# rec-plt

## 0.程序入口

**启动命令**：

```bash
rec_strategy --conf=/data/done/rec_strategy_service_master.pb.tag --load_kv_module=strategy --load_kv_dir=/data/rec-model/
```

**设置的环境变量**:

```bash
ALERT_URL=http://rec-plt-tools-uswest6-prod-proxy:8888/alert
GRPC_CLIENT_CHANNEL_BACKUP_POLL_INTERVAL_MS=10
```

**`DEBUG` 调试时需要加上**：

```bash
LD_LIBRARY_PATH=/lib64 LD_PRELOAD=/lib64/libboost_regex.so.1.75.0 gdb 
```

**配置文件打tag**：

```bash
md5sum rec_strategy_service_debug.pb > rec_strategy_service_debug.pb.tag
```

---

## 1. 代码分析：

```cpp
void RegisterMetric() {
    PM_REG(STRATEGY_MIGRATE);
    PM_REG(STRATEGY_UNKNOWN_FIELD);

    const auto quantiles = prometheus::Summary::Quantiles({{0.50, 0.001},{0.99, 0.001}, {0.999, 0.0001}});
    const auto low_quantiles = prometheus::Summary::Quantiles({{0.99, 0.001}});
}

void TerminateHandler() {
    std::exception_ptr exptr = std::current_exception(); // 获取当前未捕获的异常
    if (exptr) {
        try {
            std::rethrow_exception(exptr);
        } catch (const std::exception& e) {
            // 打印异常详细信息
            std::cerr << "Exception details: " << e.what() << "\n";
        } catch (...) {
            // 处理非 std::exception 类型的异常
            std::cerr << "Unknown exception caught!\n";
        }
    } else {
        std::cerr << "No active exception.\n";
    }
    std::stringstream ss;
    common_backtrace::PrintStackTrace(ss);
    std::cerr << "Forcing core dump...\n" << ", stack:" << ss.str();
    std::abort(); // 强制生成 core dump
}

DEFINE_string(conf, GFLAGS_NAMESPACE::StringFromEnv("CONF", "/data/conf/strategy.conf"), "server config file");
DEFINE_string(module, GFLAGS_NAMESPACE::StringFromEnv("MODULE_CONF", "strategy"), "explain module");
DEFINE_string(alert_url, GFLAGS_NAMESPACE::StringFromEnv("ALERT_URL", ""), "coredump alert url");
DEFINE_bool(quick_start_mode, false, "enable lazy loading startup dependency file");
DEFINE_int32(resource_pool_release_size, 20, "Maximum available size for resource pool before releasing resources");
DEFINE_int32(cache_memory, 8192, "cache memory size in MB");
DEFINE_int32(cache_pool_count, 16, "cache pool count");

int main(int argc, char** argv) {
    std::set_terminate(TerminateHandler);
    TIMERSTART(server_start_time);
    gflags::ParseCommandLineFlags(&argc, &argv, true);

    // folly::exception_tracer::installHandlers();

    // tag 读取文件配置
    const std::string conf_file_tag = FLAGS_conf;
    std::string conf_file;
    if (!Func::TagFile2DataFile(conf_file_tag, &conf_file)) {
        std::cout << conf_file_tag << " load error.";
        return -1;
    }
    auto& service_conf = ConfigFields<updater::ServiceConfig>::get_mutable_instance();
    if (!service_conf.PraseConfigFromGflag(conf_file)) {
        std::cout << "parse config file error.";
        return -1;
    }

    std::string ip = "";
    Func::GetLocalIp(&ip);

    std::string host_name;
    if (!Func::GetHostName(&host_name)) {
        host_name = "";
    }

    // coredump_handler::NewCoredumpHandler()
    //     ->SetProcName(argv[0])
    //     ->SetAlertUrl(FLAGS_alert_url)
    //     ->SetHostName(host_name)
    //     ->SetUp();
    async_coredump_handler::NewCoredumpHandler()
        ->SetProcName(argv[0])
        ->SetAlertUrl(FLAGS_alert_url)
        ->SetHostName(host_name)
        ->SetUp();

    auto service_static_param = service_conf.config_fields().service_param().static_param();
    auto service_dynamic_param = service_conf.config_fields().service_param().dynamic_param();
    std::cout << "service_static_param:" << service_static_param.ShortDebugString() << std::endl;
    std::cout << "service_dynamic_param:" << service_dynamic_param.ShortDebugString() << std::endl;


    const std::string debug_log_path = service_static_param.log_debug_path();
    const std::string log_path = service_static_param.log_path();
    int latency_second = service_static_param.log_latency_second();
    int minloglevel = service_static_param.log_level();  // INFO:1 WARNING:2 ERROR:3
    int log_rotate = service_static_param.log_rotate();
    int log_size = service_static_param.log_size();
    singleton<Logger>::get_mutable_instance().InitLogging("strategy", host_name, ip,
                                                          debug_log_path, log_path,
                                                          latency_second, minloglevel,
                                                          log_rotate, log_size);
    //singleton<Logger>::get_mutable_instance().InitLogging();
    // 服务级别随机队列初始化
    singleton<RandomSequenceGenerater>::get_mutable_instance().InitRandomSequence();
    std::cout << "log minloglevel:" << minloglevel << " log_rotate:" << log_rotate << " log_size:" << log_size << std::endl;
    abc::recommend_plt::feature_generate::FunctorAllocateHandlers::get_mutable_instance().Init();

    // 初始化主配置文件
    TIMERSTART(conf_file_init_time);
    abc::recommend_plt::updater::FileHandlerConf updater_conf_file;
    updater_conf_file.set_data_id(0);
    updater_conf_file.set_watch_file(conf_file_tag);
    if (abc::recommend_plt::model::DataAutoApi::get_mutable_instance().Init(updater_conf_file, true, FLAGS_quick_start_mode) == false) {
        LOG_ERROR << "init updater config error," << updater_conf_file.watch_file();
        return -1;
    }
    TIMEREND(conf_file_init_time);
    LOG_INFO << "conf files init successfully, cost_time:" << DURATION_s(conf_file_init_time) << "s";

    // init async pool
    PM_ENABLE(service_dynamic_param.monitor_enable());
    RegisterMetric();
    if (!strategy::StrategyAsyncPool::get_mutable_instance().Init()) {
        LOG_ERROR << "StrategyAsyncPool Init fail";
        return -1;
    }
    PERIOD_REPORT_START();
    strategy::StrategyMetric::get_mutable_instance().Init();
    strategy::CacheHelper::get_mutable_instance().Init(static_cast<size_t>(FLAGS_cache_memory)*1024*1024, FLAGS_cache_pool_count);
    std::thread j([]() { abc::recommend_plt::model::DataAutoApi::get_mutable_instance().WatchAndUpdate(); });
    j.detach();


    strategy::StrategyExecutorPool::get_mutable_instance().StartReportResource();
    strategy::StrategyExecutorPool::get_mutable_instance().InitExecutorPool(FLAGS_resource_pool_release_size);
    BasicFunctorPool::get_mutable_instance().Init();
    BasicFunctorPool::get_mutable_instance().StartReport();

    // kafka init
    KAFKA_REPORTER_INIT(service_comm::KafkaReporter, kKafkaAbt);
    KAFKA_REPORTER_INIT(service_comm::KVKafkaReporter, kKafkaSvrMark);
    KAFKA_REPORTER_INIT(service_comm::KafkaReporter, kKafkaStrategyFea);
    KAFKA_REPORTER_INIT(service_comm::KafkaReporter, kKafkaFeatureLanding);
    KAFKA_REPORTER_INIT(service_comm::StrategyMetricKafkaReporter, kKafkaStrategyMetric);
    KAFKA_REPORTER_RUN();

    // abc::recommend_plt::strategy::KVCache::get_mutable_instance().Init();

    // start server
    int port = service_static_param.port();
    std::string server_address("0.0.0.0:" + std::to_string(port));  //"0.0.0.0:10280"
    int thread_total = service_static_param.thread_total();
    if (thread_total <= 0) {
        thread_total = 4;
    }
    const auto session_size = GetDynConf<int64_t>("session_size", 8);
    TIMEREND(server_start_time);
		
  	...
      
    strategy::StrategyServer server;
    server.SetHandleTimeout(10000);
    server.SetAddress(server_address);
    if (!server.Run<strategy::StrategyHandle>(thread_total, session_size)) {
        LOG_ERROR << "start server error.";
        return -1;
    }
    LOG_ERROR << "recommend_svr_rank exited.";
    singleton<Logger>::get_mutable_instance().StopLogging();
    return 0;
}

```

---

###  1.1 `Set TerminateHandler`

** `std::set_terminate` **
- `std::set_terminate` 用于设置程序的“终止处理器”（terminate handler）。当 C++ 运行时调用 `std::terminate()` 时，会执行由 `std::set_terminate` 注册的函数。


当 `std::terminate()` 被调用时，会执行当前注册的 terminate handler（就是 `TerminateHandler`），然后通常产生进程终止（例如 `abort()` 产生 core dump）。

TerminateHandler 的代码（关键部分）大意如下：

1. std::exception_ptr exptr = std::current_exception();
   - 试图获取当前活动的异常对象（若存在），返回一个 `exception_ptr`。
   - 注意：`std::current_exception()` 只有在“有活动异常且在 catch 块内”时可靠地返回非空。通常在 terminate handler 中不在 catch 块内，因此它往往返回空（但某些实现/情形下可能会保留最后的异常信息，不能依赖）。因此这段代码需要理解其局限性：通常会得到 `nullptr`。

2. 
   ```cpp
       if (exptr) {
           try {
               std::rethrow_exception(exptr);
           } catch (const std::exception& e) {
               // 打印异常详细信息
               std::cerr << "Exception details: " << e.what() << "\n";
           } catch (...) {
               // 处理非 std::exception 类型的异常
               std::cerr << "Unknown exception caught!\n";
           }
       } else {
           std::cerr << "No active exception.\n";
       }
   ```

   - 如果 `exptr` 非空：重新抛出并在这里尝试把异常信息打印出来（对 `std::exception` 打印 `what()`，对其它类型打印 "Unknown exception"）。
   - 如果 `exptr` 为空：打印 "No active exception."（这是常见情况）。

3. ```cpp
   std::stringstream ss;
   common_backtrace::PrintStackTrace(ss);
   std::cerr << "Forcing core dump...\n" << ", stack:" << ss.str();
   ```

   - 使用自定义的 `common_backtrace::PrintStackTrace` 将栈信息写入 `ss`，然后将栈信息打印到 `std::err`。
   - `PrintStackTrace` 使用 `libunwind(unw_*)`来回溯栈帧、`dladdr` 获取模块信息、`__cxa_demangle` 解码符号名，并尝试用 `libdwfl(elfutils)`查询源文件和行号（如果可用的调试信息存在）。

4. `std::abort();`

   - 强制产生 SIGABRT；通常会生成 core dump（如果系统允许）。这是标准且安全的结束方式：它不会调用析构函数或进一步的 C++ 清理，而是直接让内核终止进程并产生 core（或触发系统的 coredump handler）。

总结：该 handler 尝试（有限地）获取异常内容并打印；不管是否能获取异常，会打印栈回溯并通过 `abort()` 强制终止以便生成 core dump 供离线分析。


### 1.2 注册基础 Functor
`abc::recommend_plt::feature_generate::FunctorAllocateHandlers` 是一个基于 Boost 单例模板的函数工厂注册器（factory registry）。调用 `FunctorAllocateHandlers::get_mutable_instance().Init()` 会在该单例对象内部向 `init_func_map` 中批量注册大量“函数构造器”（name -> factory lambda）。之后运行时可以通过 `FunctorAllocateHandlers::get_mutable_instance().Get(name)` 动态构造对应的 `Function` 实例（返回 `FunctionPtr`），供 `FunctionFactory` 等使用，实现按需（lazy）创建并复用实现类对象。

**Init() 做了什么:**

- `Init()` 本身在 `function_factory.cc` 中实现为：
  - 它依次调用若干注册方法：
    - `RegisterBasicFunctions();`
    - `RegisterAggrFunctions();`
    - `RegisterAlgorithmFunctions();`
    - `RegisterBucktingFunctions();`
    - `RegisterMathFunctions();`
    - `RegisterStringFunctions();`
    - `RegisterOtherFunctions();`
    - `RegisterNullFunctions();`
- 每个 RegisterXxx 函数内部使用宏：
  - #define REGISTER(name, func) \
        Register(name, []() { return std::make_shared<func>(); });
  - 示例： `Register("Add", [](){ return std::make_shared<BinaryFunction<Plus>>(); });`

因此 `Init()` 的效果是把仓库里实现的**所有**内建函数都以名字 -> 构造 lambda 的方式注入 `init_func_map`，供后续按名创建实例。

**Register / Get 的行为**:

- Register(const std::string&, std::function<FunctionPtr()> func)
  - 将给定的 factory 存入 `init_func_map[function_name] = func;`
  - 若重复注册则覆盖（实现使用直接赋值）。
- Get(const std::string& function_name) const
  - 在 `FunctorAllocateHandlers` 中：查 `init_func_map`，若找到就调用存的 lambda，返回新创建的 `FunctionPtr`；否则返回 nullptr。
  - 这是“每次调用都会新建一个实例”的工厂行为（没有内部缓存，每次 Get 都构造）。

---

### 1.3 初始化主配置

#### 1. `FileHandlerConf`
位置：recommend_updater_config.proto

关键字段：
- `uint32 data_id`：指定该配置/数据所映射的内部 data_id（在 DataAutoUpdater 中用作索引）。
- `string watch_file`：要观察/加载的文件或“配置标签”。
- `bool should_check_size`（可选）：是否检查文件大小实现某种校验。
- `bool update_priority`（可选）：优先级标志（用于 quick_start 场景只优先加载重要数据）。

语义：作为传入 `DataAutoApi::Init` 的参数，告诉更新框架“从哪里/以哪个 id 加载主配置（UpdaterConfig）”。

---

#### 2. `abc::recommend_plt::model::DataAutoApi`
位置：data_auto_api.h / `.cc`

主要目的：
- 作为上层模块访问数据/配置更新子系统的单例入口。
- 封装两个子模块：`data_updater_`（普通文件/配置更新）和 `kv_data_updater_`（KV/PVC 类型大表的更新器）。

主要接口：
- bool Init(const updater::FileHandlerConf& conf_file, bool common_cfg = false, bool quick_start_mode = false)
  - 内部做了三件事：
    1. `data_updater_.Init(conf_file, common_cfg)` —— 初始化普通更新器。
    2. `data_updater_.InitRun(quick_start_mode)` —— 根据 quick_start_mode 执行第一次数据加载。
    3. 创建 `kv_data_updater_` 并调用其 `Init(conf_file)`，将返回值保存到 `kv_init_`。
  - 返回 `true` 表示所有初始化步骤通过；任何一步失败都会导致返回 `false`。
- void WatchAndUpdate()
  - 启动一个内部线程去执行 `kv_data_updater_->Run()`（当 `kv_init_` 为 true 时），然后执行 `data_updater_.Run()`（阻塞）。在主程序中，`WatchAndUpdate` 被放入一个单独的线程并 detach，从而实现持续监控与热更新。

---

#### 3. `updater::DataAutoUpdater`
位置：data_auto_updater.h / `.cc`

核心职责：
- 负责读取主配置（通过 `CommonConfigHandler`），从主配置（`UpdaterConfig` proto）中读取每类数据的描述（例如哪些 data_id 对应哪些 handler / watch_file）。
- 根据 `UpdaterConfig` 动态实例化各类 `DataHandler`（比如 RankParamHandler、FmpParamHandler、MatchParamHandler、ItemFeatureHandlerV2、等等），并把它们注册到内部结构（`data_handlers_` 或 `data_handlers_map_`、`arrow_handlers_map_` 等）。
- 提供统一的 `Get(...)` 方法给上层代码查询各 data_id 的数据。
- 提供 `InitRun(bool quick_start_mode)`：第一次加载各 handler 的数据（如果 quick_start_mode=true，则只加载 `update_priority` 标记的 handler）。

主要接口：
- bool Init(const FileHandlerConf& config, bool common_cfg = false)
  - 创建 `CommonConfigHandler`（用于加载服务级主配置），`handler->Init(config)`、`handler->Run()`，把它放到 `data_handlers_[SERVICE_HANDLER]`（通常 index 0）。
  - 然后调用 `ReloadModel()`（用 `CommonConfigHandler` 读取到 `UpdaterConfig` 后，解析并创建具体的子 handler）。
- bool InitRun(bool quick_start_mode)
  - 对已经在 `data_handlers_` 中注册的各 handler 执行 `Run()`（load 数据）；
  - 如果 `quick_start_mode == true`，只会先执行那些 `update_priority()` 为 true 的 handler；
  - 否则会对每个已注册 handler 都执行 `Run()` 来完成第一次数据加载。
- bool Run()
  - 进入循环：周期性地调用 service handler 的 `Run()` 来检测主配置变更（若主配置有变则 `ReloadModel()`）；并轮询或调用其它 handler 的 `Run()` 以检测与加载各自 watch_file 的变更（做热更新）。
- bool ReloadModel()
  - 读取 `UpdaterConfig`（通过 `GetServiceDependCfg()` 从 `SERVICE_HANDLER` 取得），然后对 `UpdaterConfig` 中列出的各类配置项：
    - 根据 `data_id` 动态 new 对应 handler（如 `RankParamHandler`、`FeatureBucketMappingHandler`、`ItemFeatureHandlerV2` 等），调用 `Init` 或 `Reinit`，并把 handler 放到 `data_handlers_[data_id]`；
    - 对 arrow/local 特征文件，创建 `ArrowDataHandler` 并保存在 `arrow_handlers_map_`；
    - 对某些重复/集合配置（例如 repeated fields），用循环创建多个 handler。
  - 负责对每种数据类型的 handler 做“第一次注册/后续 Reinit”逻辑。

---

#### 4. `updater::KVDataAutoUpdater`
位置：kv_data_auto_updater.h / `.cc`

职责：
- 专门用于加载大规模 KV 数据（例如 PVC 存储或自定义的 kv_model），并提供按 model_id + key 的查询 `Get(model_id, key, val)`。
- 支持两种加载模式：
  - `FLAGS_kv_load_origin == true`：按 origin（原始文件）逐个 model handler 处理；
  - 否则，使用内部的 `FrozenHashMapImpl`（只读冻结哈希表）和 `global_model_idxs_` 的原子切换，做到在线更新零拷贝切换。

主要接口：
- bool Init(const FileHandlerConf& conf_file)
  - 创建并初始化 `common_handler_`（CommonConfigHandler）和 `kv_param_handler_`，调用各自的 `Init` 与 `Run`，然后 `ReloadModel()` 来解析 kv model 参数并加载或准备 handler / frozen maps；
- bool Run()
  - 循环调用 `common_handler_->Run()`、`kv_param_handler_->Run()`，在变更时触发 `ReloadModel()`，并周期性地 `Update()`（如果没有 origin 加载模式则会把新的 frozen map 替换进 `global_model_idxs_`）；
- bool Get(const std::string& model_id, const std::string& key, std::string* val)
  - 若 origin 模式：在 per-model handler 中查找；
  - 否则：通过 `global_model_idxs_` 找到路由（route_idxs）对应的 `FrozenHashMapImpl`，使用 CityHash64(key) 在冻结哈希表中查找。

---

#### 5.  `updater::DataHandler<T>`
位置：data_handler.h

职责与接口：
- 抽象数据 handler，具体的子类（RankParamHandler、FeatureMappingHandler、ItemFeatureHandlerV2、KVModelHandler 等）实现如何从文件/数据源加载并把数据放到内部结构中。
- 重要的虚函数（必须实现或可覆盖）：
  - virtual bool Init(const ProtoConfig& config) = 0;
  - virtual bool Reinit(const ProtoConfig& config) = 0;
  - virtual int Run(); // 用于轮询更新文件（默认返回 1，子类重写返回 0/1）
  - virtual bool UpdateFile(std::vector<std::string>& file) { return true; }
  - virtual void Fini();
- 提供了键值查询接口（使用 CityHash64 对 key 哈希）：
  - bool Get(int data_id, const char* key, size_t key_size, const char*& val, size_t* val_size)
  - bool Get(const std::string& key, const char*& val, size_t* val_size)
  - bool GetIdx(const std::string& version, int* idx)
  - bool Get(int specified_idx, const std::string& key, const char*& val, size_t* val_size)

内部实现细节与并发：
- 内部维护 `data_map_[3]`（三个 map）和 `int idx_`、`update_idx_` 等字段，实现采用多 buffer（至少双/三缓冲）策略：在更新时往 `update_idx_` 写数据，处理完成后切换 `idx_` 为新的有效版本，从而保证读操作（Get）可以无锁读取当前版本数据。
- `Set` / `Reserve` 等支持测试数据注入或批量装载。

---

#### 6. `updater::FileHandler`
位置：file_handler.h / 相应实现

职责：
- 在 `DataHandler` 基础上增加“文件监控/校验/加载”的公共逻辑：
  - 保存 `FileHandlerConf conf_`；
  - 管理文件大小检查 (`CheckFileSize` / `SetFileSize`)、MD5 校验、以及 `Run()` 里判断文件是否更新并在变更时调用虚函数 `Update(const std::string& file)`。
- 提供 `update_priority()` / `set_update_priority()` 支持（用于 quick_start 策略决定是否优先加载）。

---

#### 7. `updater::CommonConfigHandler`
位置：common_config_handler.h

职责：
- 继承 `FileHandler`，用于加载“服务级”或“主”配置。
- 在 `Init` 中可选择 `SetCommonCfg(true)` 表示这是公共配置；
- 实现 `Update(const std::string& file)`：把读取到的文件数据解析为 `UpdaterConfig`（或 service-related 配置），从而 `DataAutoUpdater::GetServiceDependCfg()` 能通过 `Get(SERVICE_HANDLER, model::kDependConfig, ..)` 取得 `UpdaterConfig` 的二进制并反序列化。

语义：
- `CommonConfigHandler` 是 DataAutoUpdater 首先初始化的 handler（被放在 `data_handlers_[SERVICE_HANDLER]`），负责把上层的“配置文件列表/结构（UpdaterConfig）”加载到内存，使得 `ReloadModel()` 能知道要注册哪些具体 handler。

---

#### 8. 各种具体 `*Handler`
位置：`service/updater/handler/*.cc/h`

职责：
- 每个 handler 专注读取某一种数据类型（例如 rank 参数、特征文件、fmp 参数、rec 模型等）。
- 通常在 `Init` 读取 `FileHandlerConf` 中的 `watch_file` 或其它参数并准备解析器。
- `Run()` 检测文件是否有更新并在变更时调用 `Update()` 去解析并把结果写入 `data_map_`（通过 `Set(...)` 等）。
- 提供给上层 `DataAutoApi` 一致的 `Get` 接口用于读取对应 data_id / key 的值或 proto。

实现变化：
- 一些 handler 会把数据拆成多个内部结构（例如 arrow handlers 负责复杂的特征数据并提供 `GetFeature(...)` 接口）。
- 有些 handler 会加载 proto 列表并把条目序列化存入 `data_map_`，有些产生复杂索引（例如 frozen hash map）以加速查询。

---

### 1.4 初始化异步池

`strategy::StrategyAsyncPool::get_mutable_instance().Init()`
- 主要类：`strategy::StrategyAsyncPool`（单例），内部持有 `StrategyAsyncPoolImpl`（alias）和 `havenask::HavenaskClient`
  - 参见：`service/strategy/executor/strategy_pool.h/.cc`
- `Init()` 的要点：
  - allocate `async_pool_`（`service_comm::AsyncPool<...>` 一种泛型 async client 池）；
  - 读取若干动态配置（`GetDynConf`），对每个下游服务调用 `InitService<T>(name, conn)`，即把相应的 gRPC/HTTP 客户端初始化并放入 async pool（使用 `ServiceUtility::GetService` 等查服务地址）；
  - 读取 microservice gateway 配置，调用 `async_pool_->InitConsul(addr, gateway_vec)` 初始化 service discovery（consul）；
  - 启动 async pool 的线程 `async_pool_->Run(thread_num, cq_num)`，并 `InitHttp(...)`、`SetTracer(...)`（把 `StrategyAsyncPool::TracePool` 绑定为每次调用的回调，用于度量采集）。
  - 初始化 `havenask_client_` 并运行。
- 运行态与线程：`async_pool_->Run` 会启动后台线程/IO 循环，管理异步 RPC/HTTP 请求，维护 completion queue(s)。
- 失败模式：
  - 若 `InitService` 或 `InitConsul` 失败则 `Init()` 返回 false，主程序会打印错误并退出（因为服务依赖这些下游）。
- 作用/价值：
  - 为策略里需要的异步外部调用（TFModel、FMP、Faiss、RedisProxy、ES/搜索、DMP 等）统一提供高性能、复用的异步客户端池。
  - `TracePool` 回调会把请求延迟、错误码用监控接口上报（见下）。

#### Init() 流程

1. 在 `StrategyAsyncPool::Init()` 中：
   - 构造两个成员：`async_pool_ = new StrategyAsyncPoolImpl()`（即 `service_comm::AsyncPool<...>` 的实例）和 `havenask_client_ = new HavenaskClient()`。
   - 读取若干运行时参数（thread_num、cq_num、connection_num、网关相关配置等）。
   - 逐个调用 `InitService<T>(service_name, connection_num)` 为每个下游服务在 `async_pool_` 中注册（模板服务类型与名字对应）。
   - 启用 HTTP 支持：`async_pool_->InitHttp(...)`。
   - 设置 tracer 回调：`async_pool_->SetTracer(...)`（将 `StrategyAsyncPool::TracePool` 绑定进去，用于收集每次请求的 cost/status）。
   - 设置 gateway domain / gateway name / private key（用于 HTTP header 签名等）。
   - 读取 microservice 配置文件集合，提取所有 gateway 名称，汇总到 `gateway_vec`。
   - 调用 `async_pool_->InitConsul(consul_addr, gateway_vec)` 初始化服务发现/ChannelPool（consul 地址 + gateways 列表）。
   - 启动内部线程：`async_pool_->Run(thread_num, cq_num)`（创建 completion-queue 线程、curl multi 线程和主 cq 处理线程等）。
   - 启动 Havenask 客户端：`havenask_client_->Run()`（若失败记录错误但 Init 不以失败退出）。
2. `InitService` 成功时会把 service 的 gateway 记录到 `down_stream_`（name→gateway）。

####  AsyncPool 的线程 & 事件处理

- 三类线程：
  1. 每个 `cqs_` 的轮询线程：处理 gRPC 底层 completion queue（分流）。在收到事件后会把 `BaseContext*` 通过 `cq_->Alarm` 再次投递到主 `cq_`，确保所有最终处理在主 `cq_` 线程池统一执行（兼容不同 grpc 版本）。
  2. 一个 curl multi 线程：轮询 libcurl multi，处理 `CURLMSG_DONE`，释放 headers，设置 ctx->code、cq_cost，同样通过 `cq_->Alarm` 投递到主 `cq_`。
  3. 主 `cq_` 处理线程池（由 `thread_num` 个线程）：消费 `cq_->Next` 事件，计时（cost），执行 `ctx->Run(cost)`，并在需要时调用 tracer 回调（例如上报监控）。
- 资源与生命周期：
  - AsyncPool 析构会 Shutdown cq_、Shutdown 每个 cqs_、置 exit_flag_ = true 并 join 线程，释放 curl handles (multi & easy handles)。
- 关键点：
  - `CallContext` / `HttpContext` 的内存管理采用 `new` 在 `InvokeImpl`/`InvokeHttp` 中分配并把指针作为 tag；在主 cq 线程取出 `tag` 后会用 unique_ptr<BaseContext> 接管（在 `Run` loop 中通过 `std::unique_ptr<BaseContext> ctx(static_cast<BaseContext*>(tag));`），保证释放。
  - `GetCqIdx()` 使用原子 `cq_idx_.fetch_add(...) % cqs_.size()` 做轮询分发。

####  Trace / 监控
- `async_pool_->SetTracer(std::bind(StrategyAsyncPool::TracePool, ...))` 会在主 cq 线程（RPC/HTTP 完成并 Run 之后）调用 tracer。
- `StrategyAsyncPool::TracePool` 的行为：
  - 若配置 `strategy_report_enable` 关闭则不处理。
  - 使用监控宏（`COLLECT_MONITOR` / `COLLECT_MONITOR_LITE`）上报：
    - 耗时（cost）。
    - 如果 HTTP：上报 http 错误码。
    - 如果 GRPC：上报 channel ip（ctx.channel_wrap->instance）和错误码（ctx.status.error_code）。
- 目的：统一上报下游请求的延迟和错误，用于策略监控与告警。

---

### 1.5 资源池 

#### StrategyExecutorPool

核心职责
- 管理可重用的 `StrategyExecutor` 实例池，供每个请求从池中取出执行并在完成后归还，从而避免每次请求都 `new`/`delete`。
- 定期（每 10s）上报池统计（available/current/max_current）到 `PeriodReporter`（`PERIOD_REPORT` 宏），便于监控资源使用情况。

主要数据结构
- 内部使用模板类 `ResourcePool<StrategyExecutor>`（在同文件中实现）：
  - pool 队列、mutex、condition_variable；
  - factory 函数：如何创建新的 `StrategyExecutor`（构造函数中已提供，调用 `executor->Init(true)`）；
  - `max_size_`, `current_size_`, `available_size_` 等统计字段；
  - `Init(size_t init_count)`：预创建若干实例；
  - `acquire()`：如果有可用对象直接返回；若空且未达 max，则创建新对象；若达到 max 则阻塞等待 `condition_`；
  - `release(unique_ptr<T>&&)`：归还对象，超出 `FLAGS_resource_pool_release_size` 则直接销毁（释放回内存），否则放入 pool，并 notify 唤醒等待线程。
- `StrategyExecutorPool` 封装了 `ResourcePool<StrategyExecutor>`：
  - 构造时给 `ResourcePool` 提供 factory（如何创建新的 `StrategyExecutor`，并计时/日志化初始化耗时）。
  - `GetExecutor()` 返回 `std::unique_ptr<StrategyExecutor>`（通过 `acquire()`）；
  - `ReleaseExecutor(std::unique_ptr<StrategyExecutor>&&)` 把 executor 归还；
  - `InitExecutorPool(size_t init_count)`：调用 `executor_pool_.Init(init_count)` 预分配；
  - `StartReportResource()`：启动一个后台线程（非停止线程）周期（10s）记录统计并上报 `PERIOD_REPORT("resource", "...", value)`。

如何被使用（在请求处理流程中）
- 在 `StrategyHandle::HandleRequest()`：
  - `executor_ = StrategyExecutorPool::get_mutable_instance().GetExecutor();`
  - 之后设置 arena、绑定请求等，调用 `executor_->AsyncDAG(...)` 来异步执行查询 DAG；
  - 在 `Reset()` 或处理完成后：`StrategyExecutorPool::get_mutable_instance().ReleaseExecutor(std::move(executor_));`

并发/阻塞语义
- `acquire()` 在资源耗尽且达到 `max_size_` 时会阻塞等待（`condition_.wait`），因此后端吞吐的高峰会导致等待（可能引起请求延迟或超时）。
- `release()` 若当前可用数超过 `FLAGS_resource_pool_release_size` 则会直接删除对象（目的是防止闲置对象占用过多内存）。


---

#### BasicFunctorPool
文件：basic_functor_pool.h，底层池实现在 basic_functor_pool_impl.h

核心职责
- 管理大量不同类型的 `Functor`（策略中具体节点/功能块）的对象池，每种 `functor` 按名字维护独立池；
- 提供注册（注册 functor 的名字及 factory）、取用（GetFunctor）、归还（ReleaseFunctor）接口；
- 通过后台线程周期性上报每个 functor 池的统计信息，并通过自适应逻辑调整池的 `release_size`（按 allocate_count 增减释放阈值以应对负载波动）。

主要接口
- `void Init()`：在代码里（strategy_executor.cc 中）会调用 `RegisterFunctor(...)` 注册多个 functor（注册时会构造 `FunctorPoolImpl<Functor>` 并设置初始/最大/释放阈值等）。
- `void RegisterFunctor(const std::string& functor_name, size_t hint_count, Factory factory)`：
  - 计算 `config`：`init_size`, `max_size = hint_count * work_thread_count * 10`, `release_size` 等，并创建 `make_functor_pool<Functor>(config, factory)`。
  - `hint_count` 是注册时提供的并发提示，用于估算 `max_size` 与 `release_size`。
- `std::unique_ptr<Functor> GetFunctor(const std::string& functor_name)`：从对应池 `Acquire()`，如果池不存在返回 `nullptr`。
- `void ReleaseFunctor(Functor* functor)`：把 `Functor*` 放回对应池（或根据策略销毁）。
- `void StartReport()`：
  - 启动两个 detached 后台线程：
    1. 每 60 秒遍历每个池并上报 `size`、`max_size`、`release_size`、`acquire_count`、`allocate_count`、`release_count`（使用 `PERIOD_REPORT` / `PERIOD_REPORT_ADD`）。
    2. 每 1 秒遍历并根据 `allocate_count` 的增量调整每个池的 `release_size`（如果 allocate_count 增加则 increase release_size，否则 shrink release_size）。这是实现自适应的关键逻辑：当分配频繁时扩大保留（减少重复 allocate），当分配减少时缩小保存减少内存占用。

底层池（`FunctorPoolImpl<T>`）
- 使用 `boost::lockfree::stack<T*> pool_`（无锁栈）作为对象池容器；
- `Acquire()`：先 `pop`，成功则返回该对象；若池为空则 `allocate_count++` 并调用 factory 创建新对象；
- `Release(T* obj)`：若当前池数 >= `release_size` 或 >= `max_size_` 则销毁对象（调用 deleter 或 delete），否则 push 回池并 `current_size_.fetch_add(1)`；
- 统计字段（atomic）：`acquire_count_`, `allocate_count_`, `release_count_`，并有 `ResetStatistic()`。

---

### 1.6 kafka相关

在 rec_strategy.cc 里这几行：
```cpp
KAFKA_REPORTER_INIT(service_comm::KafkaReporter, kKafkaAbt);
KAFKA_REPORTER_INIT(service_comm::KVKafkaReporter, kKafkaSvrMark);
KAFKA_REPORTER_INIT(service_comm::KafkaReporter, kKafkaStrategyFea);
KAFKA_REPORTER_INIT(service_comm::KafkaReporter, kKafkaFeatureLanding);
KAFKA_REPORTER_INIT(service_comm::StrategyMetricKafkaReporter, kKafkaStrategyMetric);
KAFKA_REPORTER_RUN();
```
等价于调用（宏展开）：
- 为每个名字调用 `KafkaReporterManager::get_mutable_instance().InitReporter<ReporterType>(name)`；
- 然后调用 `KafkaReporterManager::get_mutable_instance().Run()` 启动后台消费线程。

---

### 1.7 服务启动

代码片段：
```cpp
strategy::StrategyServer server;
server.SetHandleTimeout(10000);
server.SetAddress(server_address);
if (!server.Run<strategy::StrategyHandle>(thread_total, session_size)) { ... }
```

#### Server 类型与模式
- `StrategyServer` 是在 strategy_svr_imp.h 中的类型别名：
  - using StrategyServer = service_comm::ServerImpl<abc::recommend_plt::api2::Recommender, abc::recommend_plt::api2::RecMsg, abc::recommend_plt::api2::RecMsg, &abc::recommend_plt::api2::Recommender::AsyncService::RequestDoRecommend>;
- 因此 `ServerImpl` 是一个基于 gRPC 的异步服务器实现（async server）。它采用 gRPC 的 CompletionQueue（CQ）机制处理异步事件，ServerImpl 的 `Run` 启动了：
  - 一个 gRPC server（builder.BuildAndStart）
  - 一个单独的 CompletionQueue（builder.AddCompletionQueue）用于接收所有异步事件
  - 一组 worker 线程（数量 = `worker_size` / `thread_total`），每个线程循环调用 `cq_->Next()`，取出事件并分派给对应的 `Context` 对象处理

这是一个基于 gRPC Async API 的异步事件驱动服务器（single CQ + worker thread pool 模式）。

####  Run(...) 的启动流程
在 `ServerImpl::Run<ContextType>` 中（按代码顺序）：
1. 打印信息并设置 `session_size_`（并构建 grpc::ResourceQuota）。
2. 使用 `grpc::ServerBuilder`：
   - 设置 channel keepalive 等参数；
   - 调用 `builder.AddListeningPort(server_address_, ...)` 监听地址；
   - 注册 service（`builder.RegisterService(&service)`）；
   - 设置 send/receive message size；
   - 通过 `builder.AddCompletionQueue()` 创建并返回一个 CQ 对象（`cq_`）。
3. `server = builder.BuildAndStart()` 启动 gRPC server（内部创建网络 IO 线程等）。
4. 预分配 `session_size` 个 `Context`（vector<Context> contexts(session_size)），并对每个 context：
   - 调用 `contexts[i].Init()`（Context 子类用于做局部初始化；在 `StrategyHandle::Init()` 实现中通常做空或者设置 ip 等）；
   - 调用 `contexts[i].reset(&service, cq_.get());` —— 这一步向 gRPC 注册一次“接收请求”的异步操作：`(service->*rpc)(ctx, request_, resp_writer_, cq, cq, this)`。也就是说预先给每个 Context 注册一次 accept。
5. 设置 `available_session_size_ = session_size`。
6. 启动 `worker_size` 个工作线程（`workers_`），每个线程都循环执行：
   - `cq_->Next(&tag, &ok)` 等待下一个事件；
   - 将 `tag` 转为 `Context*`，根据 `context->status_` 的状态（READY/RUNNING/FINISH）做不同处理：
     - READY：将状态置为 RUNNING，注册超时 alarm（grpc::Alarm），调用 `context->HandleRequest()`，并把 `available_session_size_--`；
     - RUNNING：表示超时事件触发（alarm 到期），调用 `context->HandleTimeout()`；
     - FINISH：表示响应已经发送完成（resp_writer_->Finish 发回一个事件），处理 cancel alarm、调用 `Reset()` 清理、`available_session_size_++`，并重新 `reset(&service, cq)` 再次注册该 Context 用于下一次请求。
7. 主线程 join 所有 worker（在正常 shutdown 之前 worker 会一直运行），当 CQ 关闭时线程退出，最后调用 `server->Shutdown()`。

####  `Context` 的职责与生命周期
- `Context` 是 `ServerImpl` 的内部类（模板子类由用户实现，`StrategyHandle` 继承它）。
- 主要成员：
  - `REQ* request_, RESP* response_`：使用 `google::protobuf::Arena` 创建，减少内存分配。
  - `grpc::ServerContext`、`grpc::ServerAsyncResponseWriter<RESP>`、`grpc::Alarm`（可选的超时定时器）。
  - `status_`（READY、RUNNING、FINISH）用于区分事件语义。
- 关键方法：
  - `reset(service, cq)`：把 Context 置为 READY，重新在 gRPC 上注册一次接收请求（通过 `(service->*rpc)(...)`）。这是“永远保持 N 个预注册接收”的实现方式，`session_size` 决定能同时接受多少条 in-flight 会话。
  - `register_handle_timeout(timeout_ms, cq)`：如果设置了 handle_timeout_ms，会创建一个 `grpc::Alarm`，`Alarm` 在超时时间到时把 tag（this）放回 CQ，触发 worker 的处理（用于超时处理）。
  - `ReturnResponse()`：在响应需要发送时调用，内部实现将 `status_ = FINISH`，并调用 `resp_writer_->Finish(*response_, grpc_status_, this)`，当 Finish 完成后会再次把 tag(this)放到 CQ，worker 在 FINISH 分支完成清理并重新 `reset`。
  - `HandleRequest()`、`HandleTimeout()`、`Init()`、`Reset()`：由用户实现（ `StrategyHandle`）。

####  `StrategyHandle`如何处理一次请求
关键实现在 strategy_svr_imp.cc / `.h`：

- 当 worker 看到 READY 并调用 `context->HandleRequest()` 时，会执行 `StrategyHandle::HandleRequest()`：
  - 从 `StrategyExecutorPool` 获取一个 `StrategyExecutor`（`executor_ = GetExecutor()`）。
  - 设置 arena（通过 `executor_->SetArena(arena())`），准备复用 proto arena。
  - 解析请求内参数，构造 `param_vec` 等；
  - 调用 `executor_->Bind(request(), std::move(param_vec), &response())` 绑定请求/响应；
  - 调用 `executor_->AsyncDAG([&]() { this->HandleResponse(); });` 启动异步执行 DAG（策略执行图）。注意 `HandleRequest()` 是非阻塞的，它触发执行后立即返回。
- 执行过程是异步的。`StrategyExecutor` 在完成 DAG 计算后会调用回调（这里是 `HandleResponse()`）：
  - `HandleResponse()` 中最终会把计算结果写入 `response()`，然后必须调用 `ReturnResponse()` 告知 gRPC 发包（`resp_writer_->Finish(...)`），这会把 FINISH 事件投回到 CQ。
- 当 FINISH 事件被 worker 线程捕获时，worker 在 `Context::STATUS::FINISH` 分支：
  - `cancel_handle_timeout()`，调用 `context->Reset()` 清理（清空/重置 arena、request/response ptr 等）；
  - `available_session_size_++` 并 `PERIOD_REPORT` 上报会话容量；
  - 最后 `context->reset(&service, cq)` 再次注册该 Context 为 READY，以接受下一个请求。

因此请求的整体生命周期：
1. 在 `reset()` 阶段，Context 注册接受（等待 request）。
2. gRPC 网络 IO 接收到 request，并把 tag (context) 放到 CQ。
3. worker 线程取出 tag、发现是 READY -> set RUNNING -> 调用 `HandleRequest()` -> 异步执行开始（executor），并注册一个 alarm（超时）。
4. 计算完成时 executor 调用 `HandleResponse()` -> `ReturnResponse()` -> gRPC 完成后放 FINISH 事件到 CQ。
5. worker 线程看到 FINISH -> 调用 `Reset()` 和 `reset()` -> Context 再次 READY。

注意：实际网络读写与 gRPC 的底层线程（I/O）由 gRPC 库管理，应用只接收 CQ 事件并在 worker 线程上执行用户逻辑。

#### 分析

这个服务更接近 Proactor 模式（以 gRPC 的异步完成队列 / CompletionQueue 为核心的完成驱动模型），但在工程实现上带有典型的事件分派（Reactor 风格）成分——可以把它看成 Proactor 实现（由 gRPC 提供异步 IO） + 应用端的事件循环/分发（CQ + worker）混合体。

1) Proactor vs Reactor
- Reactor：应用程序注册“感兴趣的 I/O 事件”（可读/可写/accept 等），事件循环（demultiplexer，比如 epoll）检测事件并同步调用相应的 handler，通常 handler 在执行期间做实际的 I/O 操作（应用负责读/写）。
- Proactor：应用发起异步操作（比如 async read/accept），实际 I/O 由底层/OS/框架执行；当操作完成时，框架把结果放到完成队列，然后调用/通知应用的完成回调，应用只处理完成结果（不用自己做阻塞 I/O）。

2) gRPC CompletionQueue
- 应用通过 `Context::reset(...)` 调用 `(service->*rpc)(...)` 来“预注册”接收（这相当于发起一个异步 accept/read 请求给 gRPC）；
- gRPC 底层负责真实的网络 I/O（读包、解析 protobuf 等），当请求到达或 Finish 完成时，gRPC 将一个完成事件（携带 tag=this）放入 `CompletionQueue`（CQ）；
- 应用线程（worker）通过 `cq_->Next(&tag, &ok)` 阻塞等待完成事件，拿到事件后执行对应的回调逻辑（Context->HandleRequest / HandleTimeout / FINISH 分支）。

以上特征：应用不做底层网络读写，底层框架做 I/O 并把“完成事件”通知给应用 —— 这是 Proactor 的关键特征。

3) 对应到代码的映射
- 发起异步操作（Initiation）：`contexts[i].reset(&service, cq_.get())` 中的 `(service->*rpc)(...)` —— 把一次 async accept/recv 注册到 gRPC（应用“要求 gRPC 在请求到达时回调”）。
- 完成源（Proactor runtime / OS）：gRPC 的内部网络线程/实现负责实际的网络 I/O 和 RPC 协议处理。
- 完成通知（Completion Demultiplexer）：`grpc::ServerCompletionQueue`（CQ）保存完成事件并提供 Next() 供应用读取。
- 完成处理（Application completion handlers）：worker 线程在 `cq_->Next()` 返回后，按 `Context::status_` 调用 `HandleRequest()` / `HandleTimeout()` / FINISH 处理（应用层处理完成结果、业务执行、回复客户端）。
- 超时机制：`grpc::Alarm` — alarm 到期也会被放到 CQ，从而应用在 RUNNING 状态下收到“超时完成事件”并执行 `HandleTimeout()`。

4) 请求到达时的完整事件时间线（函数栈 / 流程）
- 初始：Server 已通过 `reset()` 为若干 `Context` 做好了“预注册接受”。
- 网络层：gRPC 的 IO 线程接收网络数据并完成 RPC 的解码；当一条新请求准备好时，gRPC 把事件（tag = Context*）推入 CQ。
- worker 线程：`cq_->Next(&tag, &ok)` 返回 -> `context = static_cast<StrategyHandle*>(tag)` -> 根据 `context->status_`：
  - READY -> 标记 RUNNING，注册 `grpc::Alarm`（超时），调用 `context->HandleRequest()`（即 `StrategyHandle::HandleRequest()`）；
    - 该函数取出 `StrategyExecutor`（从 `StrategyExecutorPool`），设置 arena，调用 `executor_->Bind(...)`，随后调用 `executor_->AsyncDAG(lambda -> HandleResponse)` 来异步执行策略 DAG（注意：`HandleRequest()` 本身尽量非阻塞，快速返回）。
- 异步执行完成：`StrategyExecutor` 在完成后调用 `StrategyHandle::HandleResponse()`：
  - 填充 response，调用 `ReturnResponse()` -> `resp_writer_->Finish(*response_, grpc_status_, this)`，gRPC 在把响应真正发送到客户端后会把 FINISH 事件（tag = Context*）放回 CQ。
- worker 线程再次从 CQ 取到 FINISH 事件 -> 在 FINISH 分支 `Reset()` 清理并重新 `reset(&service, cq)`，这使得 Context 再次变为 READY，接收下一个请求。



## 2. 主要类分析

### 2.1 Context类

 `StrategyHandle`（实现）和 `ServerImpl::Context`（框架基类）。

- `ServerImpl::Context` 是框架级的“单次 RPC 会话上下文”抽象，封装了 protobuf arena、gRPC ServerContext/ServerAsyncResponseWriter、超时 Alarm、以及“状态机”（READY/RUNNING/FINISH）和用于向 gRPC 注册/重新注册接收请求的内部方法。  
- `StrategyHandle` 继承自 `ServerImpl::Context`，实现具体的业务逻辑：如何在收到请求时驱动策略执行器（StrategyExecutor），如何在执行完成时填充 response 并返回客户端，以及如何在 Reset 时清理/归还资源。


#### `ServerImpl::Context`
- 代表单个 RPC 会话(slot)：管理一次请求从“等待”到“处理”到“完成并重置” 的整个生命周期。
- 封装 gRPC 的异步 API 细节，提供：
  - 预注册异步接收（`reset(service, cq)`）：调用 `(service->*rpc)(...)` 将一个异步接收请求提交给 gRPC（代表“我愿意接收下一个请求”）。
  - 超时注册（`register_handle_timeout` / `cancel_handle_timeout`） via `grpc::Alarm`，当超时到期时会把 tag 投回 CompletionQueue，以便 worker 调用 `HandleTimeout()`。
  - Response 发送：`ReturnResponse()` 会把 `resp_writer_->Finish(...)` 发回 gRPC 并把 context 标记为 FINISH（Finish 完成后框架会再次收回 tag，让 worker 做重置）。
  - Arena 管理：用 `google::protobuf::Arena` 提供高性能的 protobuf 对象分配（`request_`/`response_` 都在 arena 上分配）。
- 定义抽象接口供子类实现：
  - virtual bool Init()
  - virtual void Reset()
  - virtual void HandleRequest() noexcept
  - virtual void HandleTimeout() noexcept (可选)

#### `StrategyHandle`
主要方法：
- bool Init() override
  - 在 Run 初始化 contexts 时会调用一次，供做一次性资源准备（例如获取 pod ip，或预分配轻量状态）。如果返回 false，Run 会失败。
- void Reset() override
  - 当一个请求完成（FINISH）后框架会调用 `Reset()`，这时子类应释放或归还该请求持有的资源（例如把 `executor_` 归还到池、清理自有状态等）。
- void HandleRequest() noexcept override
  - 当有新的请求到达（READY -> RUNNING），框架会在 worker 线程中调用这个函数。这里应尽量做“非阻塞触发工作”的操作：例如从 executor 池获取 `StrategyExecutor`、绑定请求、把实际计算提交到后台线程/任务系统，然后快速返回。不要在这里长时间阻塞或做慢 I/O。
- void HandleTimeout() noexcept override
  - 当超时 alarm 到期且请求仍在 RUNNING 时框架会把 tag 投回，worker 在 RUNNING 分支调用 `HandleTimeout()`，子类实现应执行超时处理（记录、降级、标记状态、立即 ReturnResponse 等）。
- void HandleResponse()
  - 不是框架要求的纯虚方法，用于当 `StrategyExecutor` 执行完毕时被回调：在这里你把结果写入 `response()` 并调用 `ReturnResponse()`。`ReturnResponse()` 会把 `resp_writer_->Finish()` 发给 gRPC，gRPC 完成后会把 FINISH 事件送回 CQ，由框架完成 Reset。

####  典型生命周期
1. Run 初始化阶段：
   - 框架在 `Run` 中创建 `session_size` 个 `StrategyHandle contexts`，对每个调用 `Init()`，然后调用 `reset(&service, cq)`，即在 gRPC 端提交 `RequestDoRecommend` 的异步接收请求（这些是“空闲的会话槽”）。
2. 请求到达时：
   - gRPC 内部完成 I/O，CQ 返回一个事件（tag = 指向某个 `StrategyHandle`）。
   - worker 线程从 `cq_->Next()` 得到 tag，发现 context 的状态为 READY，于是：
     - 把 status->RUNNING，注册 alarm（`register_handle_timeout`），调用 `HandleRequest()`。
3. 在 `HandleRequest()` 中：
   - 你从 `StrategyExecutorPool` 获取 executor（`GetExecutor()`），把 arena 传给 executor（`SetArena(arena())`）以便在执行过程中用同一个 arena 分配临时 proto，调用 `executor_->Bind(request,...,&response())`，然后调用 `executor_->AsyncDAG([&]{ HandleResponse(); })` 启动实际的 DAG 异步计算。`HandleRequest()` 返回（非阻塞）。
4. DAG 完成后：
   - `StrategyExecutor`（在它的线程或任务系统）在完成时调用 `StrategyHandle::HandleResponse()`：
     - 在 `HandleResponse()` 中填充 `response()`，并调用 `ReturnResponse()`，这会发起 `resp_writer_->Finish()` 并将 context 标为 FINISH。
5. Finish 事件：
   - gRPC 在发送完成后把 FINISH 事件放回 CQ。
   - worker 再次在 `cq_->Next()` 得到该 tag，发现状态为 FINISH，于是：
     - `cancel_handle_timeout()`，调用 `Reset()`（释放 executor 并归还池等），增加 `available_session_size_`，并调用 `reset(&service, cq)` 重新注册该 context 为 READY（可以接受新的请求）。
6. 如遇超时：
   - Alarm 到期会把 tag 投回 CQ，此时框架看到 status_ == RUNNING，会调用 `HandleTimeout()`，子类可做记录或立即 `ReturnResponse()`。

---

### 2.2 StrategyExecutor


#### 策略引擎中 StrategyExecutor 做什么

业务背景：
- 推荐请求通常按阶段处理：召回（recall）→ 预排序（prerank）→ 重构/补全（rebuild）→ 排序（rank）→ 精排/再排序（rerank）→ 上报/埋点/report。
- 每个阶段可能由若干“策略”（strategy）组成。每个 strategy 对应一个“算子”（Functor）。算子可以是召回器（recaller）、编排器（arranger）、特征提取（extractor）、合并（merge）、上报（reporter）等。

StrategyExecutor 的职责：
1. 接受一个请求，并将请求数据绑定到内部的 `Accessor`（请求上下文、特征、候选项、埋点/监控数据都放在这里）。
2. 根据请求要跑的 `strategy_ids`，用 `StrategyAnalyzer` 将这些 strategy 构造成一组 Functor，并构建 DAG。
3. 把 Functor 节点转换成 `Graph`/`Node` 对象（节点包含 functor + 其 Accessor），然后并行/异步执行 DAG（由 `Graph` 和 `Node` 协作）。
4. 处理异步回调（异步算子内部触发完成回调），收集完成的结果，执行后置 finish job（例如上报类 Functor）。
5. 管理资源（functor 池、KV/ES 批量 helper、accessor/rebuild accessor 等）与超时/降级（通过 `StrategyController`）。
6. 返回最终 response（写回 gRPC/HTTP 层）。

换句话说：`StrategyExecutor` 是单次请求在推荐平台内部的“指挥/协调器”——把请求上下文（Accessor）交给一组按依赖执行的算子（Functor），负责并发、超时、降级与收尾汇报。

---

#### 关键数据结构与类

#####  `Accessor`
作用：
- `Accessor` 是一个“请求级上下文容器” —— 保存一个请求在整个策略执行过程中的所有上下文数据与临时结果：
  - 原始请求 proto（`api::RecommendRequest` / `api2::RecMsg`）与 response（`api2::RecMsg`）
  - 请求相关元数据：trace_id、site_id、scene_id、item_source 等
  - 上下文特征映射 `ctx_feature_`、物料特征映射 `item_feature_`
  - 召回候选 `recall_items_`（按 strategy_id 分桶保存召回出的候选项 + 特征）
  - 各种上报/埋点集合（`ctx_explain_`、`item_explain_`、`ctx_monitor_`、`item_rec_mark_` 等）
  - 工具对象引用：`KVModelHelper* kv_model_helper_`、`EsBatchHelper* es_batch_helper_`
  - 内部锁：`ctx_lock_`、`item_lock_`、`rsp_lock_` 保证并发读写安全
  - 其它：stage 成功计数、控制参数白名单、特征落地配置信息等

概念理解：
- `Accessor` 就像请求执行期间的“黑板/中间仓库”。不同算子把结果写到这里，后续算子从这里读。它同时负责记录监控/埋点数据。

---

#####  `Functor`
作用：
- `Functor` 是所有“算子”的抽象基类。每个 strategy 在运行时都会被绑定成一个 Functor 实例（或从 pool 获取）。
- 一个 Functor 承载：策略 id、所属阶段（stage）、必需的输入特征名、输出特征名、是否异步、是否有降级逻辑等。

重要成员与方法：
- 生命周期/状态：
  - `Reset()`：重置内部状态（用于复用/pool）。
  - `Init()`：初始化（可能注册内部资源）；默认返回 true。
  - `Bind(strategy_id, StrategyParam&)`：将策略 id 和策略参数绑定到这个 Functor 上。
  - `set_strategy_id()` / `name()` / `Stage()`：元信息访问。
- 执行相关：
  - `PrepareRun(Accessor*)`：在真正 Run 之前的准备步骤（默认返回 true）。
  - `Run(Accessor*)`：算子的核心执行逻辑（纯 virtual，子类实现）。返回 bool 表示是否成功/有效等。
  - `support_async()`：标记算子是否内部会异步完成（如果 true，算子需要在内部某处触发 `cb` 来通知完成）。
  - `SetCallback` / `GetCallback`：用于 Functor 完成后对上层 graph 的回调。`GetCallback` 包含防重复调用的机制（`has_run_` 原子），并在重复调用时打印栈信息以便调试。
- 特征声明/管理：
  - `SetRequiredItemFeaName/SetOutputCtxFeaName/SetReportCtxFeaName/...`：用于声明输入/输出依赖，供 `StrategyAnalyzer` 构建 DAG 时计算依赖。
  - `SetRequiredAllFeatures(param)`：从 proto param 批量导入输入/输出特征名集合。
- DSL & dsl_helper：
  - Functor 持有 `DslHelper`，用于解析/执行 DSL 风格的表达式（例如某些 filter 或排序表达式）。
- 辅助功能：
  - `AsyncQueryItemFea(...)`：封装对 item feature service 的异步查询逻辑，内部会使用 `StrategyAsyncPool` 与 `acc::ItemFeatureClient`。方便 recaller / extractor 等在运行时发起 item feature 请求。

概念理解：
- 每个具体算子（recaller/arranger/merger/recaller/feature extractor/report 等）继承自 `Functor`，实现 `Run(Accessor*)`。通过 `required`/`output` 特征声明，`StrategyAnalyzer` 可以自动把这些算子按依赖连接成 DAG。

并发/异步：
- 算子可能是“同步”或“异步”两种模型：
  - 同步算子：`Run()` 执行完就返回结果（通常立即调用回调系统），Graph 根据返回情况继续推进。
  - 异步算子：`support_async()` 返回 true，算子内部会发起异步子请求（例如网络 I/O），并在真正完成时调用为自己设置的回调 cb。这要求 Graph/Node 能处理异步完成的通知。

错误/降级：
- 子类可以实现 `has_degrade_run()` / `DegradeRun(Accessor*)` 来支持算子内部的降级处理（例如热点降级、超时返回默认候选等）。

---

##### `StrategyAnalyzer`
功能：
- 将用户请求中的 `strategy_ids` 转换为一组实际要执行的 Functor（可能会把“合并器”要求的 recaller 自动插入）。
- 填充每个 Functor 的输入/输出依赖信息。
- 构建 DAG（函数之间的依赖关系），并把 Functor 分配到 Graph 节点中。
- 处理“rebuild”（重构）流程：当 has_rebuild_ 时，会把某些阶段使用 `rebuild_accessor_`（而不是主 `accessor_`），以实现主流程与重构流程的数据隔离。

主要函数与流程：
1. `BuildDAG(strategy_ids)`：
   - 总调度：依次调用 `BuildFunctors`、`BuildDependent`、`BuildGraph`。
2. `BuildFunctors(strategy_ids)`：
   - 对给定的 strategy id 列表去重后，调用 `strategy_executor_->BindStrategyId(strategy_id, accessor)` 来创建/绑定 Functor（`BindStrategyId` 在 `StrategyExecutor` 中实现，返回 Functor*）。
   - 特殊处理：
     - 如果 functor 是 MERGER_ARRANGER，会把其所需的 recaller strategy 添加进来（并为相应 recaller 设置 merge_tag/recall_num 等），同时为 `kv_model_helper_` / `es_batch_helper_` 设定预期计数（`AddExpectCount`），以便 batched helper 预分配容器/并发槽位。
     - 处理 further_merge、recall_filter 等逻辑（把一些全局默认的 aggregator/further_merger 插入）。
   - 最后会把一些全局 finish/extra functors（如 MonitorReporter、ExplainReporter 等）也追加到 `functors_` 列表，以便作为 finish jobs 或普通阶段节点执行。
3. `BuildDependent()`：
   - 按 stage（RECALL/PRERANK/REBUILD/RANK/RERANK/REPORT）建立“依赖链”（例如 RECALL 阶段的输出是 MERGER 的输入等），并为某些常见的输出/输入特征设默认值（`kFeaGMatchItem` 等）。
   - 最终将 `functors_` 按 stage stable_sort，使不同阶段算子以阶段顺序排列。
4. `BuildGraph()`：
   - 根据各 functor 的 `GetOutputCtxFeaName()/GetOutputItemFeaName()` 和 `GetRequiredItemFeaName()/GetRequiredCtxFeaName()`，计算 DAG 边（哪些 functor 的输出被哪些 functor 依赖），同时考虑“并行 item 特征”集合（`parallel_item_feas`）等策略以决定并行/串行连接。
   - 为每个具有依赖的 functor 创建 `Graph` 节点（`strategy_executor_->graph_->AddNode`），并建立父子连接（parent->AddChildren(child)）。
   - 在建立每个 parent node 之前，会调用 `AdaptAccessor(functor)->PreAllocateResource(functor->strategy_id())`，以便根据 functor 的预期工作量预分配容器（减少执行时内存重分配）。

适配 Accessor：
- `AdaptAccessor(Functor*)` 根据 `has_rebuild_` 以及 functor 的 stage 返回使用 `accessor_` 还是 `rebuild_accessor_`。目的是把 rebuild 阶段与主流程隔离，避免干扰彼此的数据结构。

总结：
- `StrategyAnalyzer` 是策略解析器：从策略配置/规则 -> 生成可执行的 DAG（Functor 集合 + 依赖），并为每个节点分派合适的 Accessor。

---

#####  `Graph` 与 `Node`
作用：
- `Graph` 封装了 DAG 的运行与监控（含超时、运行统计、Dump/Report）。
- `Node` 表示 DAG 中一个可执行单元：包含 `Accessor*`, `Functor*` 和其子节点列表、父计数等。节点负责运行其 Functor，并在其父依赖满足时触发自身运行。

`Node` 的关键方法：
- 构造与 InitializeCallback：
  - `Node(Accessor* accessor, Functor* functor, Graph* graph)`：构造节点并关联 functor 与 accessor。
  - `InitializeCallback()`：设置 functor 的回调函数（cb），cb 在算子完成时调用（无论同步或异步），cb 会在 node 层面处理 parent/children 的通知逻辑。
- `AddChildren(std::shared_ptr<Node> child)`：建立 parent->child 邻接关系。
- `Run()`：节点运行自身的逻辑：
  - 如果 `Skip()` 为 true（例如策略被屏蔽或其他条件），节点会直接标记为完成并触发 children。
  - 否则：执行 `functor->PrepareRun(accessor)` -> `functor->Run(accessor)`。如果是异步算子，`Run` 返回后实际完成由其内部异步流程在未来调用 cb；如果 `Run` 同步完成，`InitializeCallback` 会在 `Run` 内部或Run后被立即触发。
- `RunChilds()`：当当前节点完成时，通知子节点减少 parent 未完成计数并当计数到 0 时触发子节点的 `Run()`。
- `Report()`：记录节点运行耗时、层级统计等 Prometheus 监控（`util::pmonitor`）。

`Graph` 的关键方法（用途）：
- `Bind(Accessor*, StrategyController*)`：把 graph 与 executor 的 accessor/controler 绑定（以便节点执行时访问 controller 的决策）。
- `AddNode` / `GetNode`：创建并记录节点。
- `Run(std::function<void()>&& end_cb)`：触发图的执行（通常 graph 会遍历没有父节点的 entry nodes 开始 Run），并在所有节点完成时调用 end_cb（也就是 StrategyExecutor 的最终回调）。
- `HasLoop()`：检测有无环（安全检查）。
- `Dump()` / `Report()`：可视化/监控输出。

并发细节：
- `Node` 里使用 `parent_done_cnt_`（原子）与 `parent_cnt_`（父总数）。当 parent 回调时，`parent_done_cnt_` 增加，等于 `parent_cnt_` 时才执行该节点。这样保证父节点全部完成后才启动子节点。
- 超时/timeout_{500}：每个 Node 可有其单独 timeout 默认 500ms，可以在 `InitializeCallback`/Graph run 时注册 Alarm（在 gRPC Server 的上下文中），或 Node 内部在 Run 时比较时间戳并采取降级/终止措施。

总结：
- `Graph`/`Node` 把 Functor 的“函数依赖关系”具体化为并行可执行节点，负责在运行时以异步安全的方式协调算子执行与子节点触发。

---

##### `StrategyController`
作用：
- 对于一次请求执行周期，`StrategyController` 管理运行时策略执行的“控制规则”：
  - 哪些策略被禁用（`disable_strategy_ids_` 等）
  - 是否全局禁用（`disable_all_`）
  - 哪些 stage 必须运行（`must_stages_`）
  - 是否出现降级（`has_degrade_`），以及 pm_type_/degrade_type_ 标记
- 提供判断接口：
  - `Bind(Accessor*)`：把 controller 与请求关联，并可能基于请求上下文初始化运行时黑/白名单。
  - `AllowBuild(const Functor*)`：在构建 DAG 时用于判断某个 Functor 是否允许被创建并加入 DAG（例如全局禁用、按策略 id 禁用）。
  - `AllowRun(const std::shared_ptr<Node> node)`：在 Graph 运行时判断某个节点是否可以执行（例如跑到一个 stage，但 controller 根据实时配置决定跳过）。
  - `AddRuntimeMsg()`：在运行过程中添加运行时消息（例如日志或统计），用于后续报告或决策。
  - `has_degrade()`：是否触发降级逻辑的查询：`StrategyExecutor` 或 Functor 可据此选择降级路径。

业务用途：
- 方案A/方案B 的 AB 测试开关、按流量/请求来源屏蔽某些策略、突然发现某些外部服务异常时临时禁掉特定 recaller/merger，都是通过 `StrategyController` 的配置/决策实现。

---

#### `StrategyExecutor` 

##### 从请求到响应的执行序列

一次请求在 `StrategyExecutor` 中的处理流程。（`api2::RecMsg` 的路径）：

1. gRPC server 接收到请求，获取 `StrategyHandle`（server context），并在 `StrategyHandle::HandleRequest()` 中分配一个 `StrategyExecutor`（或从 `StrategyExecutorPool` 取出）。
2. 在 `StrategyHandle` 中调用 `executor->SetArena(arena)` 将 protobuf arena 绑定到 executor（从 server 的 Context 中获取 arena）。
3. 调用 `executor->Bind(req, strategy_ids, rsp_ptr)`：把请求和要执行的 `strategy_ids` 绑定到 `accessor_`。`accessor_->Bind` 会做必要的请求解析（例如拆分 strategy_ids、提取控制参数、设置 site/user 等）。
4. `executor->analyzer_->set_has_rebuild(flag)`：根据请求的某些控制参数，可能会设置 has_rebuild_（是否走重构流程）。
5. `executor->Analyzer->BuildDAG(strategy_ids)`：
   - `BuildFunctors`: 为每个 strategy id 创建/获取 Functor（`BindStrategyId`），把其加入 functor 列表；如果是 merger 类型，自动插入其所需的 recall 策略等；设置 `kv_model_helper_`/`es_batch_helper_` 的期望并预分配资源。
   - `BuildDependent`: 根据各 functor 的 stage 设置默认的 required/output 特征名（例如 recall->match_item, prerank->prerank_item 等）。
   - `BuildGraph`: 根据特征依赖关系构造 dag_map（Functor* -> set<Functor*>），对每个 functor 创建 `Graph::AddNode(accessor, functor)` 并用 `parent->AddChildren(child)` 连接。
6. `executor->graph_->Run(end_cb)`：执行 Graph。
   - Graph 会找到所有没有父节点（entry nodes），对这些节点调用 `Node::Run()`。
   - `Node::Run()`：
     - 如果 `controller_->AllowRun(node)` 表示不允许运行则跳过。
     - 调用 functor->PrepareRun(accessor)（准备阶段：例如确保所需特征存在、设置 trace/tt等），然后调用 `functor->Run(accessor)`。
     - 若 functor 是同步执行（普通 Run 立即返回），则 functor 执行完后会触发 `functor` 的回调（`InitializeCallback` 里设置），进而 `Node` 在回调中执行 `RunChilds()`：减少子节点 pending parent 计数，并当子节点 parent_done == parent_cnt 时触发子节点 `Run()`。
     - 若 functor 是异步执行（`support_async()` true 或 Run 内部异步），则 `Run()` 返回后实际完成将由 functor 在内部异步 I/O 完成后调用其回调，回调会最终触发 `Node` 的 `RunChilds()`。
7. children node 依次执行，整个 DAG 并发推进，直到所有节点都完成。Graph 维护 `end_done_cnt_`，在全部节点完成时会调用 `end_cb`（通常这个 `end_cb` 会触发 executor 的 `RunFinishJob()`）。
8. 在 `end_cb`（DAG 完成）中：
   - `executor->RunFinishJob()` 被调用，执行 `finish_jobs_`（一些 reporter 等），这些 reporter 可能将数据写入 response、或做异步上报（Kafka、Prometheus）。
   - 将最终的 response 写回给上层（gRPC resp writer），并释放/归还 executor 到池。
9. 返回客户端响应（并发/异步处理由 server layer 与 executor 配合实现超时管理、错误处理）。

---

##### 细化：常见的 Functor 类型与行为

常见 Functor 类型（代码库中可以看到很多实现）：
- Recaller（召回器）：产生候选 item 列表（`Accessor::AddRecallItem`），通常会调用外部召回服务（KV 模型、ES、havnask、FAISS 等）。可能会是异步（network)。
- Arranger / Merger（编排/合并器）：把多个 recaller 的候选合并、去重、按策略混排，并产生下一阶段的 item 列表（例如 `kFeaGMergerItem / kFeaGMatchItem` 等）。
- Extractor（特征提取）：给候选补充 item-level 或 ctx-level 特征（可能调用 item feature 服务）。
- RebuildArranger（重构器）：对候选集做更复杂的重构（例如位置相关调整），并可能输出给 rebuild_accessor。
- Rank / Rerank：排序模型（可能调用在线/离线模型服务）给 item 打分并排序。
- Reporter（上报器）：生成埋点、监控或响应中需要的可解释字段。通常作为 `finish_jobs_` 或在特定 stage 后触发。

每个 Functor 与 Accessor 的典型交互：
- 读取：`Accessor::Get...FeaturePtr()` 获取 input 特征，或读取 prior stage 产出的 item 列表 `Accessor::GetRecallItem(strategy_id)`.
- 写入：`Accessor::AddRecallItem`, `Accessor::AddCtxFeature`, `Accessor::AddItem...`。
- 上报：`Accessor::AddCtxMonitorV2`、`AddErrorReport` 等。

##### 代码与业务场景举例

- MergeArranger 的行为（在 `StrategyAnalyzer::BuildFunctors` 中被特别处理）：
  - 如果规则中配置了一个 Merger（例如合并多路召回），`BuildFunctors` 会把 merger 所需的 recall 策略自动加进 `functors_` 并把 recall 的 `merge_tag`、`recall_num`、`disable_deduplicate` 等字段设置好，接着把 `kv_model_helper_` 和 `es_batch_helper_` 的 `AddExpectCount` 调整为预期并发/调用数值，预分配资源。
  - 业务意义：Merger 在运行时期待来自不同 recaller 的候选，Analyzer 在构造阶段就把这些 recaller 插入并配置好，Graph 运行时会先触发各 recaller 并把结果合并后交给 Merger。

- Rebuild 场景：
  - 当 `has_rebuild_` 为 true 时，Analyzer 会为部分算子使用 `rebuild_accessor_`（而非主 accessor）。业务上这是当需要“先做一个完整的预处理/补全、然后在主流程里应用”时的分支。举例：先在 rebuild accessor 上做 prerank/重构，然后把结果回写到主 accessor。

- Finish Job（上报）：
  - `finish_jobs_` 中包括 `ExplainReporter`、`SvrMarkReporter`、`StrategyReporter` 等。这些算子通常写入 `Accessor` 的 response 字段或将监控/trace 推送到 Kafka。业务上这是“把本次请求的埋点/可解释信息/统计指标输出”的步骤，通常不影响用户看到的推荐结果但对离线分析和监控至关重要。

---



## 3. 数据准备

### 要点
- 初始节点读取的数据都来自 `Accessor`（每个请求唯一的上下文对象）。  
- `Accessor` 在请求进入时由 `Accessor::Bind(...)` 填充：把请求里的上下文特征（context）、请求携带的 item 列表（RecMsg / RecommendRequest）和部分预置的 item 特征（score、location 等）写入 `Accessor`。具体实现见 accessor.cc 的 `Bind` / `BindRecGoods` / `BindSrchGoods`。  
- `Graph::Run` 把所有 ParentCount==0 的节点当作 start node，调度到 `StrategyAsyncPool::Async(...)` 执行；这些节点运行时通过持有的 `Accessor*` 读入初始化数据（通过 `GetCtxFeature*`、`GetOriginItemFeaturePtr`、`GetRecallItem` 等接口）。  
- 有些算子并不依赖事先填好的数据，而是在 `Run()` 中发起异步召回/外部 RPC，结果在回调里写回 `Accessor`（例如调用 `AddRecallItem` / `AddRecallItemFeature`），回调完成后再触发子节点执行。

#### 举个例子
- 请求里有 item list：
  - `Accessor::Bind(...)->BindRecGoods(...)` 会调用：
    - `AddItem(...)` 把每个 `Item` push 到 `origin_items_` / `entity_items_`，并且
    - `AddItemFeature(kFeaGLocation, feature::FeatureFactory::CreateVector<int64_t>(g_loc));` 等把位置/分数写入 `item_feature_`。
  - 对应节点（比如 arranger）在 `Node::Run()` 里会调用 `functor_->PrepareRun(accessor_)` / `functor_->Run(accessor_)`，在 functor 内部通过 `accessor_->GetOriginItemFeaturePtr(kFeaGLocation)` 读取这些数据。
- 召回算子：
  - Analyzer 可能为某些策略预置一个 recall 槽（`AddRecallItemFeature(strategy_id, "", nullptr)`），但没有数据；
  - 当 recall 算子运行时，它发起外部召回，回调里执行 `accessor_->AddRecallItem(...)` / `accessor_->AddRecallItemFeature(...)`，然后触发 functor 的回调，子节点就能在 `Accessor` 中看到召回结果。

### Functor 算子

#### Functor 在整个系统中的角色
- Functor 是「策略算子（strategy operator）」的抽象。每个策略（strategy）在执行图（Graph → Node）中由一个 Functor 实例来执行具体逻辑（召回、粗排、重排、合并、上报等）。  
- 一个 request 有一个 `Accessor`（请求上下文），Analyzer 会为每个策略创建 Functor，并构建成 DAG 的 Node。Graph 调度时会调用 Functor 的 `PrepareRun`/`Run`，Functor 执行完后通过回调告知 Graph/Node 继续走下游。
- 设计目标：把“业务算子逻辑”与“执行调度/异步框架”分离。Functor 负责业务（读写 `Accessor`、发 RPC、生成特征等）；Node/Graph/AsyncPool 负责调度与并发。

#### Inputs/Outputs/Error
- 输入：`Accessor* accessor`（请求级上下文、已有 item、已有特征） + Functor 自身的 strategy_id、param。  
- 输出：把结果写回 `Accessor`（例如：`AddRecallItem`, `AddRecallItemFeature`, `AddItemFeature`, `AddCtxFeature`），并触发它的 callback（由 Node 设置）。  
- 成功 / 完成信号：当一个 Functor 完成其业务（同步或异步），必须保证 Node 中为其设置的回调最终被执行一次（通过 `GetCallback()`）。  
- 错误模式：若缺少必要数据，应走降级（若 `has_degrade_run()` 为真）或记录错误并尽可能触发回调以不中断 DAG。

#### Functor 类关键字段与作用
- dsl_helper_ (unique_ptr<DslHelper>)：用于 DSL 类型的特征生成 / 处理。很多 Functor 用 DSL 来生成或校验特征。
- std::atomic<bool> has_run_{false}：保护 callback 只执行一次（`GetCallback()` 内部用它做 dedup-check 并在重复调用时报错日志）。
- Callback cb_ / empty_cb_：cb_ 是实际回调（由 Node::InitializeCallback 设置为：Report + RunChilds），empty_cb_ 是安全兜底。
- bool is_async_ / support_async()：标注该算子是否按“异步语义”执行。`is_async_` 是运行时标记，`support_async()` 是子类可覆盖的 capability（是否能自己在内部调用 cb）。
- strategy_id_, functor_name_, stage_：策略标识与阶段（RECALL/PRERANK/…）等，用于路由/日志/度量。
- required_* / output_* / report_* name sets：声明输入输出特征名，Analyzer 在构建阶段会用到这些声明来决定依赖与预置。
- dsl_effect_generater_、local_ctx_feature_：用于 DSL 的“是否生效”判断与中间特征上报。

#### Node/Graph 与 Functor 的交互
1. Analyzer 构建 Functor 实例并通过 Graph::AddNode 将 Functor 放在 Node 中。Node 在构造后会调用 `InitializeCallback()` 设定 functor 的 cb（cb 做 Report + RunChilds）。  
2. Graph::Run 把所有无父节点的 Node 提交给 AsyncPool 执行（start nodes）。  
3. Node::Run 调用：PrepareRun -> 考察是否 AllowRun / IsStrategyEffect -> 若 functor 需要 DSL 可能调用 `GenerateFeature` -> 根据 `is_async()` 和 `support_async()` 选择：
   - 同步：`functor_->Run(accessor_)` 执行并返回；Node 接着调用 `functor_->GetCallback()()` 来完成节点（Report + 子节点触发）。
   - 异步：`functor_->Run(accessor_)` 发起异步 RPC/操作，Functors 自己在 RPC 的完成回调里写回 `Accessor` 并调用 `GetCallback()`，Node 不直接调用回调。
4. 子节点在其 parent 完成后通过 `parent_done_cnt_` 控制何时真正执行（并被 AsyncPool 再次调度执行）。

#### 常见使用场景与派生类模式（按推荐系统阶段）
- Recall（召回）算子（通常异步）：
  - 功能：从外部召回服务获取 candidate ids + score；把结果写到 `accessor->AddRecallItem(...)` 或 `AddRecallItemFeature(...)`；然后调用 `GetCallback()`。
  - 特点：通常大量异步 RPC，需要批量/限流/timeout 管理；support_async() 返回 true。
  - 示例：调用 `AsyncQueryItemFea` 或直接使用 client.Async(...)，在 RPC 回调中写回并 `GetCallback()`。
- Arranger / Merger（合并、粗排、编排）算子（通常同步）：
  - 功能：基于已有 `Accessor::item_feature()` 做排序、过滤或合并位置（kFeaGLocation、kFeaGScore 等）；写回 `AddItemFeature(kFeaGLocation, ...)` 等。
  - 特点：通常是 CPU-bound，同步执行，Node 在 Run 后会马上调用 callback。
- Prerank / Rank / Rerank（模型调用）：
  - 可能是同步或异步，视模型客户端是否是异步 RPC；若为 RPC → 通常是异步（support_async true）并在 RPC 回调里写回模型输出并调用 `GetCallback()`。
- Reporter：几乎是同步，做监控/上报，不改变核心执行流（见你 repo 的 `Reporter` 已实现）。

#### DSLHelper 与特征生成
- Functor 构造时创建了 `DslHelper`（见 functor.h 中 dsl_helper_），并提供 `InitDslHelper(...)` 接口。DSL 用于按规则生成特征或判定生效。  
- Node::Run 中的逻辑：
  - 若 functor_->dsl_helper()->need_dsl() 且 `call_fmp` 的配置为某种情况，`GenerateFeature` 可能会把 callback 嵌入到 DSL 的执行流程中（即 DSL 本身执行完毕后会触发 callback），Node 里会根据 `functor_run` 决定是否需要再显式调用 callback。也就是说 DSL 能把部分完成信号内嵌在 functor 执行中，需要注意不要重复触发回调。


#### 设计层面的理解
- Recall：获取候选集（外部召回服务）→ 写回 `Accessor::recall_items_`（异步或批量）。  
- Arranger / Merge：合并来自多个召回 / 重排位置 / 去重 / 打分（通常 sync，操作 `item_feature_` 和 `origin_items_`）。  
- Prerank / Rank：调用模型做粗排/精排（可能是 RPC，通常异步），把模型输出写回 `Accessor` 的 output map。  
- Rerank / Report：后处理与上报（同步或轻量异步），记录度量。

## 4. 数据绑定到执行
### 4.1 Accessor::Bind

- 输入：
  - `rec_msg_req`：请求（`api2::RecMsg*`），包含 context、user、item 列表、srch_request（可选）等。
  - `rec_msg_rsp`：输出响应的 protobuf 指针，供后续填充。
  - `strategy_ids`：策略 id 列表（可修改，后续 `ParseInterleavingRule` 可能会插入 interleaving 策略）。
- 输出：
  - 返回 bool（本函数实现总是返回 true，除非中间抛异常），同时会把大量请求相关的数据填充进 `Accessor` 的成员（`rec_msg_req_`、`rec_msg_rsp_`、`ctx_feature_`、`item_feature_`、`origin_items_` 等）。
- 目的：
  - 将外部请求解包并初始化请求级上下文（Accessor），为后续 Analyzer/Graph/Functor 执行提供所需信息。

---

#### 逐段说明

1) 绑定请求指针与基础字段（成员赋值）
```cpp
rec_msg_req_ = rec_msg_req;
rec_msg_rsp_ = rec_msg_rsp;
debug_mode_ = rec_msg_req->context_msg().debug_mode();
svr_mark_mode_ = rec_msg_req->context_msg().svr_mark_mode();
rec_mark_mode_ = rec_msg_req->context_msg().rec_mark_mode();
item_type_ = rec_msg_req->context_msg().item_type();
item_source_ = rec_msg_req->context_msg().item_source();
req_source_ = rec_msg_req->context_msg().req_source();
scene_id_ = rec_msg_req->context_msg().scene_id();
trace_id_ = rec_msg_req->trace_id();
step_id_ = rec_msg_req->context_msg().step_id();
site_id_ = rec_msg_req->context_msg().site_id();
site_uid_ = rec_msg_req->context_msg().site_uid();
request_id_ = rec_msg_req->context_msg().request_id();
request_time_ =  rec_msg_req->context_msg().request_time();
error_log_enable_ = rec_msg_req->context_msg().log_mode();
poskey_ = rec_msg_req->context_msg().poskey();
auto& dev_id = rec_msg_req->user_msg().device_id();
auto& cookie_id = rec_msg_req->user_msg().cookie_id();
trace_key_ = std::to_string(scene_id_) + "_" + trace_id_;
SPDLOG_SET_TRACE_INFO(trace_id_, std::to_string(scene_id_), std::to_string(item_source_), step_id_);
```
- 做了什么：把 `rec_msg_req`/`rec_msg_rsp` 存入内部成员；把 request header/上下文的常用字段抽取到 Accessor 成员（如 scene、trace、site、item_type、item_source、step、request_time、poskey 等）；计算 `trace_key_`（scene_id_traceid）并设置日志追踪上下文（宏 `SPDLOG_SET_TRACE_INFO`）。
- 作用：后面代码以及其他组件会读取这些成员；`rec_msg_rsp_` 被保存以便 later 填充响应字段。
- 注意：没有对 `rec_msg_req`/`rec_msg_rsp` 做空指针检查（假设调用方保证非空）。

2) 填充若干上下文特征（context features）
```cpp
AddCtxFeature("mid", rec_msg_req->user_msg().mid());
AddCtxFeature("devid", rec_msg_req->user_msg().device_id());
AddCtxFeature("cookie_id", rec_msg_req->user_msg().cookie_id());
AddCtxFeature("ugid", rec_msg_req->user_msg().ugid());
AddCtxFeature("language_flag", rec_msg_req->context_msg().language_flag());
AddCtxFeature("request_id", request_id_);
AddCtxFeature("user_id", cookie_id.empty() ? dev_id : cookie_id);
AddCtxFeature("poskey", poskey_);
```
- 做了什么：将常用的用户/设备/语言/请求 id 等信息包装成 `ctx_feature_`（通过 `AddCtxFeature`，它会加写锁并把值放到 `ctx_feature_`）。
- 目的：使 Functor/Analyzer 可以通过 `GetCtxFeature` 快速访问。

3) 保存原始 context map 与 user profile 引用、清零阶段计数
```cpp
raw_ctx_ = &rec_msg_req->context_msg().context_map();
raw_user_profile_ = &rec_msg_req_->user_msg().user_profile();
stage_expect_cnt_.fill(0);
stage_success_cnt_.fill(0);
```
- 做了什么：保持对原始 protobuf map 的 const 指针（便于 later 需要原始 string map 时直接访问），并将 stage 的计数器重置为 0。
- 注意：`raw_ctx_` 指向外部 protobuf 存储，不能在请求销毁后使用。

4) 处理 srch_request 特殊路由情况（300 场景）
```cpp
const bool use_srch_request = (scene_id_ == 300 && rec_msg_req->has_srch_request());
const auto& req_context_map = use_srch_request ? rec_msg_req->srch_request().context() : rec_msg_req->context_msg().context_map();
for (const auto& p: req_context_map) {
    AddCtxFeature(p.first, p.second);
    // 处理 goods_id/top_goods_id 特殊字段 -> 衍生 main_goods_id/top_goods_id
    // 处理 ctrl_white_list 字段，拆分并插入 ctrl_white_list_ 集合
}
```
- 做了什么：如果是特定场景（scene_id == 300）并且请求里有 `srch_request`，则从 `srch_request` 的 context 读取 context map；否则读取普通 context_map。然后把每个 key/value 加入 `ctx_feature_`。对 `goods_id`/`top_goods_id` 另外生成派生字段（main_goods_id(s)），并对 `ctrl_white_list` 做逗号分割后填入集合 `ctrl_white_list_`。
- 目的：兼容路由类型请求，保持字段来源正确。

5) 复制额外的 trans/scene 参数
```cpp
for (const auto& p: rec_msg_req->context_msg().trans_ctx_feature()) {
    AddCtxFeature(p.first, p.second);
}
for (const auto& kv: rec_msg_req->context_msg().scene_info().svr_param()) {
    AddCtxFeature(kv.first, kv.second);
}
for (const auto& kv: rec_msg_req->context_msg().scene_info().str_svr_param()) {
    AddCtxFeature(kv.first, kv.second);
}
```
- 做了什么：把转发的 context 特性 & scene 的 server 参数全部注入到 `ctx_feature_`。
- 作用：增加更多可能被策略/feature 映射使用的上下文键。

6) 解析 interleaving（插屏/插入）规则并可能修改策略列表
```cpp
ParseInterleavingRule(rec_msg_req, strategy_ids);
```
- 做了什么：分析请求中的 interleaving 规则（`interleaving_rule()`），并根据规则在 `strategy_ids` 中插入对应的 interleaving 策略、fuse 算子或其它辅助策略（见实现：插入 `kGlobalInterleavingCombineId`、inl_fuse、further_fuse 等），同时填充 `inl_id_mp_`、`inl_name_mp_`、`inl_sid_mp_` 等映射。
- 目的：确保策略序列包含 interleaving 所需的算子并记录映射关系以供后续 `BindStrategyId`/functor 处理。
- 注意：此方法会修改 `strategy_ids`（传入的是引用），所以后续基于该列表的逻辑会使用修改后的顺序/内容。

7) 根据 svr_mark_mode 设置全量埋点模式
```cpp
if (rec_msg_req->context_msg().svr_mark_mode() == 2) {
    set_svr_mark_full_mode(true);
}
```
- 作用：当后端埋点模式为 2 时，启用 `svr_mark_full_mode_`（影响后续上报字段）。

8) 解析 user profile tags 并把 tag 加入 ctx feature
```cpp
int has_user_profile = 0;
for (const auto& tag: rec_msg_req->user_msg().user_profile().tags()) {
    const auto key = "user_" + std::to_string(tag.hkey());
    auto fea = feature::FeatureFactory::CreateVector<int64_t>(tag.value().values());
    AddCtxFeature(key, fea);
    has_user_profile = 1;
}
AddCtxFeature(kHasUserProfile, has_user_profile);
```
- 做了什么：把用户 profile tags（每个 tag 有 hkey/value）转成特征 vector 并保存为 `user_<hkey>` 的 ctx feature，同时设置 `kHasUserProfile` 标志（1/0）。
- 目的：为特征抽取/召回器提供用户画像特征。

9) 把请求中 `trans_item_feature`（预先带上来的 item group features）添加到 group_data（用于 `GetItemFeatureImpl`）
```cpp
for (const auto& kv: rec_msg_req->item_msg().trans_item_feature()) {
    fmp::FeatureGroupData gdata(kv.second);
    AddItemFeature(std::move(gdata));
}
```
- 做了什么：将外部携带的 item group feature（结构化的 group）合并到 `group_data_vec_`，并在 `feature_pos_map_` 中登记位置元信息（`AddItemFeature(fmp::FeatureGroupData&&)` 会更新 `feature_pos_map_`）。
- 后续意义：`GetItemFeatureImpl` 可以从这些 group 数据中按 item idx 抽取 item-level features。

10) 根据是否是 search route 决定如何填充 item 列表（调用 BindSrchGoods 或 BindRecGoods）
```cpp
if (use_srch_request) {
    if (debug_mode_) {
        AddCtxExplain("srch_req", "srch_req", feature::FeatureFactory::CreateSingle<std::string>(rec_msg_req->srch_request().ShortDebugString()));
    }
    BindSrchGoods(rec_msg_req); // 路由传参接口进行 item 的赋值
} else {
    BindRecGoods(rec_msg_req);  // 推荐接口 item 的赋值
}
```
- 做了什么：如果是 search 路由（use_srch_request），把 srch_request 提供的 recall_goods 解析为 internal `Item` 列表（通过 `BindSrchGoods`）；否则通过 `BindRecGoods` 从通用 `item_msg` 填充。
- `BindRecGoods/BindSrchGoods` 会：
  - 遍历 item 列表，创建 `Item`（id, score, item_source 等），调用 `AddItem` 把它加入 `entity_items_`、`origin_items_`、`arranged_items_`；
  - 创建若干 item-level 特征（例如 GScore、GLocation、GMixItemSource、GLayer 等）并放入 `item_feature_`（通过 `AddItemFeature`）。

11) 再次添加多个关键 ctx 特征（注意顺序重要）
```cpp
AddCtxFeature("trace_id", rec_msg_req->trace_id());
AddCtxFeature("scene_id", rec_msg_req->context_msg().scene_id());
AddCtxFeature("step_id", rec_msg_req->context_msg().step_id());
AddCtxFeature("site_id", rec_msg_req->context_msg().site_id());
AddCtxFeature("site_uid", rec_msg_req->context_msg().site_uid());
AddCtxFeature("item_source", rec_msg_req->context_msg().item_source());
AddCtxFeature("item_type", rec_msg_req->context_msg().item_type());
AddCtxFeature("req_num", rec_msg_req->context_msg().req_num());
AddCtxFeature("req_source", rec_msg_req->context_msg().req_source());
AddCtxFeature("language", rec_msg_req->context_msg().language_flag());
AddCtxFeature("member_id", rec_msg_req->user_msg().mid());
AddCtxFeature("item_source_req", std::to_string(rec_msg_req->context_msg().item_source()));
std::unordered_map<int64_t, std::string> rule_map(rec_msg_req->context_msg().rule_map().begin(), rec_msg_req->context_msg().rule_map().end());
AddCtxFeature("rule_map", feature::FeatureFactory::CreateFeatureMap(std::move(rule_map)));
```
- 做了什么：填充更多上下文 key/values。把 `rule_map`（int64 -> string）转为 `FeatureMap` 并加入 `ctx_feature_`。
- 注：代码注释特别提醒“顺序不能随意调整”，因为上面某些字段的类型/存在会影响后续逻辑或 feature 映射。

12) 分割策略集合到 scene/hp 参数集合
```cpp
SplitHpAndScene(strategy_ids);
```
- 做了什么：把 `strategy_ids` 列表按某些切换算子（`kSceneSave`, `kHpSave`）分为 `scene_param_ids_` 与 `hp_param_ids_` 两组（用于后续策略参数分组）。

13) 上下文映射、填充默认、特征映射设置、构建 trace 字符串
```cpp
SetupCtxMapping(rec_msg_req);
PaddingCtxFeature();
SetupFeatureMapping();
BuildTraceMsg();
```
- `SetupCtxMapping`：把一些常用字段存入 `req_fea_val_map_`（用于后续 feature mapping lookup），比如 user_id、scene_id、site_id、language 等。
- `PaddingCtxFeature`：保证某些 ctx keys 存在（page_cate、device_model 等），避免 later 访问为空。
- `SetupFeatureMapping`：基于某些 raw features（site_uid、cate 等）查询 kv 映射表（`DataAutoApi::GetKVModelFromPVC`），把映射结果写回到 ctx_feature（例如 site_country）并更新 `req_fea_val_map_`。
- `BuildTraceMsg`：构造一条简短的 trace 字符串 `request_trace_msg_`。

14) 把策略按 class 分类并生成相应 ctx feature（AddClassifiedStrategyIds）
```cpp
AddClassifiedStrategyIds(strategy_ids);
```
- 做了什么：通过 DataAutoApi 获取每个策略的 `StrategyParam`，把同类型（functor name）策略聚集成列表，然后把这些列表作为 ctx feature 写入，方便 Functor/Analyzer 以类型为单位读取策略列表。

15) 解析并注入以 `kParamPrefix` 开头的策略参数为 ctx feature
```cpp
for(const auto& param : strategy_ids) {
    auto it = std::find_if(kParamPrefix.begin(), kParamPrefix.end(),
        [&param](const std::string& prefix) { return boost::starts_with(param, prefix);});

    if (it != kParamPrefix.end()) {
        std::vector<std::string> param_val;
        boost::split(param_val, param, boost::is_any_of(":"));
        if (param_val.size() == 2) {
            AddCtxFeature(param_val[0], param_val[1]);
        }
    }
}
```
- 做了什么：对于以某些前缀（kParamPrefix）开头的策略 id，如 `foo:bar` 形式，把 `foo`=`bar` 注入到 ctx_feature（把策略参数变成 ctx-level 参数）。

16) 最终把经过处理的策略 ids 存到 `strategy_ids_`
```cpp
strategy_ids_ = strategy_ids;
```
- 副作用：Executor/Analyzer 会用 `accessor_->strategy_ids()` 或 `StrategyExecutor` 中的 `strategy_ids_`（注意 StrategyExecutor 在 Bind 前可能已经有自己的 list）。

17) 特殊实验判断（南京精排）与高效监控标志
```cpp
if ((item_source_ == api2::ItemSource::CLEAR || item_source_ == api2::ItemSource::TRAFFIC)
    && scene_id_ == 105) {
    AddCtxFeature("is_nanjing_rank", 1);
}
set_high_efficiency_monitor_flag(GetCtxFeature<fmp::STRING>("recplt_high_efficiency_enable", "0") == "1");
```
- 做了什么：基于 item_source 与 scene_id 判断并设置 `is_nanjing_rank`，并读取 control/dynconf 参数决定是否启用高效监控标志。

18) 预分配和初始化 response protobuf 的一些结构（避免并发写造成问题）
```cpp
// protobuf 不是线程安全的, 多线程写不同字段会丢数据，预先分配map槽位就OK
rec_msg_rsp_->mutable_item_msg()->mutable_trans_item_feature()->insert({item_source(), {}});
rec_msg_rsp_->mutable_trace_msg()->add_error_code(0);
```
- 做了什么：向 `rec_msg_rsp_` 的 `trans_item_feature` map 插入一个空条目（key 为 `item_source()`），以及在 trace_msg 中加入一个 error_code = 0。目的是预先分配 map 的槽位，降低后续多线程写同一 pb 时的数据丢失风险（注释已说明：protobuf 非线程安全，预分配 map 槽位可缓解部分并发写问题）。
- 注意：这只是减缓并发问题，不能完全保证线程安全；对 protobuf 的并发写仍需谨慎（最好由单个线程负责写 response 或在锁内写）。

19) 返回 true
```cpp
return true;
```
- 说明：Bind 执行完成，Accessor 已被初始化好供后续阶段使用。

---

### 4.2 StrategyExecutor::AsyncDAG流程分析

```cpp
bool StrategyExecutor::AsyncDAG(std::function<void()>&& cb) {
    if (!analyzer_->BuildDAG(strategy_ids_)) {
        accessor_->AddErrorReport("strategy-error", "BuildDAG fail", "BuildDAG fail");
        COLLECT_MONITOR(service_comm::MONITOR_STRATEGY_ENGINE, "error:build_dag_fail", STRATEGY_ENGINE);
        cb();
        return false;
    }
    if (accessor_->debug_mode()) {
        std::stringstream gos;
        graph_->Dump(gos);
        LOG_DEBUG << "graph:" << gos.str();
        accessor_->AddCtxExplain("graph", "DAG", gos.str());
    }
    auto [has_loop, err_msg] = graph_->HasLoop();
    if (has_loop) {
        accessor_->AddErrorReport("executor", "DAG graph has loop, " + err_msg, "graph_loop");
        COLLECT_MONITOR(service_comm::MONITOR_STRATEGY_ENGINE, "error:dag_loop", STRATEGY_ENGINE);
        cb();
        return false;
    }
    return graph_->Run(std::move(cb));
}
```

`AsyncDAG` 的职责是：用 `analyzer` 把 strategy id 列表构造成 DAG，做简单校验（debug dump / 环路检测），在失败时同步调用回调并上报监控，成功时把回调转交给 `graph_->Run` 异步执行并返回 `graph_->Run` 的布尔结果。

- 输入
  - cb: std::function<void()> 回调，期望在 DAG 执行结束（或失败早退）时被调用。
  - 使用到的成员：`analyzer_`, `graph_`, `accessor_`（用于 debug / 上报）。
- 输出
  - 返回 bool：true 表示已把执行交给 Graph（通常表示成功启动 DAG）；false 表示构建/校验失败且回调已被同步调用。

#### 4.2.1 StrategyAnalyzer::BuildDAG

```cpp
bool StrategyAnalyzer::BuildDAG(const std::vector<std::string>& strategy_ids) {
    if (strategy_ids.empty()) {
        LOG_ERROR << "strategy_ids is empty";
        return false;
    }
    if (!BuildFunctors(strategy_ids)) {
        LOG_ERROR << "BuildFunctors fail";
        return false;
    }
    if (!BuildDependent()) {
        LOG_ERROR << "BuildDependent fail";
        return false;
    }
    if (!BuildGraph()) {
        LOG_ERROR << "BuildGraph fail";
        return false;
    }
    return true;
}
```

##### 1. StrategyAnalyzer::BuildFunctors

`BuildFunctors` 的任务是：遍历上游传入的 strategy id 列表，按规则把每个 strategy 对应的 Functor 创建/绑定并组织到分析器的 `functors_` 列表中；同时为合并器（merger）收集并绑定它依赖的 recall 策略，配置 KV/ES helper 的预期数量，处理“further merge”的默认插入，最后生成额外的 finish/监控/ItemFea extractor 等内置 functor 并把它们合并到最终的 `functors_` 顺序列表中。

###### 逐段、逐行解释

1) 初始化和局部变量
```cpp
std::unordered_set<std::string> strategy_set;
std::vector<std::string> merge_strategys;
Functor* further_merge{nullptr};
Functor* recall_filter{nullptr};
size_t merge_count{0};
bool has_recall_item_fea{false};
const auto accessor = strategy_executor_->GetAccessor();
```
- 建立一组 `strategy_set` 防止重复处理同一 strategy id。
- `merge_strategys` / `merge_count` 用于收集遇到的 `MERGER_ARRANGER` 类型策略，以便后续处理 further_merge。
- `further_merge`：后续可能插入的进一步合并器（further merger）。
- `recall_filter`：用于 DSL-filter arranger 时可能需要的 filter 合并器实例。
- `has_recall_item_fea`：标记是否有 recall 阶段的 functor 需要原始 item feature。
- `accessor`：每次 BindStrategyId 时传入的 init accessor（用于内联策略等）。

2) 主循环：遍历 `strategy_ids`
```cpp
for (const auto& strategy_id: strategy_ids) {
    if (strategy_set.count(strategy_id)) continue;
    strategy_set.insert(strategy_id);
    auto functor = strategy_executor_->BindStrategyId(strategy_id, accessor);
    if (!functor) { LOG_DEBUG ...; continue; }
    if (!strategy_executor_->controller_->AllowBuild(functor)) { LOG_DEBUG ...; continue; }
```
- 去重：如果 strategy 已处理则 skip。
- 通过 `BindStrategyId` 去 executor 申请并初始化 Functor（详见 `BindStrategyId`：会从 pool 取出 functor、Bind param、设置 stage、可能标记为 interleaving 等）。
- 如果 `BindStrategyId` 失败就跳过该 id（通常会记录 error）。
- 再询问 `StrategyController::AllowBuild(functor)`，决定 run-time control 是否允许把这个 functor 构建进 DAG（控制参数/AB test 等影响）。

3) 拒绝某些类型在此处被直接配置（配置错误）
```cpp
if (functor->Type() == FunctorType::RECALLER
    || functor->Type() == FunctorType::KV_MODEL_RECALLER
    || functor->Type() == FunctorType::ES_RECALLER
    || functor->Type() == FunctorType::HA3_RECALLER) {
    strategy_executor_->GetAccessor()->AddErrorReport(strategy_id, "dont configure in rules");
    continue;
}
```
- 如果规则里直接把 recaller 类型放在入口策略列表中，这里视为错误（应通过 merger 的 recall options 来连接），记录错误并跳过。

4) 处理 MERGER_ARRANGER（合并器）分支（较复杂）
```cpp
} else if (functor->Type() == FunctorType::MERGER_ARRANGER) {
    ++merge_count;
    merge_strategys.push_back(strategy_id);
    int kv_model_cnt = 0, es_cnt = 0, ha3_cnt = 0;
    auto merger_functor = static_cast<MergeArranger*>(functor);
    auto accessor = AdaptAccessor(merger_functor);
    auto disable_fea = merger_functor->GetDisableStrategyRuntime(accessor);
    auto disable_sids = feature::CastFeature<fmp::LIST_STRING>(disable_fea);
    if (disable_sids) {
        const auto& data = disable_sids->data();
        strategy_set.insert(data.begin(), data.end());
    }
    auto exclude_recall_id_fea = merger_functor->GetExcludeRecallIdFea();
    for (const auto& p: merger_functor->GetRecallOptions()) {
        const auto& recall_sid = p.first;
        const auto recall_num = p.second.recall_num;
        if (strategy_set.count(recall_sid)) { continue; }
        strategy_set.insert(recall_sid);
        if (!strategy_executor_->BindStrategyId(recall_sid, accessor)) { LOG_ERROR ...; continue; }
        auto recall_functor = strategy_executor_->GetFunctor(recall_sid);
        // type check must be recaller-like, set merge_tag and set helper pointers/counters accordingly
        functors_.push_back(recall_functor);
        strategy_executor_->GetAccessor()->AddRecallItemFeature(recall_sid, "", nullptr);
    }
    strategy_executor_->GetAccessor()->AddRecallItemFeature(strategy_id, "", nullptr);
    strategy_executor_->kv_model_helper_->AddExpectCount(kv_model_cnt);
    strategy_executor_->es_batch_helper_->AddExpectCount(es_cnt);
    strategy_executor_->es_batch_helper_->AddExpectCount(ha3_cnt);
}
```
解释要点：
- 遇到 Merger：把 merger 自身计数并记录其 id。
- `AdaptAccessor(merger_functor)`：为 merger 取得合适的 Accessor（普通或 rebuild 版），用于 Bind 其依赖 recall 的 init accessor。
- `GetDisableStrategyRuntime`：merger 可以通过配置返回一组 disable IDs，这里把它们加入 `strategy_set`（跳过这些 recall）。
- 遍历 `merger_functor->GetRecallOptions()`：这些是 merger 在配置里声明要召回的子策略（recall_sid）。
  - 对每个 recall_sid：去 `BindStrategyId(recall_sid, accessor)`，把对应的 recaller 绑定并取回 raw pointer。
  - 对不同类型的 recaller（KV_MODEL_RECALLER / ES_RECALLER / HA3_RECALLER / others），做不同初始化：
    - KV recaller：给 `KVModelHelper` 指针并设置 recall_num、disable_deduplicate、merge_exclude_recall_id_，并增加 kv_model_cnt。
    - ES recaller / HA3 recaller：给 `EsBatchHelper` 指针并设置参数，相应增加 es_cnt/ha3_cnt。
  - 把 recall_functor push 到 `functors_`（注意：functors_ 顺序会影响后续 DAG 排序）。
  - 调用 `GetAccessor()->AddRecallItemFeature(recall_sid, "", nullptr)` 来预建 recall map（注释说“pre build recall map to avoid thread safe issue”）。
- 对 merger 本身也调用 `AddRecallItemFeature`。
- 最后，把计数告诉 kv/es helper（`AddExpectCount`），帮助 batching helper 预估/分配资源。

5) FURTHER_MERGER_ARRANGER 处理
```cpp
} else if (functor->Type() == FunctorType::FURTHER_MERGER_ARRANGER) {
    if (further_merge && strategy_id.find("ratio_quota_fmerge") == -1) {
        LOG_ERROR << "strategy:" << strategy_id << " further merge has one";
        continue;
    }
    further_merge = functor;
    continue;
}
```
- 遇到 further merger：只允许一个 further_merge（除了特定名字例外），把它保存在 `further_merge` 中（稍后统一插入），并跳过把它立即 push 到 functors_（用 `continue`）。

6) ARRANGER 的特殊处理（DSL filter 并行化）
```cpp
} else if (functor->Type() == FunctorType::ARRANGER) {
    functor->SetOutputItemFeaName(kFeaGLocation);
    if (functor->SubType() == FunctorType::DSL_FILTER_ARRANGER) {
        auto add_filter = [this, accessor](auto& sid, auto& io_fea, Functor* functor, Functor*& filter) mutable { ... };
        if (functor->Stage() == FunctorStage::RECALL) {
            add_filter(kGlobalRecallFilterId, kFeaGRecallFilter, functor, recall_filter);
        }
    }
}
```
- 将 arranger 的输出 item feature 默认设置为位置类 `kFeaGLocation`。
- 对于 DSL_FILTER_ARRANGER：有 inline lambda `add_filter`，它负责：
  - 确保 `filter` 存在（会通过 `BindStrategyId(sid, accessor)` 创建全局 recall filter，如 `kGlobalRecallFilterId`）。
  - 如果 filter 存在且 can parallel，则把该 arranger 注册到 `UnionFilterArranger`（`AddFilterStrategy`），关闭该 arranger 的 arrange_item（由 filter 统一并行处理），设置 required 和 output item feature name，把 arranger 的默认输出 fea 从 `kFeaGLocation` 移除（`RemoveOutputItemFeaName`）。
- 该逻辑使多个 DSL filter 的 arranger 能并行复用单个 union filter。

7) 忽略 CONTROL_PARAM_EXTRACTOR 类型
```cpp
} else if (functor->Type() == FunctorType::CONTROL_PARAM_EXTRACTOR) {
    continue;
}
```
- Control param extractor 不进入 `functors_` 列表（可能已在 earlier controller.Bind 时运行或有特殊处理）。

8) push 普通 functor
```cpp
functors_.push_back(functor);
```
- 除去上面单独处理的分支，默认把 functor 加入本次构建的 `functors_` 列表。

9) 结束主循环后：further_merge 的默认创建逻辑
```cpp
if (!further_merge && merge_count > 0) {
    if (merge_count == 1) {
        further_merge = strategy_executor_->BindStrategyId(kGlobalQuotaFurtherMerge);
        static_cast<FurtherMergeArranger*>(further_merge)->set_disable_deduplicate(true);
    } else {
        further_merge = strategy_executor_->BindStrategyId(kGlobalWeightFurtherMerge);
    }
    if (!further_merge) { LOG_ERROR << "create default quota further merge error"; return false; }
    // functors_.push_back(further_merge);
}
if (further_merge) {
    auto further = static_cast<FurtherMergeArranger*>(further_merge);
    for (const auto& merge_strategy: merge_strategys) {
        further->AddMergeStrategy(merge_strategy);
    }
    functors_.push_back(further_merge);
}
```
- 如果之前没有显式 further_merge 但发现有 merge_count>0（存在 merger），则按 merge_count==1 或 >1 的规则创建一个默认 further_merge（quota 或 weight）。
- 如果创建失败会返回 false（表示构建失败，这里是唯一会导致函数直接失败的情况）。
- 若有 further_merge，则把所有 merge_strategy id 注册到 further->AddMergeStrategy(...)，并最终 push 进 `functors_`（注意：此处 commented 出 `functors_.push_back(further_merge);` 的注释和后面真正的 push）。

10) 收集依赖特征（dep_feas / rebuild_dep_feas）
```cpp
std::unordered_set<std::string> dep_feas, rebuild_dep_feas;
for (const auto functor: functors_) {
    const auto& req_item_feas = functor->GetRequiredItemFeaName();
    if (has_rebuild()) {
        if (functor->Stage() == FunctorStage::RECALL || functor->Stage() == FunctorStage::PRERANK) {
            dep_feas.insert(req_item_feas.begin(), req_item_feas.end());
        } else {
            rebuild_dep_feas.insert(req_item_feas.begin(), req_item_feas.end());
        }
    } else {
        dep_feas.insert(req_item_feas.begin(), req_item_feas.end());
    }
    std::vector<std::string> ori_item_feas;
    for (const auto& item_fea: req_item_feas) {
        if (IsOriginItemFeature(item_fea)) {
            ori_item_feas.emplace_back(item_fea);
            if (functor->Stage() == FunctorStage::RECALL) {
                has_recall_item_fea = true;
            }
        } else if (boost::starts_with(item_fea, kFeedsGoodsPrefix)) {
            const auto goods_fea = item_fea.substr(kFeedsGoodsPrefix.size());
            if (IsOriginItemFeature(goods_fea)) {
                ori_item_feas.emplace_back(goods_fea);
                if (functor->Stage() == FunctorStage::RECALL) {
                   has_recall_item_fea = true;
                }
            }
        }
    }
    if (!ori_item_feas.empty()) {
        AdaptAccessor(functor)->RecordStrategyOriFea(functor->strategy_id(), util::join(ori_item_feas, ","));
    }
}
```
- 对每个 functor 收集它们需要的 item 特征（用于后续决定是否需要添加 ItemFeaExtractor）。
- 当有 `has_rebuild()` 时，把 recall/prerank 的 req_feas 和 rebuild/后续的分开归类（优先避免重复请求）。
- 对于每个 req item fea，若是原始 item 特征（origin），把它记录到 `ori_item_feas` 并通过 `AdaptAccessor(functor)->RecordStrategyOriFea(...)` 记录策略对应原始特征名字（用于指标或预取）。
- 如果存在任何 recall 阶段要求原始 item fea，将 `has_recall_item_fea = true`，这会影响后面插入 ItemFeaExtractor 的阶段选择。

11) 追加内置 finish/monitor/ItemFeaExtractor 等 functor（extra_functors）
```cpp
std::vector<Functor*> extra_functors;
auto& data_api = model::DataAutoApi::get_mutable_instance();
const auto add_finish = [&](auto& name, auto& id, auto stage) { ... };
const auto add_functor = [&](auto& name, auto& id, auto stage) -> Functor* { ... };
const auto set_item_feas = [&](auto functor, auto& feas) { ... };
if (has_rebuild()) {
    // 添加一套以 rebuild 为主的 extra functors（SvrMarkReporter、ExplainReporter(->RANK)、ExplainReporter(->REPORT)、StrategyReporter、MonitorReporter、ResponseReporter、FeatureLandingReporter、TraceReporter）
    // 插入 RebuildArranger 并把 rebuild_accessor 关联
    // 决定 ItemFeaExtractor 的插入阶段（RECALL 或 PRERANK）并设置其 output/required fea
} else {
    // 添加没有 rebuild 场景下的一套 finish/monitor/reporters，ItemFeaExtractor 插入位置亦不同
}
extra_functors.insert(extra_functors.end(), functors_.begin(), functors_.end());
functors_.swap(extra_functors);
```
- `add_finish`：会先尝试 `BindStrategyId(id)`（即绑定现有策略），若无法绑定就尝试 `CreateFunctor(name,id)`（CreateFunctor 使用 `GetFunctorFromPool(name)` 并做 minimal Bind）。创建的 finish functor 被保存到 `strategy_executor_->finish_jobs_`（这些会在请求结束时被调用）。
- `add_functor`：类似但会把 functor push 到 `extra_functors`（用于实际执行流程）。
- `set_item_feas`：为 ItemFeaExtractor 设置 output item fea 名称，并在特殊 `kFeedsGoodsPrefix` 情况下设置 required fea。
- 根据 `has_rebuild()` 情况选取不同的内置 functors（有 rebuild 的分支会还会插入 RebuildArranger & 调用 `strategy_executor_->accessor_->Rebuild(...)` 来准备重构数据）。
- 最后把当前计算得到的 `functors_` 拼接到 `extra_functors` 前面，并把 `functors_` 置为 `extra_functors`（以确保内置的 reporter/monitor/featextractor 优先或按需要的顺序出现在最终列表）。

###### 关键点
- `BindStrategyId`：会分配/初始化 Functor 并在 `strategy_executor_` 的 `functor_resource_` / `functor_map_` 中注册（所以 functors_ 只是持有 raw 指针，实际所有权在 executor 的 pool/资源向量中）。
- 对 `kv_model_helper_`、`es_batch_helper_` 的 `AddExpectCount`：帮助 batch helper 预估/分配请求聚合的规模。
- `AddRecallItemFeature`：预建 recall map，注释说是避免线程安全问题（推测是为了在并发调用时保证 recall 所需的 map 已存在）。
- `RecordStrategyOriFea`：记录策略需要的原始 item 特征，便于上游为 item feature client 预取/统计。
- `finish_jobs_`：将某些 reporter/finish functor 放入 executor 的 finish jobs，稍后由 `RunFinishJob()` 执行（在请求生命周期最后）。

##### 2. StrategyAnalyzer::BuildDependent()

```cpp
enum FunctorStage {
    RECALL = 0,
    PRERANK,
    REBUILD,
    RANK,
    RERANK,
    REPORT,
    MAX_STAGE
};
enum FunctorType {
    FUNCTOR,
    EXTRACTOR,
    RECALLER,
    ARRANGER,
    REPORTER,
    MERGER_ARRANGER,
    FURTHER_MERGER_ARRANGER,
    DSL_FILTER_ARRANGER,
    INDIVIDE_FILTER_ARRANGER,
    REBUILD_ARRANGER,
    KV_MODEL_RECALLER,
    ES_RECALLER,
    ITEM_FEA_EXTRACTOR,
    CONTROL_PARAM_EXTRACTOR,
    TRUNCATE_ARRANGER,
    REC_MARK_REPORTER,
    HA3_RECALLER,
    MAX_TYPE
};
```

`BuildDependent` 的职责是：基于已收集的 `functors_`（每个 functor 的 Stage/Type/required/output 特征名），计算不同阶段间的“依赖输出→依赖输入”映射，并据此为每个 functor 推断并设置它的 required/output item/ctx 特征名，最终确保不同阶段间的特征传递关系一致，准备后续的 DAG 构建。

---

###### 逐段说明

1) 定义本地结构和循环准备
```cpp
struct DepOut {
    const char* depend{nullptr};
    const char* output{nullptr};
};
std::vector<DepOut> stage_depout_vec(6);
```
- 用 `stage_depout_vec` 存储每个 Stage（RECALL/PRERANK/REBUILD/RANK/RERANK/REPORT）的“depend”（输入特征名）与“output”（输出特征名）。初始都为 nullptr。

2) 为每个 functor 推断阶段默认的 depend/output（按 Stage）
```cpp
for (auto functor: functors_) {
    if (functor->Stage() == FunctorStage::RECALL) {
        stage_depout_vec[FunctorStage::RECALL].depend = kFeaGMergerItem.c_str();
        stage_depout_vec[FunctorStage::RECALL].output = kFeaGMatchItem.c_str();
    } else if (functor->Stage() == FunctorStage::PRERANK) {
        stage_depout_vec[FunctorStage::PRERANK].depend = kFeaGMatchItem.c_str();
        stage_depout_vec[FunctorStage::PRERANK].output = kFeaGPreRankItem.c_str();
    } ...
}
```
- 含义：根据有哪些 Stage 出现在 `functors_` 中，设定阶段间默认的“上一阶段输出 → 下一阶段依赖”的映射。例如 RECALL 阶段默认产出 `kFeaGMatchItem`，下游 PRERANK 默认依赖 `kFeaGMatchItem`；这为后续需要自动填充 required/output 的 functor 提供默认值。

3) 将相邻阶段的 output/pdepend 合并（resolve chain）
```cpp
int out_idx = 0, in_idx = 1;
while (out_idx < stage_depout_vec.size() && in_idx < stage_depout_vec.size()) {
    if (!stage_depout_vec[out_idx].output) { ++out_idx; continue; }
    if (!stage_depout_vec[in_idx].depend) { ++in_idx; continue; }
    if (stage_depout_vec[out_idx].output == stage_depout_vec[in_idx].depend) {
        ++out_idx; ++in_idx; continue;
    }
    stage_depout_vec[in_idx].depend = stage_depout_vec[out_idx].output;
    out_idx = in_idx;
    ++in_idx;
}
```
- 作用：若某阶段A的输出已知而下一阶段B的依赖为空或不匹配，尝试把A的输出填充为B的依赖，从而形成连续链条。总体目的是消除阶段之间的断点，使依赖链连贯（例如当中间阶段缺失时，后续阶段的 depend 可能直接来自更早的 output）。

4) 按 Stage 对 `functors_` 进行稳定排序
```cpp
std::stable_sort(functors_.begin(), functors_.end(),
                 [](Functor* f1, Functor* f2) { return f1->Stage() < f2->Stage(); });
```
- 目的是按 stage 升序排列 functors，保持同一 stage 内的原有相对顺序（stable）。排序后，BuildGraph 能更容易推断阶段性依赖和节点创建顺序。

5) 为每个 functor 根据类型设置具体 output/required
主要逻辑：
```cpp
for (auto functor: functors_) {
    if (functor->Type() == FunctorType::RECALLER || ... || INDIVIDE_FILTER_ARRANGER) {
        functor->SetOutputItemFeaName(kFeaGRecallItem);
    } else if (functor->Type() == FunctorType::MERGER_ARRANGER) {
        functor->SetRequiredItemFeaName(kFeaGRecallItem);
        functor->SetOutputItemFeaName(kFeaGMergeRecallItem);
    } else if (functor->Type() == FunctorType::FURTHER_MERGER_ARRANGER) {
        functor->SetRequiredItemFeaName(kFeaGMergeRecallItem);
        functor->SetOutputItemFeaName(kFeaGMergerItem);
    } else if (functor->Type() == FunctorType::REC_MARK_REPORTER && functor->Stage() == FunctorStage::RANK) {
        functor->SetRequiredItemFeaName(kFeaGRankItem);
    } else {
        if (!functor->GetRequiredItemFeaName().empty() || !functor->GetOutputItemFeaName().empty()
            || functor->Type() == FunctorType::REPORTER
            || functor->Type() == FunctorType::ITEM_FEA_EXTRACTOR
            || functor->Stage() == FunctorStage::REBUILD) {
            // 按 stage 从 stage_depout_vec 填充 require/output
            if (functor->Stage() == FunctorStage::RECALL) {
                const auto& depout = stage_depout_vec[FunctorStage::RECALL];
                functor->SetRequiredItemFeaName(depout.depend);
                functor->SetOutputItemFeaName(depout.output);
            } else if (functor->Stage() == FunctorStage::PRERANK) {
                ...
            } ...
        }
    }
}
```
- 解释：
  - 若 functor 属于 recaller 类型或个性化前置过滤器，则直接把输出设置为 `kFeaGRecallItem`（recall 的标准输出）。
  - 如果是 merger，设置它要求 `kFeaGRecallItem` 并输出 `kFeaGMergeRecallItem`（Merger 聚合 recall 的输出）。
  - 如果是 further merger，在 merger 的基础上再合并输出为 `kFeaGMergerItem`（整体合并后的 item）。
  - 若是 rec_mark reporter 在 RANK 阶段，则把 required 设为 `kFeaGRankItem`（用于异步前置埋点）。
  - 否则，对于那些已有 required/output 或特殊类型（REPORTER/ITEM_FEA_EXTRACTOR/REBUILD），使用 `stage_depout_vec` 为该 Stage 填入依赖/输出（如果相应条目存在）。也即：如果某个 stage 的 functor 没显式设置 required/output，则用阶段默认的 dep/out 填充。

---

###### 意图与上下文关系
- `BuildFunctors` 先将所有需要的 functor 收集并做类型与 helper 的绑定；`BuildDependent` 则负责把这些 functor 连上“数据流”（feature 名称），为每个 functor 明确输入(feature) 与输出(feature) 的语义，方便 `BuildGraph` 根据“谁输出某个 fea → 谁依赖该 fea”建立依赖边。
- `stage_depout_vec` 提供了阶段级别的默认 feature 流（RECALL → MATCH → PRERANK → PRERANKOUT → REBUILD → RANK → RERANK → REPORT），解决当某些 functor 没显式声明时的自动衔接问题。

---

##### 3. StrategyAnalyzer::BuildGraph()

`BuildGraph()` 根据前面填充好的 `functors_`（每个 functor 的 stage/type/required/output 特征名），构建依赖图（dag_map），把 functor 映射为 `Graph::Node` 并连接父子关系，最终把所有节点加入 `strategy_executor_->graph_` 以供后续异步执行。

---

###### 输入 / 输出
- 输入：成员变量 `functors_`（由 `BuildFunctors` / `BuildDependent` 填充），其中每个 Functor 已有 Stage、Type、GetOutputCtxFeaName/GetOutputItemFeaName/GetRequiredItemFeaName 等元数据。
- 输出：返回 bool（当前实现总是 true 表示成功）。
- 返回值：true（无失败分支）。

---

###### 逐段说明

1) 准备局部容器：
- output_ctx_fea_functors：map<ctx_fea_name, vector<Functor*>>，记录哪些 functor 会输出该上下文特征（按 functors_ 顺序）。
- output_item_fea_functors：map<item_fea_name, vector<Functor*>>，记录输出某 item 特征的 functor 序列（按 functors_ 顺序）。
- require_item_fea_functors：map<item_fea_name, vector<Functor*>>，记录依赖某 item 特征的 functor 序列。

代码逻辑：
- 遍历 `functors_`，把 functor 按它们的输出 ctx/item 特征名加入对应 map（每个输出特征对应一个 vector，元素顺序反映 functors_ 的顺序）。
- 对每个 `required item fea`（除了 kFeaGLocation），把 functor 加入 `require_item_fea_functors[fea]`。

意图/影响：
- 这些映射是后面根据“谁输出 X → 谁依赖 X”规则来建立 DAG 边的基础。向量的顺序保留了 `functors_` 顺序，后续某些逻辑会使用向量的前后关系推断串行/并行关系。

2) 处理 ctx 特征依赖（上下文特征）
```text
for (const auto functor: functors_) {
  dag_map[functor];
  for (const auto& fea: functor->GetRequiredCtxFeaName()) {
    auto iter = output_ctx_fea_functors.find(fea);
    if (iter != output_ctx_fea_functors.end()) {
      auto& func_vec = iter->second;
      if (functor->GetOutputCtxFeaName().count(fea)) {
        for (size_t i = func_vec.size() - 1; i > 0; --i) {
          if (functor == func_vec[i]) {
            dag_map[func_vec[i-1]].insert(functor);
          }
        }
      } else {
        dag_map[func_vec.back()].insert(functor);
      }
    }
  }
}
```
解释：
- 对每个 functor，把它放入 `dag_map` 作为一个 key（即确保存在条目）。
- 对 functor 依赖的每个 ctx 特征 fea：
  - 找到所有输出该 ctx 特征的 functor 列表（func_vec）。
  - 若当前 functor 自身也输出该 fea（GetOutputCtxFeaName().count(fea)），则找到它在 func_vec 中的位置并将其前一个 functor 作为父（`func_vec[i-1] -> functor`），意图是把输出相同 ctx 且有顺序关系的 functor 连成链（取上一个生产者作为父）。
  - 否则直接把该 ctx 特征的最后一个 producer（func_vec.back()）作为父，即依赖最近的 producer。

含义/理由：
- 处理 ctx 特征时优先考虑“最近的 producer”。若同一个 functor 集合中某个 functor 既输出又依赖该 fea，则它应该依赖前一个输出该 fea 的 functor（形成串行化）。

3) 处理输出 item 特征（特殊处理 kFeaGLocation）
```text
for (const auto& p: output_item_fea_functors) {
  if (p.first == kFeaGLocation) {
    const auto& fs = p.second;
    for (size_t i = 0; i < fs.size() - 1; ++i) {
      dag_map[fs[i]].insert(fs[i+1]);
      if (fs[i]->Stage() == FunctorStage::RECALL && fs[i+1]->Stage() == FunctorStage::RECALL
          && fs[i]->Type() == FunctorType::ARRANGER && fs[i+1]->Type() == FunctorType::ARRANGER) {
        static_cast<Arranger*>(fs[i])->set_arrange_item(false);
      }
    }
  }
  // debug logging of producers for output-feature p.first
}
```
解释：
- 对于输出为 `kFeaGLocation`（通常表示位置/位置信息链）的 fea，直接把该 fea 的 producers 串联成链：producer[i] -> producer[i+1]。这是因为多个 arranger 在位置输出上具有顺序关系，后一个需要在前一个之后执行。
- 额外：如果相邻的两个 producer 都是 RECALL 阶段的 ARRANGER，则把前一个 arranger 的 arrange_item 标记为 false（表示它不再做位置的 arrange，可能交由后续合并器统一处理）。这是保证多个 arranger 在 recall 阶段的特殊协作逻辑。

含义：
- kFeaGLocation 的 producers 序列是按 functors_ 的顺序形成明确的链，这影响最终 DAG 中的串行执行路径。

4) 处理 require item 特征（大多数 item fea ）
```text
const std::unordered_set<std::string> parallel_item_feas { ... };
for (const auto& p: require_item_fea_functors) {
  const auto& fea = p.first;
  const auto& functors = p.second;
  auto iter = output_item_fea_functors.find(fea);
  if (iter != output_item_fea_functors.end()) {
    if (parallel_item_feas.count(fea)) {
      for (const auto functor: functors) {
        for (const auto parent: iter->second) {
          dag_map[parent].insert(functor);
        }
      }
      continue;
    }
    dag_map[iter->second.back()].insert(functors[0]);
    for (size_t i = 1; i < functors.size(); ++i) {
      if (dag_map[functors[i-1]].count(functors[i])) {
        continue;
      }
      dag_map[iter->second.back()].insert(functors[i]);
    }
  }
  // debug log listing dependents
}
```
解释：
- `require_item_fea_functors` 列出了那些依赖某 item 特征的 functors（可认为是 consumers）。
- 若该 fea 有 producers（output_item_fea_functors 中存在）：
  - 如果该 fea 在 `parallel_item_feas` 集合中（例如 recall item、merge recall item、各种 filter 列表），说明 producers 与 consumers 之间可以并行：对每个 consumer，将每个 producer 都作为父（所有 producer -> consumer），从而允许 consumer 在任一 producer 完成或所有 producer 完成后的特定运行方式（取决于 Node 的 parent counting 行为）。
  - 否则（默认串行语义）：把 producers 的最后一个 producer（iter->second.back()）作为 consumers[0] 的父（最近的 producer 作为第一个 consumer 的父）。对于后续 consumer（functors[1..]），如果它们之间已由先前的 `dag_map` 强连线（即 functors[i-1] -> functors[i]）则跳过，否则把最新 producer（iter->second.back()）也作为父。该逻辑把 consumers 串联或把 producer 作为多个 consumers 的共同父，具体依赖于先前的 dag_map 状态。
- 注：该逻辑试图在“producer 多 → consumer 多”的场景中，按照业务规则决定并行或串行关系。

5) 为每个 dag_map 条目创建 Node 并连接边
```text
for (const auto& p: dag_map) {
  auto parent_accessor = AdaptAccessor(p.first);
  parent_accessor->PreAllocateResource(p.first->strategy_id());
  auto parent = strategy_executor_->graph_->AddNode(parent_accessor, p.first);
  for (const auto node: p.second) {
    if (p.first != node) {
      auto child_accessor = AdaptAccessor(node);
      auto child = strategy_executor_->graph_->AddNode(child_accessor, node);
      parent->AddChildren(child);
    }
  }
}
```
解释：
- 遍历每个 parent functor（p.first）及其子集合（p.second）。
- 为 parent 选取合适的 Accessor（AdaptAccessor 根据 rebuild 状态返回主 accessor 或 rebuild_accessor）。
- 调用 `parent_accessor->PreAllocateResource(parent->strategy_id())`：预分配该策略运行时需要的资源（可能是 item buffers、vector reserve、临时容器等），减少运行时动态分配。
- 通过 `graph_->AddNode(parent_accessor, p.first)` 创建/复用 Node（内部会创建 shared_ptr<Node>，调用 InitializeCallback）。
- 对于每个 child：若 child != parent（避免自环），获取 child_accessor、AddNode(child), 并通过 parent->AddChildren(child) 建立边。`AddChildren` 会在 child 上增加 parent count（child->parent_cnt_++），并将 child 放入 parent.children_nodes_。

意图/效果：
- 这一步把从依赖分析得到的指针关系物化为 Graph 的节点和边，Graph 随后会在 `Graph::Run` 中按 parent_cnt_ 和 parent_done_cnt_ 来 orchestrate 节点执行。

