# 八、Context类

 `StrategyHandle`（实现）和 `ServerImpl::Context`（框架基类）职责、接口、生命周期、典型使用和注意事项。

结论：  
- `ServerImpl::Context` 是框架级的“单次 RPC 会话上下文”抽象，封装了 protobuf arena、gRPC ServerContext/ServerAsyncResponseWriter、超时 Alarm、以及“状态机”（READY/RUNNING/FINISH）和用于向 gRPC 注册/重新注册接收请求的内部方法。  
- `StrategyHandle` 继承自 `ServerImpl::Context`，实现具体的业务逻辑：如何在收到请求时驱动策略执行器（StrategyExecutor），如何在执行完成时填充 response 并返回客户端，以及如何在 Reset 时清理/归还资源。

下面分项说明。

## 1) `ServerImpl::Context`（框架基类）——主要职责
- 代表单个 RPC 会话(slot)：管理一次请求从“等待”到“处理”到“完成并重置” 的整个生命周期。
- 封装 gRPC 的异步 API 细节，提供：
  - 预注册异步接收（`reset(service, cq)`）：调用 `(service->*rpc)(...)` 将一个异步接收请求提交给 gRPC（代表“我愿意接收下一个请求”）。
  - 超时注册（`register_handle_timeout` / `cancel_handle_timeout`） via `grpc::Alarm`，当超时到期时会把 tag 投回 CompletionQueue，以便 worker 调用 `HandleTimeout()`。
  - Response 发送：`ReturnResponse()` 会把 `resp_writer_->Finish(...)` 发回 gRPC 并把 context 标记为 FINISH（Finish 完成后框架会再次收回 tag，让 worker 做重置）。
  - Arena 管理：用 `google::protobuf::Arena` 提供高性能的 protobuf 对象分配（`request_`/`response_` 都在 arena 上分配）。
- 定义抽象接口供子类实现：
  - virtual bool Init()
  - virtual void Reset()
  - virtual void HandleRequest() noexcept
  - virtual void HandleTimeout() noexcept (可选)

## 2) `ServerImpl::Context` 公开/受保护的重要方法/字段（可以调用或覆写）
可直接使用（来自 Context）：
- request() / response() -> 访问 request/response protobuf（由 arena 管理）
- arena() -> 获取 protobuf arena 指针
- ReturnResponse() -> 发送 response（会将状态置为 FINISH 并调用 resp_writer_->Finish）
- set_grpc_status(grpc::Status) -> 设置返回的 gRPC status
框架内部方法（Context::reset/register_handle_timeout 等）：
- reset(service, cq) -> 将 context 置 READY 并把异步接收操作注册到 gRPC（应用通常不直接调用，Run 在初始化时调用）
- register_handle_timeout(timeout_ms, cq) / cancel_handle_timeout() -> 为当前运行的会话设置/取消超时 alarm（Context 自己或子类可调用）

内部字段（供框架/子类使用）：
- request_, response_, grpc_status_
- status_（READY/RUNNING/FINISH）用于框架 event-switch
- alarm_（grpc::Alarm）
- arena_，ctx_（ServerContext），resp_writer_

## 3) `StrategyHandle`（业务实现类）
在 strategy_svr_imp.h 中，`StrategyHandle : public StrategyServer::Context`，它的职责是实现具体的业务处理逻辑，主要方法：
- bool Init() override
  - 在 Run 初始化 contexts 时会调用一次，供做一次性资源准备（例如获取 pod ip，或预分配轻量状态）。如果返回 false，Run 会失败。
- void Reset() override
  - 当一个请求完成（FINISH）后框架会调用 `Reset()`，这时子类应释放或归还该请求持有的资源（例如把 `executor_` 归还到池、清理自有状态等）。
- void HandleRequest() noexcept override
  - 当有新的请求到达（READY -> RUNNING），框架会在 worker 线程中调用这个函数。这里应尽量做“非阻塞触发工作”的操作：例如从 executor 池获取 `StrategyExecutor`、绑定请求、把实际计算提交到后台线程/任务系统，然后快速返回。不要在这里长时间阻塞或做慢 I/O。
- void HandleTimeout() noexcept override
  - 当超时 alarm 到期且请求仍在 RUNNING 时框架会把 tag 投回，worker 在 RUNNING 分支调用 `HandleTimeout()`，子类实现应执行超时处理（记录、降级、标记状态、立即 ReturnResponse 等）。
- void HandleResponse()
  - 不是框架要求的纯虚方法（你的类定义了它），用于当 `StrategyExecutor` 执行完毕时被回调：在这里你把结果写入 `response()` 并调用 `ReturnResponse()`。`ReturnResponse()` 会把 `resp_writer_->Finish()` 发给 gRPC，gRPC 完成后会把 FINISH 事件送回 CQ，由框架完成 Reset。

## 4) 典型生命周期（事件流 + 调用序列）
1. Run 初始化阶段：
   - 框架在 `Run` 中创建 `session_size` 个 `StrategyHandle contexts`，对每个调用 `Init()`，然后调用 `reset(&service, cq)`，即在 gRPC 端提交 `RequestDoRecommend` 的异步接收请求（这些是“空闲的会话槽”）。
2. 请求到达时：
   - gRPC 内部完成 I/O，CQ 返回一个事件（tag = 指向某个 `StrategyHandle`）。
   - worker 线程从 `cq_->Next()` 得到 tag，发现 context 的状态为 READY，于是：
     - 把 status->RUNNING，注册 alarm（`register_handle_timeout`），调用 `HandleRequest()`。
3. 在 `HandleRequest()` 中：
   - 你从 `StrategyExecutorPool` 获取 executor（`GetExecutor()`），把 arena 传给 executor（`SetArena(arena())`）以便在执行过程中用同一个 arena 分配临时 proto，调用 `executor_->Bind(request,...,&response())`，然后调用 `executor_->AsyncDAG([&]{ HandleResponse(); })` 启动实际的 DAG 异步计算。`HandleRequest()` 返回（非阻塞）。
4. DAG 完成后：
   - `StrategyExecutor`（在它的线程或任务系统）在完成时调用 `StrategyHandle::HandleResponse()`：
     - 在 `HandleResponse()` 中填充 `response()`，并调用 `ReturnResponse()`，这会发起 `resp_writer_->Finish()` 并将 context 标为 FINISH。
5. Finish 事件：
   - gRPC 在发送完成后把 FINISH 事件放回 CQ。
   - worker 再次在 `cq_->Next()` 得到该 tag，发现状态为 FINISH，于是：
     - `cancel_handle_timeout()`，调用 `Reset()`（释放 executor 并归还池等），增加 `available_session_size_`，并调用 `reset(&service, cq)` 重新注册该 context 为 READY（可以接受新的请求）。
6. 如遇超时：
   - Alarm 到期会把 tag 投回 CQ，此时框架看到 status_ == RUNNING，会调用 `HandleTimeout()`，子类可做记录或立即 `ReturnResponse()`。



## HandleRequest

```cpp
void StrategyHandle::HandleRequest() noexcept {
    LOG_DEBUG << "strategy request:" << request().ShortDebugString();
    auto it = request().context_msg().rule_map().find(request().context_msg().item_source());
    if (it == request().context_msg().rule_map().end()) {
        LOG_ERROR << "item_source:" << request().context_msg().item_source() << " rule id not found.";
        return HandleResponse();
    }

    executor_ = std::move(StrategyExecutorPool::get_mutable_instance().GetExecutor());
    executor_->SetArena(arena());

    std::vector<std::string> param_vec = util::Split(it->second, '|');
    SetTrafficRankParam(&param_vec);
    const auto& svr_param = request().context_msg().scene_info().svr_param();
    auto iter_svr_param = svr_param.find("enable_fea_sampler");
    if(iter_svr_param !=svr_param.end() && iter_svr_param->second==1){
        param_vec.emplace_back("scc_prerank_fea_sampler:50680");
    }
    // then push a bunch of fixed params and possibly NATURAL-specific param...
    start_time_ = dt_.GetCurrentTimeMs();

    executor_->Bind(request(), std::move(param_vec), &response());
    executor_->AsyncDAG([&]() { this->HandleResponse(); });
};
```

## HandleRequest 做了哪些事情

1. 日志和请求结构检查
   - 打印 request 的 debug 信息。
   - 从 request 的 `context_msg().rule_map()` 根据 `item_source()` 查找对应的策略参数字符串（`it->second`）。这是决定后续策略集合/参数的关键配置来源。

2. rule_map 缺失处理
   - 如果找不到对应 entry，代码记录错误日志 `rule id not found.`，然后执行 `return HandleResponse();`（立即跳到响应处理流程）。
   - 重要：在此分支下 `executor_` 尚未取得（仍然为 nullptr），但 `HandleResponse()` 会访问 `executor_`（`executor_->GetAccessor()`），这会产生空指针解引用 —— 这是代码中的一个明显潜在 bug（详见下文建议）。

3. 从 `StrategyExecutorPool` 获取 `StrategyExecutor` 实例
   - `executor_ = std::move(StrategyExecutorPool::get_mutable_instance().GetExecutor());`
   - 目的是复用执行器对象，避免频繁构造。`GetExecutor()` 返回 `unique_ptr<StrategyExecutor>`。
   - 紧接着调用 `executor_->SetArena(arena());`：把当前 RPC 的 protobuf arena 传给 executor，使 executor 在执行过程中能在同一 arena 上分配临时/响应对象，减少动态分配与拷贝（提高性能）。

4. 构造并调整参数向量 `param_vec`
   - 通过 `util::Split(it->second, '|')` 将配置字符串拆成 vector<string>。
   - 调用 `SetTrafficRankParam(&param_vec)`：当请求来源是 `TRAFFIC` 时，按规则将自然链路的一些 rank 参数追加到 `param_vec`（保证某些融合参数最后出现，或把自然链路的某些策略加入投放链路）。
   - 检查 `scene_info().svr_param()` 中是否 `enable_fea_sampler` 开启，若开启则 push 额外的 sampler 参数。
   - 往 `param_vec` 中追加若干固定的参数字符串（rec_recall_save、rec_prerank_save 等），并在前面插入一个默认 param `"scc_recall_get_merge_item_fea:36725"`。
   - 记录最终的 `param_vec` 内容（debug）。

5. 记录开始时间
   - `start_time_ = dt_.GetCurrentTimeMs();`：用于后续计算处理耗时，并在 `HandleResponse()` 中加入监控数据。

6. 绑定请求与启动异步执行 DAG
   - `executor_->Bind(request(), std::move(param_vec), &response());`
     - 向 executor 提供输入 `request()`（protobuf 引用）、参数向量（移入以避免拷贝）和 `&response()`（指向由 Context 的 arena 管理的 response protobuf）。
     - 通过将 response 的地址传入，可以避免在 executor 内为 response 分配新的对象或做额外拷贝（在 executor 使用 arena 分配可直接填充 response）。
   - `executor_->AsyncDAG([&]() { this->HandleResponse(); });`
     - 异步提交 DAG 执行，并传入一个回调 lambda：当 DAG 执行完成时，executor 会调用此回调，以便回填 response 并返回客户端（`HandleResponse()` 会调用 `ReturnResponse()`）。

7. `HandleRequest()` 快速返回（非阻塞）
   - 该函数的设计就是“触发/提交异步任务并尽快返回”，以避免阻塞 CQ 的 worker 线程。实际耗时的计算在 executor 的线程/线程池中执行。

## 与其他组件的交互
- `StrategyExecutorPool::GetExecutor()`：从池取 executor；可能是新创建也可能是已有对象。
- `executor_->SetArena(arena())`：把 RPC 的 arena 给 executor，executor 在运行期间可在该 arena 上分配临时 proto，从而避免频繁堆分配，且 response 直接写入该 arena 的 response 对象。
- `executor_->Bind(...)`：绑定 request、参数和 response 的位置；具体 Bind 实现会解析请求并准备 DAG 的执行上下文（内部细节视 `StrategyExecutor` 实现）。
- `executor_->AsyncDAG(callback)`：真正异步执行，完成时调用 callback（这里是 `HandleResponse()`）。执行线程通常由 executor 的内部线程池或任务系统负责。

## 并发/生命周期与安全性注意（重要）
1. lambda 捕获与 `this` 生命周期：
   - Lambda `[&]() { this->HandleResponse(); }` 捕获方式按引用（`&`）。它使用 `this`（当前 Context 指针）。保证安全的条件：
     - 在 DAG 完成并调用 callback 之前，`StrategyHandle` 的对象不能被销毁或重置到下一个请求。框架的生命周期：只有在 `ReturnResponse()` 后，框架的 worker 会在 FINISH 事件回调中调用 `Reset()` 并 `reset()` 为下一次请求。通常 `HandleResponse()` 会调用 `ReturnResponse()`，因此回调运行时 `this` 仍然有效，这是安全的。
   - 但仍需注意：如果发生异常路径或 timeout 逻辑，可能会有竞态（例如超时触发并被 Reset），因此在 callback 执行前要确保不会发生把 `executor_` 提前释放的情形。当前框架设计在 Finish 完成前不会调用 Reset，因此一般安全，但最好在回调时对 `executor_` 做空指针检查。

2. 空指针风险（代码中的明显问题）
   - 当 rule_map 找不到时，代码 `return HandleResponse();` 直接进入 `HandleResponse()`，但 `executor_` 尚未被赋值（nullptr）。`HandleResponse()` 里第一行 `auto accessor = executor_->GetAccessor();` 会导致空指针解引用并崩溃。
   - 修复建议：在 rule 没找到的分支应该直接构造错误 response 或设置 grpc status，并调用 `ReturnResponse()`；**不要**调用 `HandleResponse()`（因为该函数依赖 executor_）。例如：
     - set response 的错误字段并 `ReturnResponse()`，或
     - 设置 `set_grpc_status(grpc::Status(grpc::StatusCode::INVALID_ARGUMENT, "rule not found"))` 然后 `ReturnResponse()`。
   - 该问题在生产环境会直接导致服务 crash 或未定义行为，应尽快修复。

3. executor_ 可能为 null（factory 失败）
   - `GetExecutor()` 可能在极端情况下返回空（例如 factory 创建失败），当前代码没有对 `executor_` 为空做检查。应加入检查，若失败则记录日志并返回合理的错误响应。

4. 异常与 noexcept
   - `HandleRequest()` 标注 `noexcept`，但内部有可能触发异常（例如容器分配失败、GetExecutor 抛出异常等）。因为 `noexcept` 下异常会调用 `std::terminate`，应在函数内部使用 try-catch 捕获所有异常并在异常路径中安全地返回（写 error response 并 `ReturnResponse()`），避免未捕获异常中断 worker 线程或整个进程。

5. 超时与 cancel
   - 框架在 `HandleRequest()` 进入 RUNNING 时会注册一个 `grpc::Alarm`（超时时间），如果任务执行超时，`HandleTimeout()` 会被调用。当前 `HandleTimeout()` 仅记录错误，未取消 executor 的运行或回收资源，可能导致：
     - 请求超时后仍在后台占用执行资源并随后调用 `HandleResponse()`，这会把响应发送回客户端（客户端可能已断开）或造成重复回包/竞态。
   - 建议在 `HandleTimeout()` 中尝试告知 executor 取消（如果 executor 支持 cancel），并确保 `HandleResponse()` 中检查是否已经超时或已被取消，从而避免在超时后仍发送结果。

6. arena 的注意点
   - `executor_->SetArena(arena())` 把 Context 的 arena 给 executor。好处是低分配和零拷贝 response 写入。
   - 但必须确保 executor 在调用 callback (HandleResponse) 前不会把 response 引用交给其他线程长期持有；因为 arena 的生命周期受 Context 控制，直到 FINISH/Reset 前有效。不要把 arena 中的指针跨请求或长期缓存。

## 性能与可优化点
- 参数向量构造：
  - `util::Split(it->second, '|')` 创建 vector；如果配置很长或高 QPS，可考虑 `param_vec.reserve(...)` 来减少再分配（取决于 util::Split 的实现）。
- 捕获 lambda 改为 `[this]` 或 `std::weak_ptr` 风格
  - 捕获方式目前 `[&]`（按引用捕获外部变量），更明确和安全的写法是捕获 `this`（`[this]`）或使用 `std::weak_ptr` 来防止引用悬空（如果你打算改造 Context 为可 shared_ptr 管理）。
- 在关键路径加上空指针和错误检查（GetExecutor 结果，Bind 是否成功等）。

## 结论
- `HandleRequest()` 的核心思想是：
  1. 根据请求确定要执行的策略参数集合；
  2. 从 executor 池取出 executor 并把当前 RPC 的 arena 传给它；
  3. 绑定 request/params/response 到 executor；
  4. 异步执行 DAG，并在完成时回调 `HandleResponse()` 来填充响应并发回客户端。
- 目前代码存在一个显著 bug（rule not found -> 调用 HandleResponse 导致空指针）。还需要添加空指针检查、异常捕获与超时 cancel 支持来增强鲁棒性。



# SetTrafficRankParam作用

```protobuf
enum ItemSource{
    NATURAL = 0;        // 普通品	->	自然流量/自然品链路
    NEW = 1;            // 新品		->	新品链路
    TRAFFIC = 2;        // 投放		->	投放/流量/付费链路
    RESTOCK = 3;        // 回货		->	补货/到货相关链路
    CLEAR = 4;          // 清仓		->	清仓/促销/清货链路
    MIXER = 99;         // 混排		->	 混合/合并/聚合链路
}
```

业务语义总结
- NATURAL = 自然流量 -> 用户正常浏览/推荐流（非广告），以用户兴趣/协同过滤/个性化排序为主。
- NEW = 新品位 -> 关注新品的专门策略（上新识别、冷启动处理）。
- TRAFFIC = 投放/广告位/付费流量 -> 需要兼顾投放评估、abtest、竞价或和自然排序融合。
- RESTOCK = 到货/补货场景 -> 触发补货提醒、到货优先展示等逻辑。
- CLEAR = 清仓/促销场景 -> 优先展现清仓商品或降价逻辑。
- MIXER = 合并器/混流 -> 负责把来自多路召回或不同来源混合输出的复合链路（比如把投放+自然+新品合并并重新排序的链路）。

### 代码回顾  
函数在 strategy_svr_imp.cc 中，核心逻辑是：

- 仅当请求的 `item_source()` 是 `TRAFFIC` 时才生效（对非 TRAFFIC 不做任何改动）。
- 如果 `scene_id()` == 205 则直接返回（特殊场景不做合并）。
- 在 `rule_map` 中查找 `ItemSource::NATURAL` 的参数串（即自然品链路的参数定义）；如果存在，则：
  - 在当前 `stra_param_vec`（即 traffic 的 param 列表）中寻找以 `rec_rank_fuse` 或 `scc_rank_fuse` 开头的 fuse 参数，把该 fuse 参数摘出（保存为 `traffic_rank_fuse_param` 并从原向量中删除）。
  - 把 `NATURAL` 的参数串拆分成单个 param，并把其中以 rank 策略前缀（`kRankStrategyPrefix` / `kSccRankStrategyPrefix` / `kSccV1RankStrategyPrefix`）开头的那些 param 追加到 `stra_param_vec`。
  - 最后把之前摘出的 `traffic_rank_fuse_param`（如果存在）追加回 `stra_param_vec` 的尾部。

业务意图
- 源语义：
  - `TRAFFIC`：通常指投放/流量位（paid/promoted/traffic chain）的请求参数集合——投放链路专用的策略参数。
  - `NATURAL`：自然链路（organic）的策略参数集合，包含许多针对自然排序/召回/精排的 rank 策略。
- 合并需求：在某些投放场景下，需要把自然链路里针对排序/精排的策略也纳入到投放链路的执行流程中（可能为了提升融合质量或兼容某些业务逻辑）。因此把 NATURAL 的 rank 策略追加到 TRAFFIC 的参数里，令投放链路在执行时也会跑这些 rank 算子。
- 关于 fuse 参数的处理（把 `rec_rank_fuse` / `scc_rank_fuse` 提取并放到末尾）：
  - `*_fuse` 可能是“融合”或“最终融合”的策略参数（将多个排序/得分结果合并）。为了保证融合逻辑在所有参与策略运行之后再执行，代码先把 traffic 的 fuse parm 暂移除，再把 NATURAL 的 rank 策略追加，最后把 fuse 放回末尾。即保证融合参数始终位于最后（fusion 在所有子策略之后执行）。

实现细节
- 只挑选 NATURAL 参数中以特定前缀开头的参数（rank 策略相关），而不是把 NATURAL 的所有参数都盲目拼进来。这样避免把不相关的配置引入 TRAFFIC。
- 当找到 traffic 自有的 fuse 参数时只取第一个匹配并移除（循环里遇到第一个匹配就 break）。
- 使用 string 前缀匹配（`boost::starts_with`）决定哪些是 fuse 或 rank 策略。
- 操作是在每次请求到来时对 `param_vec` 做字符串拆解/拼接（轻量的 CPU/alloc 开销，通常可接受，但 QPS 很高时值得注意）。

举例说明（输入 -> 输出）
假设：
- 原始 traffic 的 param_vec（来自 rule_map[TRAFFIC]）：
  ["A", "rec_rank_fuse:123", "B"]
- NATURAL 的 param 字符串（拆分后）包含：
  ["rec_rank_X:1", "foo:bar", "scc_rank_Y:2", "something_else"]
  执行后：
- 会先找到并摘出 `"rec_rank_fuse:123"`；
- 从 NATURAL 追加以 rank 前缀开头的 `"rec_rank_X:1"`, `"scc_rank_Y:2"`；
- 把 fuse 参数追加到末尾。
  最终 param_vec 可能是：
  ["A", "B", "rec_rank_X:1", "scc_rank_Y:2", "rec_rank_fuse:123"]

特殊分支说明
- `scene_id == 205` 的早返回：这是一个业务特例（某场景不需要或不能合并 NATURAL 的 rank 策略），代码直接跳过合并；具体原因由产品/算法定义（例如 205 场景对投放链路有不同要求）。
- 如果 `rule_map` 中找不到 NATURAL 条目，就不做任何追加。
