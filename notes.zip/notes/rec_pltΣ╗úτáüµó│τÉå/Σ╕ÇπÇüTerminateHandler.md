# 一、`TerminateHandler`

## 1) std::set_terminate 做了什么（概念与语义）
- `std::set_terminate` 用于设置程序的“终止处理器”（terminate handler）。当 C++ 运行时调用 `std::terminate()` 时，会执行由 `std::set_terminate` 注册的函数。
- 语义：
  - `std::set_terminate` 接受一个 `void (*)()` 风格的函数指针（或可调用对象），并返回先前的处理器（如果需要可以保存）。
  - 这个终止处理器是全局（进程级）的：影响所有线程（不是某个线程局部）。
  - 终止处理器一旦被调用，通常不应返回（规范建议不返回）；典型做法是调用 `std::abort()`、`_Exit()` 或 `std::exit()`。如果终止处理器返回，运行时会再次调用 `std::terminate()`，可能导致无限递归。

## 2) 什么时候会触发 std::terminate（触发场景）
std::terminate 会在多种情况下被调用，常见的包括：
- 有异常抛出但没有匹配的 catch（即异常传播到 `main()` 以上且未被捕获）。
- 在异常传播（stack unwinding）期间又抛出另一个异常（例如在析构函数中抛出异常，而这一析构是在处理另一个异常时被调用），导致双重抛出。
- 在 `noexcept` 函数中抛出异常（实现会调用 `std::terminate`）。
- C++ 线程函数（std::thread）中异常未被捕获导致线程终止，运行时会对该线程调用 `std::terminate`（进程级的 terminate handler 仍然会被调用）。
- 显式调用 `std::terminate()`。

当 `std::terminate()` 被调用时，会执行当前注册的 terminate handler（就是 `TerminateHandler`），然后通常产生进程终止（例如 `abort()` 产生 core dump）。

## 3) 程序中 `TerminateHandler()` 的逐行行为分析
TerminateHandler 的代码（关键部分）大意如下：

1. std::exception_ptr exptr = std::current_exception();
   - 试图获取当前活动的异常对象（若存在），返回一个 `exception_ptr`。
   - 注意：`std::current_exception()` 只有在“有活动异常且在 catch 块内”时可靠地返回非空。通常在 terminate handler 中不在 catch 块内，因此它往往返回空（但某些实现/情形下可能会保留最后的异常信息，不能依赖）。因此这段代码需要理解其局限性：通常会得到 `nullptr`。

2. 
   ```cpp
       if (exptr) {
           try {
               std::rethrow_exception(exptr);
           } catch (const std::exception& e) {
               // 打印异常详细信息
               std::cerr << "Exception details: " << e.what() << "\n";
           } catch (...) {
               // 处理非 std::exception 类型的异常
               std::cerr << "Unknown exception caught!\n";
           }
       } else {
           std::cerr << "No active exception.\n";
       }
   ```

   - 如果 `exptr` 非空：重新抛出并在这里尝试把异常信息打印出来（对 `std::exception` 打印 `what()`，对其它类型打印 "Unknown exception"）。
   - 如果 `exptr` 为空：打印 "No active exception."（这是常见情况）。

3. ```cpp
   std::stringstream ss;
   common_backtrace::PrintStackTrace(ss);
   std::cerr << "Forcing core dump...\n" << ", stack:" << ss.str();
   ```

   - 使用自定义的 `common_backtrace::PrintStackTrace` 将栈信息写入 `ss`，然后将栈信息打印到 `std::err`。
   - `PrintStackTrace` 使用 `libunwind(unw_*)`来回溯栈帧、`dladdr` 获取模块信息、`__cxa_demangle` 解码符号名，并尝试用 `libdwfl(elfutils)`查询源文件和行号（如果可用的调试信息存在）。

4. `std::abort();`

   - 强制产生 SIGABRT；通常会生成 core dump（如果系统允许）。这是标准且安全的结束方式：它不会调用析构函数或进一步的 C++ 清理，而是直接让内核终止进程并产生 core（或触发系统的 coredump handler）。

总结：该 handler 尝试（有限地）获取异常内容并打印；不管是否能获取异常，会打印栈回溯并通过 `abort()` 强制终止以便生成 core dump 供离线分析。

## 4) 典型的“函数栈 / 调用流程”在发生未捕获异常时（从抛出到 terminate 的简化链）
下面给出一个典型的调用链（最顶端是最先发生的事件 -> 最后调用 terminate-handler）：

1. 代码某处抛出异常
   - user_function()  // 例如某个函数在运行时抛出: `throw std::runtime_error(...)`
2. C++ 运行时开始向上查找匹配的 catch 并执行栈展开（unwinding）
   - 调用栈会依次执行已注册的析构函数等
3. 如果没有找到任何匹配的 catch，运行时会调用 `std::terminate()`（在 libstdc++/libc++ 中通常从 `__cxa_throw` 或相关处触发）
   - 典型低层函数名（实现相关）： `__cxa_throw -> (runtime) -> std::terminate()`
4. `std::terminate()` 调用当前注册的 terminate handler（在 `main()` 开头通过 `std::set_terminate(TerminateHandler);` 注册的那个）
   - 调用： TerminateHandler()
5. TerminateHandler 执行：
   - 尝试 `std::current_exception()` 并（可能）打印异常信息（见上文 caveat）
   - 调用 `common_backtrace::PrintStackTrace(...)`，用 libunwind 遍历当前进程线程的栈帧并解析符号、尝试用 DWARF 查源文件/行号
   - 打印栈信息
   - 调用 `std::abort()`（触发 SIGABRT）
6. 内核收到 SIGABRT，生成 core（如果系统允许），并结束进程（可以由外部 coredump handler/监控接管）

在真实的栈跟踪输出中，会看到类似的 frame 列表（从当前 frame 向下）：
- pc: address main_logic_function + offset   // 抛出异常的位置（如果没有内联/优化）
- pc: address caller_function + offset
- ...
- pc: address __cxa_throw + offset
- pc: address std::terminate + offset
- pc: address TerminateHandler + offset
- pc: address common_backtrace::PrintStackTrace + offset
- pc: address unw_getcontext / unw_init_local / unw_step ...
- pc: address __libc_start_main / start (进程入口)

注意：实际输出会受编译器优化、内联、tail-call、符号剥离（stripping）和是否包含调试信息（DWARF）影响。优化编译可能导致某些函数被内联或帧信息变得不完整。

## 5) `common_backtrace::PrintStackTrace` 的实现要点与局限
实现细节：
- 使用 libunwind（unw_getcontext / unw_init_local / unw_step / unw_get_proc_name）来逐帧遍历当前上下文。
- 用 `abi::__cxa_demangle` 对 C++ 符号做 demangle。
- 用 `dladdr` 获取可执行或库文件名（dli_fname）。
- 使用 elfutils 的 libdwfl（Dwfl、dwfl_linux_proc_report、dwfl_module_getsrc 等）尝试把程序计数器（pc）映射到源文件和行号（DWARF 信息）。
- 还有一个变体 `PrintStackUCTrace(const ucontext_t& uc, int out_fd)`：用于在 signal handler（有 ucontext）中打印栈，直接写到 file descriptor（更适合 signal-safe 输出）。

局限与注意事项：
- libdwfl / elfutils 是 Linux 专用（ELF）工具链的一部分。
- 为了得到准确的源文件/行号，二进制及相关库需要包含 DWARF 调试信息（或有 separate debug info 可用）。如果二进制被 strip 或没有调试 info，则只能得到地址和符号而无法映射到行号。
- 在优化级别高（-O2/-O3）下，某些帧会被内联或优化掉，导致回溯不完整或不准确。
- `unw_get_proc_name` 与 `dladdr` 在动态加载和跨模块调用时的表现依赖于链接选项（例如是否使用 `-rdynamic` 导出符号）以及是否使用了静态/动态库。
- 在 signal handlers 中要非常注意“异步信号安全”函数：`malloc`、`std::string`、`std::cout`、`__cxa_demangle` 等不是 async-signal-safe；`PrintStackUCTrace` 直接写到 fd（write）是更安全的做法（代码中提供了该变体以便在 signal handler 中使用）。
