# 六、kafka相关

在 rec_strategy.cc 里这几行：
```cpp
KAFKA_REPORTER_INIT(service_comm::KafkaReporter, kKafkaAbt);
KAFKA_REPORTER_INIT(service_comm::KVKafkaReporter, kKafkaSvrMark);
KAFKA_REPORTER_INIT(service_comm::KafkaReporter, kKafkaStrategyFea);
KAFKA_REPORTER_INIT(service_comm::KafkaReporter, kKafkaFeatureLanding);
KAFKA_REPORTER_INIT(service_comm::StrategyMetricKafkaReporter, kKafkaStrategyMetric);
KAFKA_REPORTER_RUN();
```
等价于调用（宏展开）：
- 为每个名字调用 `KafkaReporterManager::get_mutable_instance().InitReporter<ReporterType>(name)`；
- 然后调用 `KafkaReporterManager::get_mutable_instance().Run()` 启动后台消费线程。

下面按步骤解释 InitReporter/Init/Run/Push 的完整流程与实现细节。

---

## 启动时发生的事情（InitReporter -> BasicKafkaReporterImpl::Init）

1. `KafkaReporterManager::InitReporter<T>(name, queue_size)`：
   - 在单例管理器 `KafkaReporterManager` 的内部 map (`reporters_`) 中为 key `name` 创建一个 `T(queue_size)` 对象（T 必须继承 `BasicKafkaReporterImpl`）。
   - 随后调用该对象的 `Init(name)`，并把对象保存在 `reporters_` 中（只有 Init 返回 true 表示初始化成功，函数仍返回 Init 的布尔结果）。

2. `BasicKafkaReporterImpl::Init(const std::string& name)`（关键点）：
   - 调用 `ServiceUtility::GetKafkaConf(name, &kakfa_conf)` 从服务配置中读取 Kafka 参数（topic、username、auth_token、cluster_name、auth_url 等）。这些配置来自程序的配置 proto（见 `recommend_common_config` 等）。
   - 调用 `KafkaAuth::KafkaSaslAuth(...)`：这是向认证服务请求实际 broker 列表与密码的过程（在 prod 环境会向 `auth_url + "/api/v1/sdk/access"` 发送 HTTP 请求，最多重试 3 次），函数返回并填充一个 `cppkafka::Configuration`（包括 metadata.broker.list、sasl 信息等）。
   - 用生成的 `cppkafka::Configuration` 构造 `cppkafka::Producer`（`producer_`），用 kafka topic 构造 `cppkafka::MessageBuilder`（`builder_`）。
   - 设置 `name_` 等内部状态，并返回 true 表示 Kafka producer 已准备就绪。
   - 失败情况：如果 `GetKafkaConf` 或 `KafkaSaslAuth` 失败，会记录日志并返回 false（初始化失败不会创建 producer）。

注意：`KafkaAuth::KafkaSaslAuth` 的行为：
- 在 prod，会调用 `GetKafkaSaslAuthInfo` 向 auth 服务 POST 带用户名/token 的 JSON 请求，解析返回的 brokers 与密码；重试机制为最多 3 次，失败则返回 false。
- 根据返回的 `isAcl`，构造带 SASL 配置或不带 SASL 的 `cppkafka::Configuration`。

---

## 启动后台消费线程（KafkaReporterManager::Run）

- `KafkaReporterManager::Run()` 启动一个单独线程（成员 `worker_`），在该线程中循环直到 `stop_` 被设置：
  - 每个循环遍历 `reporters_` 中的每个 `BasicKafkaReporterImpl` 实例，调用其 `Consume()` 方法；
  - 如果某个 reporter 返回 `Consume()` 为 true（表示消费到了数据并发送到了 Kafka），就记为 `has_value = true`；
  - 如果这一轮没有任何 reporter 有数据（has_value == false），线程 sleep 100 ms，然后继续循环。
- Manager 析构时会把 `stop_` 置为 true 并 join worker 线程，确保优雅结束。

---

## 报告者（Reporter）们具体如何入队与出队、发送到 Kafka

- 报告者种类
  - `KafkaReporter`（对字符串消息）：内部是 `KafkaReporterImpl<std::string>`，有固定大小的消息池（vector）和两个 lock-free 队列 `pool_queue_`/`work_queue_` 用来管理空闲槽与待发送索引。
  - `KVKafkaReporter`（key+value pair）：`KafkaReporterImpl<std::pair<string,string>>`，Consume 时将 pair.second 作为 payload，pair.first 作为 key 发送（以便 Kafka partitioning/key）。
  - `StrategyMetricKafkaReporter`（proto `RecStrategyReport` 类型）：实现定制的 `Consume()`，会把入队的 `RecStrategyReport` 合并、维护内部 metric_map_、按周期打点计算汇总（包括用 prometheus::Summary 计算 p99），然后分批序列化并调用 PushKafka。

- 入队（在各处业务代码）
  - 使用宏 `KAFKA_REPORTER_PUSH(name, msg)` / `KAFKA_REPORTER_RPUSH(name, reporter, msg)`：
    - 这些宏调用 `KafkaReporterManager::Push<T>(name, std::move(msg))`，内部取对应 reporter，强制转换为指定类型然后调用其 `Push(msg)`（`Push` 为 `KafkaReporterImpl<T>::Push`，把对象放到 messages_ 的空闲槽并把索引入 `work_queue_`）。
    - 如果 `pool_queue_` 空（没有可用槽），Push 会失败并返回 false（此时在调用点通常会有日志，但消息会被丢弃）。
- 出队与发送（后台线程调用 `Consume()`）
  - `KafkaReporterImpl<T>::Consume()`（由各具体类重写）会调用 `Pop(msg)`（从 `work_queue_` pop 索引、取消息），然后调用 `BasicKafkaReporterImpl::PushKafka(std::move(serialized_msg), key)`。
  - `BasicKafkaReporterImpl::PushKafka` 使用 `cppkafka::MessageBuilder` 构造消息并调用 `producer_->produce(...)` 将消息发给 librdkafka（同步调用到 librdkafka 的 produce path；librdkafka 内部有自己的缓冲与网络线程）。
  - `PushKafka` 捕获异常并在失败时记录日志，返回 false 表示发送失败。

---

## 运行时语义与性能/容错要点

1. 非阻塞入队：上游调用入队几乎是 lock-free、快速的（如果 `pool_queue_` 有空闲槽）。一旦空槽耗尽，Push 会失败且消息被丢弃——没有内建阻塞等待或回压。
2. 后台消费线程轮询：单线程遍历所有 reporters 并调用 `Consume()`。如果某 reporter 有大量数据，worker 会不断消费该 reporter（本轮 has_value=true），不会 sleep；当总体短期没有数据时会 sleep 100ms。
3. Kafka 生产端：
   - 使用 `cppkafka::Producer`（librdkafka 封装）发送消息；producer 内部有队列/缓冲，`produce()` 是可能抛异常的，且在这里没有重试策略（遇异常记录错误并丢弃该消息）。
   - `BasicKafkaReporterImpl::Init` 设置 `request.required.acks = 0`（即不等待 broker ack），并开启 `lz4` 压缩，这减少延迟但存在消息丢失风险。
4. StrategyMetricKafkaReporter 有额外的聚合与周期逻辑：它把多条小 metric 合并并每隔一定时间分批发送（避免高频小消息）。
5. 认证：KafkaAuth 在 prod 模式会通过 HTTP 向认证/授权服务请求 brokers 和密码（最多重试 3 次），如果认证失败 reporter Init 就失败，不会加入 `reporters_`（或者 InitReporter 返回 false）。
6. 资源释放 / 退出：
   - `KafkaReporterManager` 析构会设置 stop_ 并 join worker，确保后台线程停止；但主程序在退出时应确保先 flush/消耗队列（当前实现并没有显式 flush），所以部分消息可能在进程退出时还在内存中未发出。

---

## 在代码中哪里使用这些 reporter（举例）
- strategy_reporter.cc：
  - 用 `KAFKA_REPORTER_PUSH(kKafkaStrategyFea, strategy_report.SerializeAsString())` 发送策略特征报告（字符串 proto）。
  - 用 `KAFKA_REPORTER_RPUSH(kKafkaStrategyMetric, service_comm::StrategyMetricKafkaReporter, std::move(strategy_report))` 发送 `RecStrategyReport`（交给专用 reporter 聚合）。
- 其他地方用 `KAFKA_REPORTER_PUSH(kKafkaAbt, json)`、`KAFKA_REPORTER_RPUSH(kKafkaSvrMark, service_comm::KVKafkaReporter, std::move(pair))` 等。

---

## 结论
在 main 里调用的 `KAFKA_REPORTER_INIT(...); KAFKA_REPORTER_RUN();` 会为每个命名的 reporter 构造并初始化 Kafka producer（包括向认证服务取 brokers/密码并构造 cppkafka::Producer），并启动一个后台线程循环消费各 reporter 的内存队列，将消息发到 Kafka；推送是非阻塞的、基于 lock-free 池的，消费线程负责把消息真正调用 `producer_->produce()` 发送出去。当前设计偏重低延迟（acks=0、快速入队），代价是容易在高负载或错误场景下丢消息与需要更精细的错误/退避处理。

