# StrategyExecutor::AsyncDAG流程分析

```cpp
bool StrategyExecutor::AsyncDAG(std::function<void()>&& cb) {
    if (!analyzer_->BuildDAG(strategy_ids_)) {
        accessor_->AddErrorReport("strategy-error", "BuildDAG fail", "BuildDAG fail");
        COLLECT_MONITOR(service_comm::MONITOR_STRATEGY_ENGINE, "error:build_dag_fail", STRATEGY_ENGINE);
        cb();
        return false;
    }
    if (accessor_->debug_mode()) {
        std::stringstream gos;
        graph_->Dump(gos);
        LOG_DEBUG << "graph:" << gos.str();
        accessor_->AddCtxExplain("graph", "DAG", gos.str());
    }
    auto [has_loop, err_msg] = graph_->HasLoop();
    if (has_loop) {
        accessor_->AddErrorReport("executor", "DAG graph has loop, " + err_msg, "graph_loop");
        COLLECT_MONITOR(service_comm::MONITOR_STRATEGY_ENGINE, "error:dag_loop", STRATEGY_ENGINE);
        cb();
        return false;
    }
    return graph_->Run(std::move(cb));
}
```

`AsyncDAG` 的职责是：用 `analyzer` 把 strategy id 列表构造成 DAG，做简单校验（debug dump / 环路检测），在失败时同步调用回调并上报监控，成功时把回调转交给 `graph_->Run` 异步执行并返回 `graph_->Run` 的布尔结果。

- 输入
  - cb: std::function<void()> 回调，期望在 DAG 执行结束（或失败早退）时被调用。
  - 使用到的成员：`analyzer_`, `graph_`, `accessor_`（用于 debug / 上报）。
- 输出
  - 返回 bool：true 表示已把执行交给 Graph（通常表示成功启动 DAG）；false 表示构建/校验失败且回调已被同步调用。
- 副作用
  - 可能通过 `accessor_->AddErrorReport` 记录错误。
  - 通过 `COLLECT_MONITOR` 宏触发监控计数。
  - 在成功路径，实际执行与回调交由 `graph_->Run` 控制（会在异步线程中触发 Node 运行并最终在 end 节点回调中执行 cb）。

函数体：
1) if (!analyzer_->BuildDAG(strategy_ids_)) {
   - 作用：调用 `analyzer_` 尝试根据当前 `strategy_ids_` 构建 DAG（通常会把 functor 加入 graph）。
   - 含义：若构建失败（返回 false），说明配置/依赖/构建逻辑问题，不能继续执行。

2) accessor_->AddErrorReport("strategy-error", "BuildDAG fail", "BuildDAG fail");
   - 副作用：将错误信息写入请求级的 debug/错误收集结构（便于上游或追踪）。

3) COLLECT_MONITOR(service_comm::MONITOR_STRATEGY_ENGINE, "error:build_dag_fail", STRATEGY_ENGINE);
   - 副作用：触发监控统计（上报一个 build_dag 失败事件）。

4) cb();
   - 行为：在构建失败路径下，同步执行传入回调 `cb`。注意——这是同步调用（在当前执行线程立即调用）。

5) return false;
   - 行为：函数返回 false，表示失败并且回调已经执行。

6) if (accessor_->debug_mode()) { ... graph_->Dump(gos); ... accessor_->AddCtxExplain("graph", "DAG", gos.str()); }
   - 作用（可选）：当请求在 debug 模式时，把构建出来的 DAG 序列化并放到 debug/context 中，便于后续查看 DAG 结构。
   - 注意：Dump 在此仅作字符串化，并没有改变 graph 状态。

7) auto [has_loop, err_msg] = graph_->HasLoop();
   - 作用：对当前 graph 做环路检测（DFS），并返回是否存在环及错误信息（若 debug 则包含环节点序列）。
   - 含义：DAG 有环说明 analyzer 构建出错导致依赖循环，必须停止。

8) if (has_loop) { accessor_->AddErrorReport("executor", "DAG graph has loop, " + err_msg, "graph_loop"); COLLECT_MONITOR(... "error:dag_loop"...); cb(); return false; }
   - 语义：与 BuildDAG 失败路径一致，记录错误、上监控、同步调用回调并返回 false。

9) return graph_->Run(std::move(cb));
   - 作用：把回调（通过 std::move）传给 `graph_->Run`，并返回 `graph_->Run` 的返回值。
   - 含义：成功路径会由 `graph_->Run` 启动 DAG 的异步执行（`Graph::Run` 会把 start 节点提交给 `StrategyAsyncPool::Async`），并在 DAG 终止时调用传入的 `end_cb`（也就是这里的 cb）。此处 `AsyncDAG` 并不再直接执行 cb，而是委托 Graph 管理回调执行时机与线程。



# StrategyAnalyzer::BuildDAG

```cpp
bool StrategyAnalyzer::BuildDAG(const std::vector<std::string>& strategy_ids) {
    if (strategy_ids.empty()) {
        LOG_ERROR << "strategy_ids is empty";
        return false;
    }
    if (!BuildFunctors(strategy_ids)) {
        LOG_ERROR << "BuildFunctors fail";
        return false;
    }
    if (!BuildDependent()) {
        LOG_ERROR << "BuildDependent fail";
        return false;
    }
    if (!BuildGraph()) {
        LOG_ERROR << "BuildGraph fail";
        return false;
    }
    return true;
}
```

## StrategyAnalyzer::BuildFunctors

`BuildFunctors` 的任务是：遍历上游传入的 strategy id 列表，按规则把每个 strategy 对应的 Functor 创建/绑定并组织到分析器的 `functors_` 列表中；同时为合并器（merger）收集并绑定它依赖的 recall 策略，配置 KV/ES helper 的预期数量，处理“further merge”的默认插入，最后生成额外的 finish/监控/ItemFea extractor 等内置 functor 并把它们合并到最终的 `functors_` 顺序列表中。

## 逐段、逐行解释

1) 初始化和局部变量
```cpp
std::unordered_set<std::string> strategy_set;
std::vector<std::string> merge_strategys;
Functor* further_merge{nullptr};
Functor* recall_filter{nullptr};
size_t merge_count{0};
bool has_recall_item_fea{false};
const auto accessor = strategy_executor_->GetAccessor();
```
- 建立一组 `strategy_set` 防止重复处理同一 strategy id。
- `merge_strategys` / `merge_count` 用于收集遇到的 `MERGER_ARRANGER` 类型策略，以便后续处理 further_merge。
- `further_merge`：后续可能插入的进一步合并器（further merger）。
- `recall_filter`：用于 DSL-filter arranger 时可能需要的 filter 合并器实例。
- `has_recall_item_fea`：标记是否有 recall 阶段的 functor 需要原始 item feature。
- `accessor`：每次 BindStrategyId 时传入的 init accessor（用于内联策略等）。

2) 主循环：遍历 `strategy_ids`
```cpp
for (const auto& strategy_id: strategy_ids) {
    if (strategy_set.count(strategy_id)) continue;
    strategy_set.insert(strategy_id);
    auto functor = strategy_executor_->BindStrategyId(strategy_id, accessor);
    if (!functor) { LOG_DEBUG ...; continue; }
    if (!strategy_executor_->controller_->AllowBuild(functor)) { LOG_DEBUG ...; continue; }
```
- 去重：如果 strategy 已处理则 skip。
- 通过 `BindStrategyId` 去 executor 申请并初始化 Functor（详见 `BindStrategyId`：会从 pool 取出 functor、Bind param、设置 stage、可能标记为 interleaving 等）。
- 如果 `BindStrategyId` 失败就跳过该 id（通常会记录 error）。
- 再询问 `StrategyController::AllowBuild(functor)`，决定 run-time control 是否允许把这个 functor 构建进 DAG（控制参数/AB test 等影响）。

3) 拒绝某些类型在此处被直接配置（配置错误）
```cpp
if (functor->Type() == FunctorType::RECALLER
    || functor->Type() == FunctorType::KV_MODEL_RECALLER
    || functor->Type() == FunctorType::ES_RECALLER
    || functor->Type() == FunctorType::HA3_RECALLER) {
    strategy_executor_->GetAccessor()->AddErrorReport(strategy_id, "dont configure in rules");
    continue;
}
```
- 如果规则里直接把 recaller 类型放在入口策略列表中，这里视为错误（应通过 merger 的 recall options 来连接），记录错误并跳过。

4) 处理 MERGER_ARRANGER（合并器）分支（较复杂）
```cpp
} else if (functor->Type() == FunctorType::MERGER_ARRANGER) {
    ++merge_count;
    merge_strategys.push_back(strategy_id);
    int kv_model_cnt = 0, es_cnt = 0, ha3_cnt = 0;
    auto merger_functor = static_cast<MergeArranger*>(functor);
    auto accessor = AdaptAccessor(merger_functor);
    auto disable_fea = merger_functor->GetDisableStrategyRuntime(accessor);
    auto disable_sids = feature::CastFeature<fmp::LIST_STRING>(disable_fea);
    if (disable_sids) {
        const auto& data = disable_sids->data();
        strategy_set.insert(data.begin(), data.end());
    }
    auto exclude_recall_id_fea = merger_functor->GetExcludeRecallIdFea();
    for (const auto& p: merger_functor->GetRecallOptions()) {
        const auto& recall_sid = p.first;
        const auto recall_num = p.second.recall_num;
        if (strategy_set.count(recall_sid)) { continue; }
        strategy_set.insert(recall_sid);
        if (!strategy_executor_->BindStrategyId(recall_sid, accessor)) { LOG_ERROR ...; continue; }
        auto recall_functor = strategy_executor_->GetFunctor(recall_sid);
        // type check must be recaller-like, set merge_tag and set helper pointers/counters accordingly
        functors_.push_back(recall_functor);
        strategy_executor_->GetAccessor()->AddRecallItemFeature(recall_sid, "", nullptr);
    }
    strategy_executor_->GetAccessor()->AddRecallItemFeature(strategy_id, "", nullptr);
    strategy_executor_->kv_model_helper_->AddExpectCount(kv_model_cnt);
    strategy_executor_->es_batch_helper_->AddExpectCount(es_cnt);
    strategy_executor_->es_batch_helper_->AddExpectCount(ha3_cnt);
}
```
解释要点：
- 遇到 Merger：把 merger 自身计数并记录其 id。
- `AdaptAccessor(merger_functor)`：为 merger 取得合适的 Accessor（普通或 rebuild 版），用于 Bind 其依赖 recall 的 init accessor。
- `GetDisableStrategyRuntime`：merger 可以通过配置返回一组 disable IDs，这里把它们加入 `strategy_set`（跳过这些 recall）。
- 遍历 `merger_functor->GetRecallOptions()`：这些是 merger 在配置里声明要召回的子策略（recall_sid）。
  - 对每个 recall_sid：去 `BindStrategyId(recall_sid, accessor)`，把对应的 recaller 绑定并取回 raw pointer。
  - 对不同类型的 recaller（KV_MODEL_RECALLER / ES_RECALLER / HA3_RECALLER / others），做不同初始化：
    - KV recaller：给 `KVModelHelper` 指针并设置 recall_num、disable_deduplicate、merge_exclude_recall_id_，并增加 kv_model_cnt。
    - ES recaller / HA3 recaller：给 `EsBatchHelper` 指针并设置参数，相应增加 es_cnt/ha3_cnt。
  - 把 recall_functor push 到 `functors_`（注意：functors_ 顺序会影响后续 DAG 排序）。
  - 调用 `GetAccessor()->AddRecallItemFeature(recall_sid, "", nullptr)` 来预建 recall map（注释说“pre build recall map to avoid thread safe issue”）。
- 对 merger 本身也调用 `AddRecallItemFeature`。
- 最后，把计数告诉 kv/es helper（`AddExpectCount`），帮助 batching helper 预估/分配资源。

5) FURTHER_MERGER_ARRANGER 处理
```cpp
} else if (functor->Type() == FunctorType::FURTHER_MERGER_ARRANGER) {
    if (further_merge && strategy_id.find("ratio_quota_fmerge") == -1) {
        LOG_ERROR << "strategy:" << strategy_id << " further merge has one";
        continue;
    }
    further_merge = functor;
    continue;
}
```
- 遇到 further merger：只允许一个 further_merge（除了特定名字例外），把它保存在 `further_merge` 中（稍后统一插入），并跳过把它立即 push 到 functors_（用 `continue`）。

6) ARRANGER 的特殊处理（DSL filter 并行化）
```cpp
} else if (functor->Type() == FunctorType::ARRANGER) {
    functor->SetOutputItemFeaName(kFeaGLocation);
    if (functor->SubType() == FunctorType::DSL_FILTER_ARRANGER) {
        auto add_filter = [this, accessor](auto& sid, auto& io_fea, Functor* functor, Functor*& filter) mutable { ... };
        if (functor->Stage() == FunctorStage::RECALL) {
            add_filter(kGlobalRecallFilterId, kFeaGRecallFilter, functor, recall_filter);
        }
    }
}
```
- 将 arranger 的输出 item feature 默认设置为位置类 `kFeaGLocation`。
- 对于 DSL_FILTER_ARRANGER：有 inline lambda `add_filter`，它负责：
  - 确保 `filter` 存在（会通过 `BindStrategyId(sid, accessor)` 创建全局 recall filter，如 `kGlobalRecallFilterId`）。
  - 如果 filter 存在且 can parallel，则把该 arranger 注册到 `UnionFilterArranger`（`AddFilterStrategy`），关闭该 arranger 的 arrange_item（由 filter 统一并行处理），设置 required 和 output item feature name，把 arranger 的默认输出 fea 从 `kFeaGLocation` 移除（`RemoveOutputItemFeaName`）。
- 该逻辑使多个 DSL filter 的 arranger 能并行复用单个 union filter。

7) 忽略 CONTROL_PARAM_EXTRACTOR 类型
```cpp
} else if (functor->Type() == FunctorType::CONTROL_PARAM_EXTRACTOR) {
    continue;
}
```
- Control param extractor 不进入 `functors_` 列表（可能已在 earlier controller.Bind 时运行或有特殊处理）。

8) push 普通 functor
```cpp
functors_.push_back(functor);
```
- 除去上面单独处理的分支，默认把 functor 加入本次构建的 `functors_` 列表。

9) 结束主循环后：further_merge 的默认创建逻辑
```cpp
if (!further_merge && merge_count > 0) {
    if (merge_count == 1) {
        further_merge = strategy_executor_->BindStrategyId(kGlobalQuotaFurtherMerge);
        static_cast<FurtherMergeArranger*>(further_merge)->set_disable_deduplicate(true);
    } else {
        further_merge = strategy_executor_->BindStrategyId(kGlobalWeightFurtherMerge);
    }
    if (!further_merge) { LOG_ERROR << "create default quota further merge error"; return false; }
    // functors_.push_back(further_merge);
}
if (further_merge) {
    auto further = static_cast<FurtherMergeArranger*>(further_merge);
    for (const auto& merge_strategy: merge_strategys) {
        further->AddMergeStrategy(merge_strategy);
    }
    functors_.push_back(further_merge);
}
```
- 如果之前没有显式 further_merge 但发现有 merge_count>0（存在 merger），则按 merge_count==1 或 >1 的规则创建一个默认 further_merge（quota 或 weight）。
- 如果创建失败会返回 false（表示构建失败，这里是唯一会导致函数直接失败的情况）。
- 若有 further_merge，则把所有 merge_strategy id 注册到 further->AddMergeStrategy(...)，并最终 push 进 `functors_`（注意：此处 commented 出 `functors_.push_back(further_merge);` 的注释和后面真正的 push）。

10) 收集依赖特征（dep_feas / rebuild_dep_feas）
```cpp
std::unordered_set<std::string> dep_feas, rebuild_dep_feas;
for (const auto functor: functors_) {
    const auto& req_item_feas = functor->GetRequiredItemFeaName();
    if (has_rebuild()) {
        if (functor->Stage() == FunctorStage::RECALL || functor->Stage() == FunctorStage::PRERANK) {
            dep_feas.insert(req_item_feas.begin(), req_item_feas.end());
        } else {
            rebuild_dep_feas.insert(req_item_feas.begin(), req_item_feas.end());
        }
    } else {
        dep_feas.insert(req_item_feas.begin(), req_item_feas.end());
    }
    std::vector<std::string> ori_item_feas;
    for (const auto& item_fea: req_item_feas) {
        if (IsOriginItemFeature(item_fea)) {
            ori_item_feas.emplace_back(item_fea);
            if (functor->Stage() == FunctorStage::RECALL) {
                has_recall_item_fea = true;
            }
        } else if (boost::starts_with(item_fea, kFeedsGoodsPrefix)) {
            const auto goods_fea = item_fea.substr(kFeedsGoodsPrefix.size());
            if (IsOriginItemFeature(goods_fea)) {
                ori_item_feas.emplace_back(goods_fea);
                if (functor->Stage() == FunctorStage::RECALL) {
                   has_recall_item_fea = true;
                }
            }
        }
    }
    if (!ori_item_feas.empty()) {
        AdaptAccessor(functor)->RecordStrategyOriFea(functor->strategy_id(), util::join(ori_item_feas, ","));
    }
}
```
- 对每个 functor 收集它们需要的 item 特征（用于后续决定是否需要添加 ItemFeaExtractor）。
- 当有 `has_rebuild()` 时，把 recall/prerank 的 req_feas 和 rebuild/后续的分开归类（优先避免重复请求）。
- 对于每个 req item fea，若是原始 item 特征（origin），把它记录到 `ori_item_feas` 并通过 `AdaptAccessor(functor)->RecordStrategyOriFea(...)` 记录策略对应原始特征名字（用于指标或预取）。
- 如果存在任何 recall 阶段要求原始 item fea，将 `has_recall_item_fea = true`，这会影响后面插入 ItemFeaExtractor 的阶段选择。

11) 追加内置 finish/monitor/ItemFeaExtractor 等 functor（extra_functors）
```cpp
std::vector<Functor*> extra_functors;
auto& data_api = model::DataAutoApi::get_mutable_instance();
const auto add_finish = [&](auto& name, auto& id, auto stage) { ... };
const auto add_functor = [&](auto& name, auto& id, auto stage) -> Functor* { ... };
const auto set_item_feas = [&](auto functor, auto& feas) { ... };
if (has_rebuild()) {
    // 添加一套以 rebuild 为主的 extra functors（SvrMarkReporter、ExplainReporter(->RANK)、ExplainReporter(->REPORT)、StrategyReporter、MonitorReporter、ResponseReporter、FeatureLandingReporter、TraceReporter）
    // 插入 RebuildArranger 并把 rebuild_accessor 关联
    // 决定 ItemFeaExtractor 的插入阶段（RECALL 或 PRERANK）并设置其 output/required fea
} else {
    // 添加没有 rebuild 场景下的一套 finish/monitor/reporters，ItemFeaExtractor 插入位置亦不同
}
extra_functors.insert(extra_functors.end(), functors_.begin(), functors_.end());
functors_.swap(extra_functors);
```
- `add_finish`：会先尝试 `BindStrategyId(id)`（即绑定现有策略），若无法绑定就尝试 `CreateFunctor(name,id)`（CreateFunctor 使用 `GetFunctorFromPool(name)` 并做 minimal Bind）。创建的 finish functor 被保存到 `strategy_executor_->finish_jobs_`（这些会在请求结束时被调用）。
- `add_functor`：类似但会把 functor push 到 `extra_functors`（用于实际执行流程）。
- `set_item_feas`：为 ItemFeaExtractor 设置 output item fea 名称，并在特殊 `kFeedsGoodsPrefix` 情况下设置 required fea。
- 根据 `has_rebuild()` 情况选取不同的内置 functors（有 rebuild 的分支会还会插入 RebuildArranger & 调用 `strategy_executor_->accessor_->Rebuild(...)` 来准备重构数据）。
- 最后把当前计算得到的 `functors_` 拼接到 `extra_functors` 前面，并把 `functors_` 置为 `extra_functors`（以确保内置的 reporter/monitor/featextractor 优先或按需要的顺序出现在最终列表）。

## 关键副作用与跨组件交互点
- `BindStrategyId`：会分配/初始化 Functor 并在 `strategy_executor_` 的 `functor_resource_` / `functor_map_` 中注册（所以 functors_ 只是持有 raw 指针，实际所有权在 executor 的 pool/资源向量中）。
- 对 `kv_model_helper_`、`es_batch_helper_` 的 `AddExpectCount`：帮助 batch helper 预估/分配请求聚合的规模。
- `AddRecallItemFeature`：预建 recall map，注释说是避免线程安全问题（推测是为了在并发调用时保证 recall 所需的 map 已存在）。
- `RecordStrategyOriFea`：记录策略需要的原始 item 特征，便于上游为 item feature client 预取/统计。
- `finish_jobs_`：将某些 reporter/finish functor 放入 executor 的 finish jobs，稍后由 `RunFinishJob()` 执行（在请求生命周期最后）。

## StrategyAnalyzer::BuildDependent()

```cpp
enum FunctorStage {
    RECALL = 0,
    PRERANK,
    REBUILD,
    RANK,
    RERANK,
    REPORT,
    MAX_STAGE
};
enum FunctorType {
    FUNCTOR,
    EXTRACTOR,
    RECALLER,
    ARRANGER,
    REPORTER,
    MERGER_ARRANGER,
    FURTHER_MERGER_ARRANGER,
    DSL_FILTER_ARRANGER,
    INDIVIDE_FILTER_ARRANGER,
    REBUILD_ARRANGER,
    KV_MODEL_RECALLER,
    ES_RECALLER,
    ITEM_FEA_EXTRACTOR,
    CONTROL_PARAM_EXTRACTOR,
    TRUNCATE_ARRANGER,
    REC_MARK_REPORTER,
    HA3_RECALLER,
    MAX_TYPE
};
```

`BuildDependent` 的职责是：基于已收集的 `functors_`（每个 functor 的 Stage/Type/required/output 特征名），计算不同阶段间的“依赖输出→依赖输入”映射，并据此为每个 functor 推断并设置它的 required/output item/ctx 特征名，最终确保不同阶段间的特征传递关系一致，准备后续的 DAG 构建。

---

## 逐段说明

1) 定义本地结构和循环准备
```cpp
struct DepOut {
    const char* depend{nullptr};
    const char* output{nullptr};
};
std::vector<DepOut> stage_depout_vec(6);
```
- 用 `stage_depout_vec` 存储每个 Stage（RECALL/PRERANK/REBUILD/RANK/RERANK/REPORT）的“depend”（输入特征名）与“output”（输出特征名）。初始都为 nullptr。

2) 为每个 functor 推断阶段默认的 depend/output（按 Stage）
```cpp
for (auto functor: functors_) {
    if (functor->Stage() == FunctorStage::RECALL) {
        stage_depout_vec[FunctorStage::RECALL].depend = kFeaGMergerItem.c_str();
        stage_depout_vec[FunctorStage::RECALL].output = kFeaGMatchItem.c_str();
    } else if (functor->Stage() == FunctorStage::PRERANK) {
        stage_depout_vec[FunctorStage::PRERANK].depend = kFeaGMatchItem.c_str();
        stage_depout_vec[FunctorStage::PRERANK].output = kFeaGPreRankItem.c_str();
    } ...
}
```
- 含义：根据有哪些 Stage 出现在 `functors_` 中，设定阶段间默认的“上一阶段输出 → 下一阶段依赖”的映射。例如 RECALL 阶段默认产出 `kFeaGMatchItem`，下游 PRERANK 默认依赖 `kFeaGMatchItem`；这为后续需要自动填充 required/output 的 functor 提供默认值。

3) 将相邻阶段的 output/pdepend 合并（resolve chain）
```cpp
int out_idx = 0, in_idx = 1;
while (out_idx < stage_depout_vec.size() && in_idx < stage_depout_vec.size()) {
    if (!stage_depout_vec[out_idx].output) { ++out_idx; continue; }
    if (!stage_depout_vec[in_idx].depend) { ++in_idx; continue; }
    if (stage_depout_vec[out_idx].output == stage_depout_vec[in_idx].depend) {
        ++out_idx; ++in_idx; continue;
    }
    stage_depout_vec[in_idx].depend = stage_depout_vec[out_idx].output;
    out_idx = in_idx;
    ++in_idx;
}
```
- 作用：若某阶段A的输出已知而下一阶段B的依赖为空或不匹配，尝试把A的输出填充为B的依赖，从而形成连续链条。总体目的是消除阶段之间的断点，使依赖链连贯（例如当中间阶段缺失时，后续阶段的 depend 可能直接来自更早的 output）。

4) 按 Stage 对 `functors_` 进行稳定排序
```cpp
std::stable_sort(functors_.begin(), functors_.end(),
                 [](Functor* f1, Functor* f2) { return f1->Stage() < f2->Stage(); });
```
- 目的是按 stage 升序排列 functors，保持同一 stage 内的原有相对顺序（stable）。排序后，BuildGraph 能更容易推断阶段性依赖和节点创建顺序。

5) 为每个 functor 根据类型设置具体 output/required
主要逻辑：
```cpp
for (auto functor: functors_) {
    if (functor->Type() == FunctorType::RECALLER || ... || INDIVIDE_FILTER_ARRANGER) {
        functor->SetOutputItemFeaName(kFeaGRecallItem);
    } else if (functor->Type() == FunctorType::MERGER_ARRANGER) {
        functor->SetRequiredItemFeaName(kFeaGRecallItem);
        functor->SetOutputItemFeaName(kFeaGMergeRecallItem);
    } else if (functor->Type() == FunctorType::FURTHER_MERGER_ARRANGER) {
        functor->SetRequiredItemFeaName(kFeaGMergeRecallItem);
        functor->SetOutputItemFeaName(kFeaGMergerItem);
    } else if (functor->Type() == FunctorType::REC_MARK_REPORTER && functor->Stage() == FunctorStage::RANK) {
        functor->SetRequiredItemFeaName(kFeaGRankItem);
    } else {
        if (!functor->GetRequiredItemFeaName().empty() || !functor->GetOutputItemFeaName().empty()
            || functor->Type() == FunctorType::REPORTER
            || functor->Type() == FunctorType::ITEM_FEA_EXTRACTOR
            || functor->Stage() == FunctorStage::REBUILD) {
            // 按 stage 从 stage_depout_vec 填充 require/output
            if (functor->Stage() == FunctorStage::RECALL) {
                const auto& depout = stage_depout_vec[FunctorStage::RECALL];
                functor->SetRequiredItemFeaName(depout.depend);
                functor->SetOutputItemFeaName(depout.output);
            } else if (functor->Stage() == FunctorStage::PRERANK) {
                ...
            } ...
        }
    }
}
```
- 解释：
  - 若 functor 属于 recaller 类型或个性化前置过滤器，则直接把输出设置为 `kFeaGRecallItem`（recall 的标准输出）。
  - 如果是 merger，设置它要求 `kFeaGRecallItem` 并输出 `kFeaGMergeRecallItem`（Merger 聚合 recall 的输出）。
  - 如果是 further merger，在 merger 的基础上再合并输出为 `kFeaGMergerItem`（整体合并后的 item）。
  - 若是 rec_mark reporter 在 RANK 阶段，则把 required 设为 `kFeaGRankItem`（用于异步前置埋点）。
  - 否则，对于那些已有 required/output 或特殊类型（REPORTER/ITEM_FEA_EXTRACTOR/REBUILD），使用 `stage_depout_vec` 为该 Stage 填入依赖/输出（如果相应条目存在）。也即：如果某个 stage 的 functor 没显式设置 required/output，则用阶段默认的 dep/out 填充。

---

## 意图与上下文关系
- `BuildFunctors` 先将所有需要的 functor 收集并做类型与 helper 的绑定；`BuildDependent` 则负责把这些 functor 连上“数据流”（feature 名称），为每个 functor 明确输入(feature) 与输出(feature) 的语义，方便 `BuildGraph` 根据“谁输出某个 fea → 谁依赖该 fea”建立依赖边。
- `stage_depout_vec` 提供了阶段级别的默认 feature 流（RECALL → MATCH → PRERANK → PRERANKOUT → REBUILD → RANK → RERANK → REPORT），解决当某些 functor 没显式声明时的自动衔接问题。

---

## 隐含假设与并发 / 生命周期注意
- `functors_` 已包含所有需要考虑的 functor（含 merger 插入、recaller 子策略等），函数并不检验 functor 是否为 nullptr。
- `SetRequiredItemFeaName` / `SetOutputItemFeaName` 的调用会改变 functor 的元信息，后续 `BuildGraph` 和运行时会依赖这些设置。
- 没有同步（锁）— 假定 `BuildFunctors` / `BuildDependent` / `BuildGraph` 在单线程请求绑定阶段顺序运行，不与其他线程并发修改 `functors_`。
- 使用了许多全局 const key（kFeaGRecallItem、kFeaGMergeRecallItem、kFeaGMergerItem 等），这些名称在系统中有固定语义，依赖全局一致性。

## StrategyAnalyzer::BuildGraph()

`BuildGraph()` 根据前面填充好的 `functors_`（每个 functor 的 stage/type/required/output 特征名），构建依赖图（dag_map），把 functor 映射为 `Graph::Node` 并连接父子关系，最终把所有节点加入 `strategy_executor_->graph_` 以供后续异步执行。

---

## 输入 / 输出
- 输入：成员变量 `functors_`（由 `BuildFunctors` / `BuildDependent` 填充），其中每个 Functor 已有 Stage、Type、GetOutputCtxFeaName/GetOutputItemFeaName/GetRequiredItemFeaName 等元数据。
- 输出：返回 bool（当前实现总是 true 表示成功）。
- 返回值：true（无失败分支）。

---

## 逐段说明

1) 准备局部容器：
- output_ctx_fea_functors：map<ctx_fea_name, vector<Functor*>>，记录哪些 functor 会输出该上下文特征（按 functors_ 顺序）。
- output_item_fea_functors：map<item_fea_name, vector<Functor*>>，记录输出某 item 特征的 functor 序列（按 functors_ 顺序）。
- require_item_fea_functors：map<item_fea_name, vector<Functor*>>，记录依赖某 item 特征的 functor 序列。

代码逻辑：
- 遍历 `functors_`，把 functor 按它们的输出 ctx/item 特征名加入对应 map（每个输出特征对应一个 vector，元素顺序反映 functors_ 的顺序）。
- 对每个 `required item fea`（除了 kFeaGLocation），把 functor 加入 `require_item_fea_functors[fea]`。

意图/影响：
- 这些映射是后面根据“谁输出 X → 谁依赖 X”规则来建立 DAG 边的基础。向量的顺序保留了 `functors_` 顺序，后续某些逻辑会使用向量的前后关系推断串行/并行关系。

2) 处理 ctx 特征依赖（上下文特征）
```text
for (const auto functor: functors_) {
  dag_map[functor];
  for (const auto& fea: functor->GetRequiredCtxFeaName()) {
    auto iter = output_ctx_fea_functors.find(fea);
    if (iter != output_ctx_fea_functors.end()) {
      auto& func_vec = iter->second;
      if (functor->GetOutputCtxFeaName().count(fea)) {
        for (size_t i = func_vec.size() - 1; i > 0; --i) {
          if (functor == func_vec[i]) {
            dag_map[func_vec[i-1]].insert(functor);
          }
        }
      } else {
        dag_map[func_vec.back()].insert(functor);
      }
    }
  }
}
```
解释：
- 对每个 functor，把它放入 `dag_map` 作为一个 key（即确保存在条目）。
- 对 functor 依赖的每个 ctx 特征 fea：
  - 找到所有输出该 ctx 特征的 functor 列表（func_vec）。
  - 若当前 functor 自身也输出该 fea（GetOutputCtxFeaName().count(fea)），则找到它在 func_vec 中的位置并将其前一个 functor 作为父（`func_vec[i-1] -> functor`），意图是把输出相同 ctx 且有顺序关系的 functor 连成链（取上一个生产者作为父）。
  - 否则直接把该 ctx 特征的最后一个 producer（func_vec.back()）作为父，即依赖最近的 producer。

含义/理由：
- 处理 ctx 特征时优先考虑“最近的 producer”。若同一个 functor 集合中某个 functor 既输出又依赖该 fea，则它应该依赖前一个输出该 fea 的 functor（形成串行化）。

3) 处理输出 item 特征（特殊处理 kFeaGLocation）
```text
for (const auto& p: output_item_fea_functors) {
  if (p.first == kFeaGLocation) {
    const auto& fs = p.second;
    for (size_t i = 0; i < fs.size() - 1; ++i) {
      dag_map[fs[i]].insert(fs[i+1]);
      if (fs[i]->Stage() == FunctorStage::RECALL && fs[i+1]->Stage() == FunctorStage::RECALL
          && fs[i]->Type() == FunctorType::ARRANGER && fs[i+1]->Type() == FunctorType::ARRANGER) {
        static_cast<Arranger*>(fs[i])->set_arrange_item(false);
      }
    }
  }
  // debug logging of producers for output-feature p.first
}
```
解释：
- 对于输出为 `kFeaGLocation`（通常表示位置/位置信息链）的 fea，直接把该 fea 的 producers 串联成链：producer[i] -> producer[i+1]。这是因为多个 arranger 在位置输出上具有顺序关系，后一个需要在前一个之后执行。
- 额外：如果相邻的两个 producer 都是 RECALL 阶段的 ARRANGER，则把前一个 arranger 的 arrange_item 标记为 false（表示它不再做位置的 arrange，可能交由后续合并器统一处理）。这是保证多个 arranger 在 recall 阶段的特殊协作逻辑。

含义：
- kFeaGLocation 的 producers 序列是按 functors_ 的顺序形成明确的链，这影响最终 DAG 中的串行执行路径。

4) 处理 require item 特征（大多数 item fea ）
```text
const std::unordered_set<std::string> parallel_item_feas { ... };
for (const auto& p: require_item_fea_functors) {
  const auto& fea = p.first;
  const auto& functors = p.second;
  auto iter = output_item_fea_functors.find(fea);
  if (iter != output_item_fea_functors.end()) {
    if (parallel_item_feas.count(fea)) {
      for (const auto functor: functors) {
        for (const auto parent: iter->second) {
          dag_map[parent].insert(functor);
        }
      }
      continue;
    }
    dag_map[iter->second.back()].insert(functors[0]);
    for (size_t i = 1; i < functors.size(); ++i) {
      if (dag_map[functors[i-1]].count(functors[i])) {
        continue;
      }
      dag_map[iter->second.back()].insert(functors[i]);
    }
  }
  // debug log listing dependents
}
```
解释：
- `require_item_fea_functors` 列出了那些依赖某 item 特征的 functors（可认为是 consumers）。
- 若该 fea 有 producers（output_item_fea_functors 中存在）：
  - 如果该 fea 在 `parallel_item_feas` 集合中（例如 recall item、merge recall item、各种 filter 列表），说明 producers 与 consumers 之间可以并行：对每个 consumer，将每个 producer 都作为父（所有 producer -> consumer），从而允许 consumer 在任一 producer 完成或所有 producer 完成后的特定运行方式（取决于 Node 的 parent counting 行为）。
  - 否则（默认串行语义）：把 producers 的最后一个 producer（iter->second.back()）作为 consumers[0] 的父（最近的 producer 作为第一个 consumer 的父）。对于后续 consumer（functors[1..]），如果它们之间已由先前的 `dag_map` 强连线（即 functors[i-1] -> functors[i]）则跳过，否则把最新 producer（iter->second.back()）也作为父。该逻辑把 consumers 串联或把 producer 作为多个 consumers 的共同父，具体依赖于先前的 dag_map 状态。
- 注：该逻辑试图在“producer 多 → consumer 多”的场景中，按照业务规则决定并行或串行关系。

5) 为每个 dag_map 条目创建 Node 并连接边
```text
for (const auto& p: dag_map) {
  auto parent_accessor = AdaptAccessor(p.first);
  parent_accessor->PreAllocateResource(p.first->strategy_id());
  auto parent = strategy_executor_->graph_->AddNode(parent_accessor, p.first);
  for (const auto node: p.second) {
    if (p.first != node) {
      auto child_accessor = AdaptAccessor(node);
      auto child = strategy_executor_->graph_->AddNode(child_accessor, node);
      parent->AddChildren(child);
    }
  }
}
```
解释：
- 遍历每个 parent functor（p.first）及其子集合（p.second）。
- 为 parent 选取合适的 Accessor（AdaptAccessor 根据 rebuild 状态返回主 accessor 或 rebuild_accessor）。
- 调用 `parent_accessor->PreAllocateResource(parent->strategy_id())`：预分配该策略运行时需要的资源（可能是 item buffers、vector reserve、临时容器等），减少运行时动态分配。
- 通过 `graph_->AddNode(parent_accessor, p.first)` 创建/复用 Node（内部会创建 shared_ptr<Node>，调用 InitializeCallback）。
- 对于每个 child：若 child != parent（避免自环），获取 child_accessor、AddNode(child), 并通过 parent->AddChildren(child) 建立边。`AddChildren` 会在 child 上增加 parent count（child->parent_cnt_++），并将 child 放入 parent.children_nodes_。

意图/效果：
- 这一步把从依赖分析得到的指针关系物化为 Graph 的节点和边，Graph 随后会在 `Graph::Run` 中按 parent_cnt_ 和 parent_done_cnt_ 来 orchestrate 节点执行。

