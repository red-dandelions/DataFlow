# Graph::Run流程分析

---

## 概念
- Node：代表图中一个可执行单位（包装一个 `Functor`）。负责调用 `Functor`、统计耗时、在完成后触发子节点（children）。
- Graph：管理所有 Node、建立父子关系、启动起点（start nodes）执行，并在所有终点（end nodes）完成后一次性触发结束回调（end_cb）。

---

## 一、Node 的代码

文件：graph.cc

1) 构造函数（语义）
```cpp
Node::Node(Accessor* accessor, Functor* functor, Graph* graph)
    : accessor_(accessor), functor_(functor), graph_(graph) {
}
```
要点：保存指向请求上下文（`accessor`）、要执行的策略单元（`functor`）和所属图（`graph`）的裸指针。Node 不拥有这些对象，执行时假设它们在生命周期内有效。

2) 初始化回调
```cpp
void Node::InitializeCallback() {
    auto self = shared_from_this();
    functor_->SetCallback([self]() mutable {
        self->Report();
        self->RunChilds();
    });
}
```
解释（：
- `shared_from_this()` 返回一个 `shared_ptr<Node>`，保证 lambda 捕获的是一个智能指针，这样当 functor 在其它线程调用回调时，Node 不会被析构（防止野指针）。
- 把这个 lambda 设置为 `functor` 的回调。回调做两件事：
  1. `Report()`：收集并上报当前节点耗时与指标。
  2. `RunChilds()`：触发所有子节点的执行尝试（见下面 RunChilds 的逻辑）。

为什么这样：无论 `Functor` 是同步执行还是内部异步（例如发 RPC），只要完成就会调用它的 callback，从而保证 `Report` 与 `RunChilds` 被执行。

3) Run — 关键函数
```cpp
void Node::Run() {
    size_t cnt = parent_cnt_;
    auto is_async = functor_->is_async() && functor_->support_async();
    auto call_fmp = functor_->dsl_helper()->call_fmp();
    auto self = shared_from_this(); // hold on 对象声明周期
    if (parent_done_cnt_.compare_exchange_strong(cnt, cnt+1,
                                                 std::memory_order_acq_rel)) {
        util::DateTime dt;
        start_ms_ = dt.GetTimeMs();
        LOG_DEBUG << "run functor:" << functor_->strategy_id();
        functor_->PrepareRun(accessor_);
        if (!graph_->controller()->AllowRun(self) || !functor_->IsStrategyEffect(accessor_)) {
            if (functor_->has_degrade_run()) {
                functor_->DegradeRun(accessor_);
                return;
            }
            if (functor_->Type() == FunctorType::ARRANGER
                && functor_->Stage() == FunctorStage::RECALL
                && static_cast<Arranger*>(functor_)->arrange_item()) {
                accessor_->ArrangeBy(kFeaGLocation);
            }
            return functor_->GetCallback()();
        }
        ...
        if (functor_->is_async() && functor_->support_async()) {
            functor_->Run(accessor_);
        } else {
            if (!functor_->Run(accessor_)) {
                if (functor_->Type() == FunctorType::ARRANGER
                    && functor_->Stage() == FunctorStage::RECALL
                    && static_cast<Arranger*>(functor_)->arrange_item()) {
                    accessor_->ArrangeBy(kFeaGLocation);
                }
            }
            functor_->GetCallback()();
        }
    }
}
```

逐行解读：
- `size_t cnt = parent_cnt_;`：把父节点数量读到本地变量 `cnt`。
- `parent_done_cnt_.compare_exchange_strong(cnt, cnt+1, ...)`：这一步是“门”：
  - 如果 `parent_done_cnt_` 的当前值等于 `cnt`（也就是父完成计数刚好等于父数量），它将 `parent_done_cnt_` 设为 `cnt+1` 并返回 true —— 表示允许真正的执行体进入并执行一次。
  - 否则返回 false（并把实际 `parent_done_cnt_` 的值写回 `cnt`），表示“还没到所有父完成的时刻”，什么都不做。
- 这个设计让 Node::Run 可以被多次调用（每个父完成时常会调用一次），但是只有最后一次会成功进入执行体，保证“只在所有父完成之后运行一次”。
- `PrepareRun`：functor 的预处理（清容器、初始化上下文等）。
- `controller()->AllowRun(self)` 和 `IsStrategyEffect(accessor_)`：控制规则决定是否真的运行；如果不允许并且有降级实现（`has_degrade_run()`），会执行降级路径；否则直接调用 `functor_->GetCallback()()` （等同于“立即完成”）。
- `is_async` 分支：
  - 若 `functor` 标记为异步，调用 `functor_->Run(accessor_)` 即可；functor 内部应在异步完成时调用之前设置的 callback（Node::InitializeCallback 设置）。
  - 否则（同步），在 `Run` 返回后立刻调用 `functor_->GetCallback()()` — 这会触发 Node::Report 和 RunChilds（即同步链路继续推进）。

直白比喻：Node 像一扇门，`parent_done_cnt_` 是在门外等候的人数；只有当最后一个人到门口（父完成并把计数++）并由线程尝试打开门（Run）时，门才会真正打开并执行一次门内的工作。

4) RunChilds — 触发子节点的“父完成”信号
```cpp
void Node::RunChilds() {
    for (auto child: children_nodes_) {
        LOG_DEBUG << "try run child:" << child->name();
        StrategyAsyncPool::get_mutable_instance().Async([child]() {
            child->parent_done_cnt_.fetch_add(1, std::memory_order_relaxed);
            child->Run();
        }, accessor_->trace_key());
    }
}
```
解释：
- 对每个子节点，提交一个异步任务到线程池。该任务先把子节点的 `parent_done_cnt_` ++，然后调用 `child->Run()`。
- 这就产生了上文“门被逐个父唤醒”的机制：父完成触发一次异步提交，子节点在收到每个 parent 的 ++ 后会在某次 `Run()` 中最终进入其执行体（当 ++ 达到 parent_cnt_ 时）。

注意要点：
- `fetch_add` 先做 ++，再调用 `Run()`，保证 `child->Run()` 内的 compare_exchange 能看到更新后的值（减少竞态）。
- `StrategyAsyncPool::Async` 把动作放到线程池，child 的 `Run()` 也在池线程中执行，减少主线程阻塞。

5) Report — 汇报耗时并记录
```cpp
void Node::Report() {
    util::DateTime dt;
    const auto now = dt.GetTimeMs();
    uint64_t rt = now - this->start_ms_;
    const auto graph_cost = now - this->graph_ms_;
    if (functor_->Type() == FunctorType::FURTHER_MERGER_ARRANGER) {
        graph_->set_merge_cost(graph_cost);
    }
    if (functor_->Type() == FunctorType::REPORTER ||
        functor_->Type() == FunctorType::REC_MARK_REPORTER) {
        graph_->set_stage_cost(FunctorStage::REPORT, graph_cost);
    } else {
        graph_->set_stage_cost(functor_->Stage(), graph_cost);
    }
    ... debug explain ... 
    accessor_->AddCtxMonitorV2(functor_->strategy_id(), "cost", rt);
}
```
解释：
- 计算本节点耗时并把它放到 Graph 的 stage/merge 汇总里（Graph 后面统一 Report）并把单节点成本记录到 `Accessor` 的监控里。

---

## 二、Graph 的代码与执行流程

文件：graph.cc

1) `Graph::Bind`
```cpp
bool Graph::Bind(Accessor* accessor, StrategyController* controller) {
    accessor_ = accessor;
    controller_ = controller;
    return true;
}
```
说明：保存访问器与控制器。注意：没有做 `nullptr` 校验，后续所有操作都假定它们有效。

2) `Graph::AddNode`（用于去重并创建 Node）
```cpp
std::shared_ptr<Node> Graph::AddNode(Accessor* accessor, Functor* functor) {
    auto exist_node = GetNode(functor->strategy_id());
    if (exist_node) {
        return exist_node;
    }
    auto new_node = std::make_shared<Node>(accessor, functor, this);
    new_node->InitializeCallback();
    nodes_.emplace_back(new_node);
    node_map_.insert({new_node->name(), new_node});
    return new_node;
}
```
解释：
- 用 `functor->strategy_id()` 作为 Node 名称做去重。如果已存在同名 Node，就复用它（避免重复节点）。
- 新建 Node 后立即调用 `InitializeCallback()`，把 functor 的回调设置到 Node 所定义的 lambda（Report + RunChilds）。

3) `Graph::Run`（核心：如何启动整个 DAG）
```cpp
bool Graph::Run(std::function<void()>&& end_cb) {
    end_cb_ = std::move(end_cb);
    util::DateTime dt;
    const auto graph_ms = dt.GetTimeMs();
    std::vector<std::shared_ptr<Node>> start_nodes, end_nodes;
    accessor_->AddCtxMonitorV2("service_info", "node_count", node_map_.size());
    for (auto& p: node_map_) {
        auto node = p.second;
        node->graph_ms_ = graph_ms;
        node->timeout_ = timeout_;
        if (!node->ParentCount()) {
            start_nodes.push_back(node);
        }
        if (!node->ChildrenCount()) {
            end_nodes.push_back(node);
        }
    }
    if (start_nodes.empty() || end_nodes.empty()) {
        LOG_ERROR << "dag not valid, start_nodes.size()=" << start_nodes.size()
                  << ", end_nodes.size()=" << end_nodes.size();
        end_cb_();
        return false;
    }
    for (auto node: end_nodes) {
        node->functor_->SetCallback([this, node, cnt = end_nodes.size()]() mutable {
            node->Report();
            LOG_DEBUG << "end node:" << node->name();
            end_done_cnt_.fetch_add(1, std::memory_order_relaxed);
            if (end_done_cnt_.compare_exchange_strong(cnt, cnt+1,
                                                      std::memory_order_acq_rel)) {
                this->Report();
                end_cb_();
            }
        });
    }
    for (auto node: start_nodes) {
        StrategyAsyncPool::get_mutable_instance().Async([node]() { node->Run(); }, accessor_->trace_key());
    }
    return true;
}
```

逐段解释：
- `end_cb_ = std::move(end_cb);`：保存由上层（通常是 `StrategyExecutor`）传来的“全图完成时要执行的回调”，Graph 会在最后调用它（注意：回调会在异步池线程中运行）。
- 遍历 `node_map_`：
  - 给每个 node 设定 `graph_ms_`（图开始时间）与 `timeout_`。
  - 找出所有 `start_nodes`（没有父）和 `end_nodes`（没有子）。
- 如果 `start_nodes.empty()` 或 `end_nodes.empty()`，说明 DAG 构建不合法。代码会：
  - 记录错误并 `end_cb_()`（同步调用）后返回 false —— 这意味着在失败路径回调是同步调用（请记住，成功路径回调在异步池线程）。
- 对于 `end_nodes`，**重写它们的 functor 回调** 为一个特殊回调：每当 end node 完成就 `end_done_cnt_.fetch_add(1)`；如果这是最后一个 end node（即 `end_done_cnt_` 在 compare_exchange 中等于 cnt），就执行 `this->Report()`（全图上报）并调用 `end_cb_()`（触发上层收尾逻辑）。
  - 这个 compare_exchange 模式和 Node::Run 中的 parent gate 是同样的思路：只让最终一次触发去跑全局收尾，避免多次触发。
- 最后把 `start_nodes` 都提交到线程池执行 `node->Run()`（异步开始执行图）。
- 返回 true 表示图已启动（收尾回调将在异步线程执行）。

4) `Graph::HasLoop`（环检测）
- 使用 DFS 检测 DAG 中是否存在环（若有环， `AsyncDAG` 会在启动前拒绝并同步调用回调）。如果看到 Graph 报环路，用 `graph_->Dump()` 的输出查看具体环节点列表。

---

## 三、从上层到下层的完整调用链

假设一个最简单的 DAG：A 和 B 都是 start nodes，C 有两个父（A、B），C 是 end node。

1) 上层：
- `StrategyExecutor::AsyncDAG(cb)` 调用 `analyzer_->BuildDAG(...)` 生成 Graph（A,B,C），然后 `graph_->Run(cb)`。
2) `Graph::Run`：
- start_nodes = [A, B]，end_nodes = [C]。
- 对 C 重写 callback：当 C 完成并且是最后一个 end 节点时（这里只剩 C），执行 `end_cb_()`。
- 把 A 和 B 都提交到线程池：`Async([A]{ A->Run(); })`，`Async([B]{ B->Run(); })`。
3) 假设线程池分配线程分别执行 A 与 B：
- A 执行完后触发其 functor 的 callback（Node::InitializeCallback 里设置），导致：
  - A->Report()
  - A->RunChilds()：对 C 提交 `Async([C]{ C->parent_done_cnt_++ ; C->Run(); })`
- B 执行同理，提交一次 C 的任务并做 `fetch_add`。
4) C 的行为（父为 2）：
- 第一次父完成时：`parent_done_cnt_` 从 0 -> 1，`C->Run()` 的 compare_exchange 失败（因为 parent_cnt_ == 2），什么都不做。
- 第二次父完成时：`parent_done_cnt_` 从 1 -> 2，然后 `C->Run()` 的 compare_exchange 成功（parent_done_cnt_==parent_cnt_），C 真正执行；执行完成后 C 的 callback 会触发 Graph 的 end logic（因为 C 是唯一 end node），从而 `end_cb_()` 被调用。
5) `end_cb_()`（在池线程中）通常做：写 response、RunFinishJob、metrics 等，最后释放/复用 executor。

数字举例（更直观）：
- parent_cnt_(C) = 2
- 初始 parent_done_cnt_(C) = 0
- A 完成 => 提交 child任务 =>  parent_done_cnt_ = 1 => C->Run() 被尝试但不执行主体。
- B 完成 => 提交 child任务 =>  parent_done_cnt_ = 2 => C->Run() 在这次调用进入主体且被执行一次；C 完成后触发 end_cb。

---

# start Node 的 Aync 调用

`StrategyAsyncPool::Async(...)` 并不是把任务直接放到 std::thread 或简单队列里，而是通过底层的通用 `service_comm::AsyncPool`（RPC/HTTP 复用的异步池）以“FakeInvoke”方式把任务打包成一个事件（Context），推入 gRPC 的 CompletionQueue，再由 AsyncPool 的 worker 线程在 CQ 上取出并执行函数（在池线程上执行）。也就是说：Async -> FakeInvoke（构造 Context、Set Alarm/Cancel）-> 全局 CQ 收到事件 -> worker 线程运行 callback。

下面按步骤、并结合具体代码行把每一步拆开讲清楚。

1) 关键调用点
- 在 graph.cc 中调用：
  StrategyAsyncPool::get_mutable_instance().Async([node]() { node->Run(); }, accessor_->trace_key());
- `Async` 的实现位置：strategy_pool.h：
  template <typename F>
  void Async(F&& func, const std::string& trace_key) {
      async_pool_->FakeInvoke<fmp::ItemFeatureService>( &fmp::ItemFeatureService::Stub::PrepareAsyncGetItemFeature,
          func=std::move(func){ func(); }, trace_key);
  }
  -> 也就是把传入的 lambda 包装成一个 RPC 风格的“fake”上下文，并交给底层 `AsyncPool::FakeInvoke`。

2) 底层是什么：`service_comm::AsyncPool`（定义在 async_pool.h）
- `StrategyAsyncPool` 在 strategy_pool.cc 初始化时会 `async_pool_.reset(new StrategyAsyncPoolImpl());` 然后 `async_pool_->Run(thread_num, cq_num);`
- `AsyncPool::Run(...)` 的关键行为：
  - 创建一个全局 `cq_`（grpc::CompletionQueue），以及若干 per-service `cqs_`（vector of CompletionQueue）。
  - 启动多组线程：
    - 若干线程轮询 `cqs_`（per-service CQ），当某个 RPC 的响应（或 fake 事件）到来时，这些线程把事件“转发”到全局 `cq_`（通过创建并 cancel 一个 grpc::Alarm，下面会解释）。
    - 若干 worker 线程监听全局 `cq_`（cq_->Next），取出事件（tag），把 tag 转换为 BaseContext 指针并执行 `ctx->Run(ctx->cost)`（这里会调用我们放入 ctx 的 callback）。
    - 还有一个线程专门处理 libcurl HTTP 多路复用（非重点）。

3) FakeInvoke 的工作（把任务放进 CQ）
- 在 `AsyncPool` 中，FakeInvoke 的实现（简化说明）：
  - new 一个 CallContext（继承自 BaseContext），设置 ctx->type = FAKE，ctx->cb.swap(cb)（把回调装入 ctx），ctx->start = now。
  - 创建一个 grpc::Alarm： ctx->alarm.reset(new grpc::Alarm);
  - 调用 ctx->alarm->Set(cq_.get(), now + 秒数, ctx);
  - 立刻调用 ctx->alarm->Cancel();
- 为什么这么做？
  - grpc::Alarm 用来向 CompletionQueue 投递一个“tag”（这里 tag 是 ctx 指针）。Set 然后 Cancel 会导致一个到 `cq_` 的完成事件（以 tag=ctx）被触发（实现上会产生一次 CompletionQueue 的事件），从而让监听 `cq_` 的 worker 线程尽快收到并处理这个 ctx。
  - FakeInvoke 通过 Alarm 的 Set/Cancel 把一个“立即”事件投递到全局 cq_，起到“把我们的回调调度到 AsyncPool 的 worker 线程执行”的作用。

4) 全部流程（带代码/线程定位，逐步）
- 调用： StrategyAsyncPool::get_mutable_instance().Async(lambda, trace_key)
  - 转到： StrategyAsyncPool::Async -> async_pool_->FakeInvoke(..., cb, trace_key)
- FakeInvoke 执行（在调用线程）：
  - new CallContext<...>* ctx = new CallContext...
  - ctx->type = FAKE; ctx->cb.swap(cb); ctx->start = now; ctx->trace_info.save(); ctx->alarm.reset(new grpc::Alarm);
  - ctx->alarm->Set(cq_.get(), now + seconds(1024), ctx);
  - ctx->alarm->Cancel();
  - 返回 true。
- gRPC internals / AsyncPool:
  - Set + Cancel 会让 `cq_` 产生一次事件，其 tag 等于 `ctx`。全局 worker 线程在 `cq_->Next(&tag, &ok)` 处会接收到 (tag=ctx)。
- 全局 worker 线程（在 `AsyncPool::Run` 的线程组中）：
  - `void* tag = nullptr; bool ok=false; cq_->Next(&tag,&ok)` 返回后，线程做：
    std::unique_ptr<BaseContext> ctx(static_cast<BaseContext*>(tag));
    auto now = ...; ctx->cost = ...;
    ctx->trace_info.toenv(); // 恢复日志上下文（trace id 等）
    ctx->Run(ctx->cost); // 关键：CallContext::Run 会调用我们放进 ctx 的 cb
    if (tracer_) tracer_(*ctx);
  - 由于 ctx 是 unique_ptr，当处理完成后 ctx 会被自动 delete（释放内存）。
- cb 执行位置：worker 线程（非调用线程），cb 接收的参数是 `grpc::Status` / cost / response 指针，但 FakeInvoke 的 cb 在 StrategyPool::Async 中被包装成 `[func=...] (const grpc::Status&, const uint32_t, fmp::ItemFeatureResponse*) { func(); }`，也就是忽略输入参数，直接执行你传进来的 `func()`（例如 node->Run())。

5) 为什么要走 gRPC 的 CQ / Alarm 路径？（设计目的）
- `AsyncPool` 是一个通用的异步执行器，兼顾：
  - 真正的 gRPC 异步调用（通过 per-service cqs_ 收到 RPC 完成事件，再转发到全局 cq_）。
  - libcurl HTTP 的异步完成。
  - “Fake” 任务（Quick task）也通过同一条通路调度到相同的 worker 池执行，这样所有任务和 RPC 响应都在同一组线程上执行回调，便于统一追踪、上下文恢复（trace）和统一计时/打点（tracer_）。
- 使用 Alarm 的 Set+Cancel 是一个已知的技巧，用来把任意自定义事件放入 grpc::CompletionQueue 进行统一调度。

6) 关于 trace_key / trace_info
- 在 FakeInvoke 和 CallContext 创建时，`ctx->trace_info.save()` 会把当前线程日志上下文（LogCenter::traceID_ 等）保存进 ctx。
- 当 worker 线程处理该 ctx 时，会调用 `ctx->trace_info.toenv()` 恢复这些日志上下文，从而保证无论回调在哪个线程执行，日志中的 trace id / step 信息都是一致的，便于关联请求日志。
- `trace_key` 在 FakeInvoke 的实现里并未显著使用，但很多调用点都把 `accessor_->trace_key()` 传入，这在某些 Invoke 路径或未来扩展可能会被用来设置 metadata 或做路由。当前核心是 `ctx->trace_info` 的保存/恢复来保证日志 trace。

7) 内存与生命周期
- ctx 是用 new 分配的；当 global cq_ worker 线程取到 tag 时，会用 unique_ptr<BaseContext> ctx(static_cast<BaseContext*>(tag)); 这样在 worker 执行完成后 ctx 会自动 delete，不会泄漏。
- 你传入 Async 的 lambda 捕获了 Node 的 shared_ptr（在 graph.cc 里通常捕获的是 shared_ptr<Node>），这保证了 Node 在 lambda 执行期间不会被析构（非常重要）。
- 因此在使用 Async 提交 `node` 时常见安全做法是：传 lambda 捕获 shared_ptr（或传值 capture），不要捕获裸指针或 reference 到短生命周期对象。

8) 线程/队列/并发注意点
- 调度线程：
  - per-service cqs_ 线程组：负责将 RPC 完成的事件转换为全局 cq_ 事件（通过 Alarm trick）。
  - 全局 cq_ worker 线程组：真正调用 ctx->Run（执行回调）的线程。
  - curl 线程：处理 HTTP 完成。
- 并发：
  - FakeInvoke 立即把事件放到 cq_，并不会阻塞调用线程；实际执行在 worker 线程。
  - worker 线程数在 `AsyncPool::Run(thread_num, cq_num)` 时设置（由配置 async_pool_thread_num），如果 worker 数小而任务多，会出现队列积压与延迟。
- 队列饱和/阻塞：
  - gRPC CompletionQueue 是阻塞等待 Next() 的；任务积压时 Next() 会逐个返回，延迟增长。
  - 如果有大量短任务（例如 Node->RunChilds 每个 child 都用 Async 提交），线程池尺寸和任务粒度需要调优，否则可能造成线程切换/队列延迟。

9) 错误处理与超时
- FakeInvoke 的 ctx->Run 会在 worker 中直接执行 cb；如果 cb 抛异常（throw），AsyncPool 的 worker 没有显式 try/catch（在当前代码中），异常会终止线程或导致未定义行为。因此：callback 内部不应抛异常，最好捕获异常并记录。
- 对于真实 RPC 的 InvokeImpl：它设置了 ctx->cli_ctx.set_deadline(deadline); 当 RPC 到期会有 status 非 OK，最终会触发 ctx->Run 并执行带 status 参数的 cb。FakeInvoke 不和 real RPC 一样有超时，因为 FakeInvoke 只是把任务放到队列。
- Alarm 的 deadline 使用较大的值（1024 秒）只是为了完成 tag 转发，不是做单任务超时控制。
