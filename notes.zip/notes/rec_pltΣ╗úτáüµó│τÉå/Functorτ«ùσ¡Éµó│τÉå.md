# Functor算子梳理

## 概览 — Functor 在整个系统中的角色
- Functor 是「策略算子（strategy operator）」的抽象。每个策略（strategy）在执行图（Graph → Node）中由一个 Functor 实例来执行具体逻辑（召回、粗排、重排、合并、上报等）。  
- 一个 request 有一个 `Accessor`（请求上下文），Analyzer 会为每个策略创建 Functor，并构建成 DAG 的 Node。Graph 调度时会调用 Functor 的 `PrepareRun`/`Run`，Functor 执行完后通过回调告知 Graph/Node 继续走下游。
- 设计目标：把“业务算子逻辑”与“执行调度/异步框架”分离。Functor 负责业务（读写 `Accessor`、发 RPC、生成特征等）；Node/Graph/AsyncPool 负责调度与并发。

## Inputs/Outputs/Error
- 输入：`Accessor* accessor`（请求级上下文、已有 item、已有特征） + Functor 自身的 strategy_id、param。  
- 输出：把结果写回 `Accessor`（例如：`AddRecallItem`, `AddRecallItemFeature`, `AddItemFeature`, `AddCtxFeature`），并触发它的 callback（由 Node 设置）。  
- 成功 / 完成信号：当一个 Functor 完成其业务（同步或异步），必须保证 Node 中为其设置的回调最终被执行一次（通过 `GetCallback()`）。  
- 错误模式：若缺少必要数据，应走降级（若 `has_degrade_run()` 为真）或记录错误并尽可能触发回调以不中断 DAG。

## Functor 类关键字段与作用
- dsl_helper_ (unique_ptr<DslHelper>)：用于 DSL 类型的特征生成 / 处理。很多 Functor 用 DSL 来生成或校验特征。
- std::atomic<bool> has_run_{false}：保护 callback 只执行一次（`GetCallback()` 内部用它做 dedup-check 并在重复调用时报错日志）。
- Callback cb_ / empty_cb_：cb_ 是实际回调（由 Node::InitializeCallback 设置为：Report + RunChilds），empty_cb_ 是安全兜底。
- bool is_async_ / support_async()：标注该算子是否按“异步语义”执行。`is_async_` 是运行时标记，`support_async()` 是子类可覆盖的 capability（是否能自己在内部调用 cb）。
- strategy_id_, functor_name_, stage_：策略标识与阶段（RECALL/PRERANK/…）等，用于路由/日志/度量。
- required_* / output_* / report_* name sets：声明输入输出特征名，Analyzer 在构建阶段会用到这些声明来决定依赖与预置。
- dsl_effect_generater_、local_ctx_feature_：用于 DSL 的“是否生效”判断与中间特征上报。

## 关键方法语义
- Reset()：把内部状态复位，供 Functor 池复用时调用（非常重要）。派生类若有额外资源也应重写并在 Reset 中清理。
- Bind(strategy_id, param)：把策略 id、参数与需要的输入输出特征名绑定到 Functor（Analyzer 调用）。派生类可以在 Bind 中解析 param 并填充 required_xxx 集合。
- Init()：可选的启动时初始化（例如创建 client、预热资源）。
- support_async()：若 Functor 可以在内部做异步（自己负责什么时候执行回调），覆盖并返回 true。否则为 false，Node 会在 Run 调用后代为触发回调。
- has_degrade_run() / DegradeRun(Accessor*)：支持降级逻辑。若返回 true 且发生条件不满足，可以在降级路径里写入替代结果并触发回调（或返回）。
- PrepareRun(Accessor*)：运行前准备（例如检查 feature 是否存在、填充临时状态），Node 在执行 Run 前会调用它。
- virtual bool Run(Accessor* accessor) = 0：派生必须实现。语义：
  - 对于“同步” Functor（support_async()==false）：实现 Run 并返回 `true/false` （实际代码中 Node 对结果的利用不完全严格，Node 在 sync 情况下会在 Run 返回后立刻调用 `functor_->GetCallback()`，因此同步 Functor 应在返回前完成所有写入和清理）。
  - 对于“异步” Functor（support_async()==true 且 is_async 标记为 true）：Run 应发起异步操作（RPC、外部客户端、timer 等），并保证在异步完成时在回调里调用 `GetCallback()`（Node 不会自动调用）。
- SetCallback / GetCallback：
  - Node 在创建 Node 时会通过 `functor_->SetCallback([self]() { self->Report(); self->RunChilds(); });` 把回调设置为“上报并触发子节点”；
  - `GetCallback()` 返回 `cb_` 并保证该回调只会真正被“允许执行”一次（通过 `has_run_` 原子）。若重复调用会打印错误并返回 `empty_cb_`。
  - 因此：要么由 Node（同步）调用 `GetCallback()`，要么由 Functor（异步场景）在完成时自己调用 `GetCallback()`。不要两边都调用两次。

## Node/Graph 与 Functor 的交互
1. Analyzer 构建 Functor 实例并通过 Graph::AddNode 将 Functor 放在 Node 中。Node 在构造后会调用 `InitializeCallback()` 设定 functor 的 cb（cb 做 Report + RunChilds）。  
2. Graph::Run 把所有无父节点的 Node 提交给 AsyncPool 执行（start nodes）。  
3. Node::Run 调用：PrepareRun -> 考察是否 AllowRun / IsStrategyEffect -> 若 functor 需要 DSL 可能调用 `GenerateFeature` -> 根据 `is_async()` 和 `support_async()` 选择：
   - 同步：`functor_->Run(accessor_)` 执行并返回；Node 接着调用 `functor_->GetCallback()()` 来完成节点（Report + 子节点触发）。
   - 异步：`functor_->Run(accessor_)` 发起异步 RPC/操作，Functors 自己在 RPC 的完成回调里写回 `Accessor` 并调用 `GetCallback()`，Node 不直接调用回调。
4. 子节点在其 parent 完成后通过 `parent_done_cnt_` 控制何时真正执行（并被 AsyncPool 再次调度执行）。

## 常见使用场景与派生类模式（按推荐系统阶段）
- Recall（召回）算子（通常异步）：
  - 功能：从外部召回服务获取 candidate ids + score；把结果写到 `accessor->AddRecallItem(...)` 或 `AddRecallItemFeature(...)`；然后调用 `GetCallback()`。
  - 特点：通常大量异步 RPC，需要批量/限流/timeout 管理；support_async() 返回 true。
  - 示例：调用 `AsyncQueryItemFea` 或直接使用 client.Async(...)，在 RPC 回调中写回并 `GetCallback()`。
- Arranger / Merger（合并、粗排、编排）算子（通常同步）：
  - 功能：基于已有 `Accessor::item_feature()` 做排序、过滤或合并位置（kFeaGLocation、kFeaGScore 等）；写回 `AddItemFeature(kFeaGLocation, ...)` 等。
  - 特点：通常是 CPU-bound，同步执行，Node 在 Run 后会马上调用 callback。
- Prerank / Rank / Rerank（模型调用）：
  - 可能是同步或异步，视模型客户端是否是异步 RPC；若为 RPC → 通常是异步（support_async true）并在 RPC 回调里写回模型输出并调用 `GetCallback()`。
- Reporter：几乎是同步，做监控/上报，不改变核心执行流（见你 repo 的 `Reporter` 已实现）。

## 如何实现一个派生 Functor（步骤 + 同步/异步示例）
下面给出两个最小示例：同步 arranger（简单操作 item feature）和异步 recall（发 RPC 并在回调里写回）。

示例 A：同步 arranger（伪代码）
```cpp
class SimpleArranger : public Functor {
public:
  SimpleArranger() {}
  virtual ~SimpleArranger() {}
  virtual FunctorType Type() const override { return FunctorType::ARRANGER; }
  virtual bool Bind(const std::string& strategy_id, const StrategyParam& param) override {
    Functor::Bind(strategy_id, param);
    // 如果此 arranger 需要 kFeaGScore/kFeaGLocation，声明依赖，方便 Analyzer 做依赖分析
    SetRequiredItemFeaName(kFeaGScore);
    SetOutputItemFeaName(kFeaGLocation);
    return true;
  }

  virtual bool Run(Accessor* accessor) override {
    // 读取当前 items 的 score 和 location
    auto score_ptr = accessor->GetOriginItemFeaturePtr<fmp::FLOAT>(kFeaGScore);
    if (!score_ptr) {
      // 无分数，做降级或返回 false
      return false;
    }
    // ... 执行排序/重排逻辑，构建新的 location vector ...
    auto new_loc = feature::FeatureFactory::CreateVector<int64_t>(std::move(loc_vec));
    accessor->AddItemFeature(kFeaGLocation, new_loc);
    // 对同步算子：Node 在 Run 后会自动调用 GetCallback()
    return true;
  }
};
```

示例 B：异步 recall（伪代码，使用 repo 中的 AsyncQueryItemFea helper）
```cpp
class MyRecallFunctor : public Functor {
public:
  MyRecallFunctor(acc::ItemFeatureClient* client) : client_(client) { set_async(true); }
  virtual ~MyRecallFunctor() {}
  virtual FunctorType Type() const override { return FunctorType::RECALL; }
  virtual bool support_async() const noexcept override { return true; } // 支持内部回调
  virtual bool Bind(const std::string& sid, const StrategyParam& param) override {
    Functor::Bind(sid, param);
    // 如果需要把召回结果写入某个 recall 特征
    SetOutputItemFeaName(kFeaGRecallId);
    return true;
  }

  virtual bool Run(Accessor* accessor) override {
    // 构建 recall 请求（item ids 或用户向量等）
    std::vector<int64_t> req_ids = BuildIdsFromAccessor(accessor);
    // 发起异步调用（示例使用 AsyncQueryItemFea wrapper）
    AsyncQueryItemFea(accessor, client_, req_ids, {"feaA", "feaB"},
      [this, accessor]() mutable {
        // 这是 RPC 完成时在 AsyncPool worker 线程执行的回调
        // 把 rpc 返回的结果写回 accessor
        accessor->AddRecallItem(strategy_id(), item_ids, item_scores);
        accessor->AddRecallItemFeature(strategy_id(), kFeaGScore, score_feature_ptr);
        // 标志完成：调用 Node 设置的 callback（只会执行一次）
        this->GetCallback()();
      }
    );
    // 对于异步算子：Run 立即返回 (true/false 没那么重要)，真正的 completion 由回调调用 GetCallback()
    return true;
  }
private:
  acc::ItemFeatureClient* client_;
};
```

注意点：
- 异步函数中的 lambda 捕获 `accessor` 时要小心生命周期（确保 accessor 在回调执行时仍然有效——一般请求周期保证 Accessor 存活直到 Graph 完成，但最好避免捕获裸指针到长存储结构中）。在你的代码中 AsyncPool worker 会在请求结束前完成回调，通常是安全的，但要小心异常与超时。
- 一定在回调中调用 `GetCallback()`（不在别处重复调用）。

## DSLHelper 与特征生成
- Functor 构造时创建了 `DslHelper`（见 functor.h 中 dsl_helper_），并提供 `InitDslHelper(...)` 接口。DSL 用于按规则生成特征或判定生效。  
- Node::Run 中的逻辑：
  - 若 functor_->dsl_helper()->need_dsl() 且 `call_fmp` 的配置为某种情况，`GenerateFeature` 可能会把 callback 嵌入到 DSL 的执行流程中（即 DSL 本身执行完毕后会触发 callback），Node 里会根据 `functor_run` 决定是否需要再显式调用 callback。也就是说 DSL 能把部分完成信号内嵌在 functor 执行中，需要注意不要重复触发回调。

## 并发/线程/生命周期注意事项（实战）
- Callback 去重：`GetCallback()` 内部用 `has_run_` 原子保证只允许第一次“真正执行”，重复调用会得到 `empty_cb_` 并记录后溯栈（这是 safety 机制）。但你仍应确保每个放行路径能恰好触发一次（由 Node 或 functor 决定哪边触发）。
- Reset 必须清理回调与状态：当 Functor 从池中回收并复用时，`Reset()` 会被调用，必须清除并恢复 `dsl_helper_` 等。若你在 Functor 中存有外部资源（client、定时器等），请在 Reset/析构时妥善释放/取消。
- Accessor 的并发保护：`Accessor` 内有 `ctx_lock_`, `item_lock_` 等锁。异步回调在写 `Accessor` 时（AddRecallItemFeature / AddItemFeature）会自己获得写锁，但仍需注意 protobuf 对象（如 Feature pointers）与 Arena 的生存期（不要把指向临时 Arena 的指针跨线程使用）。
- 异常安全：如果异步回调抛异常，可能导致线程退出或没有调用回调，建议在回调外包 try/catch 并确保最终调用 `GetCallback()` 或至少记录并恢复状态。

## 常见错误/陷阱（check-list）
- [ ] 忘记在异步 RPC 回调中调用 `GetCallback()` → DAG 卡住。  
- [ ] 在 sync 场景下异步化了但没有把 is_async 标记好 → Node 行为不一致。  
- [ ] 在回调中捕获了 `accessor` 的临时对象或局部指针（生命周期不足）。  
- [ ] Functor Reset 未清理回调/状态，造成复用时残留数据。  
- [ ] 重复触发回调（GetCallback 被多次尝试）会触发错误日志——应设计路径只触发一次。  
- [ ] 在异步回调中直接操作临时生成的 protobuf/Arena 内存，需注意 Arena 的生存期。  

## 设计层面的理解（推荐系统阶段映射）
- Recall：获取候选集（外部召回服务）→ 写回 `Accessor::recall_items_`（异步或批量）。  
- Arranger / Merge：合并来自多个召回 / 重排位置 / 去重 / 打分（通常 sync，操作 `item_feature_` 和 `origin_items_`）。  
- Prerank / Rank：调用模型做粗排/精排（可能是 RPC，通常异步），把模型输出写回 `Accessor` 的 output map。  
- Rerank / Report：后处理与上报（同步或轻量异步），记录度量。

## 小结
- Functor：策略算子抽象，负责业务逻辑与写回 `Accessor`。  
- 同步 Functor：Node 负责调用回调；异步 Functor：Functors 自己在异步完成处调用 `GetCallback()`。  
- 派生类需要实现 `Run(Accessor*)`，并在合适的位置往 `Accessor` 写入结果并触发回调。  
- 注意并发、生命周期、Reset、异常、callback 去重。

