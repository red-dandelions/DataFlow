# Node数据准备

## 要点

- 初始节点读取的数据都来自 `Accessor`（每个请求唯一的上下文对象）。  
- `Accessor` 在请求进入时由 `Accessor::Bind(...)` 填充：把请求里的上下文特征（context）、请求携带的 item 列表（RecMsg / RecommendRequest）和部分预置的 item 特征（score、location 等）写入 `Accessor`。具体实现见 accessor.cc 的 `Bind` / `BindRecGoods` / `BindSrchGoods`。  
- `Graph::Run` 把所有 ParentCount==0 的节点当作 start node，调度到 `StrategyAsyncPool::Async(...)` 执行；这些节点运行时通过持有的 `Accessor*` 读入初始化数据（通过 `GetCtxFeature*`、`GetOriginItemFeaturePtr`、`GetRecallItem` 等接口）。  
- 有些算子并不依赖事先填好的数据，而是在 `Run()` 中发起异步召回/外部 RPC，结果在回调里写回 `Accessor`（例如调用 `AddRecallItem` / `AddRecallItemFeature`），回调完成后再触发子节点执行。  
- 单元测试和 debug 场景也会通过 `Accessor::AddItemFeature` / `AddRecallItemFeature` 直接注入数据以驱动节点。

## 代码位置与具体流程
1. 请求绑定阶段（输入被填入 `Accessor`）
   - 当请求到达，调用 `Accessor::Bind(...)`（两种重载：`const api::RecommendRequest*` 或 `const api2::RecMsg*`）。见 accessor.cc：
     - `Bind(const api2::RecMsg* rec_msg_req, api2::RecMsg* rec_msg_rsp, ...)` 会：
       - 填写上下文特征：比如 `AddCtxFeature("mid", ...)`、`AddCtxFeature("poskey", ...)`、以及把 `context_map` 里的 kv 写为 ctx 特征；
       - 填写请求级别信息（trace_id、site_id、scene_id 等）；
       - 将请求里传入的 item 列表转换为内部 `Item` 并通过 `AddItem(...)` 记录，同时调用 `AddItemFeature(kFeaGScore/GRankScore/GLocation/GMixItemSource...)` 把 item 的 score/location 等转换成 item-feature 存储到 `item_feature_`。
       - `BindRecGoods` / `BindSrchGoods` 里构造并写入这些 item 特征（即最常见的“初始候选列表”来源）。
   - 因此初始节点（比如对 item list 做排序/编排的 arranger）通常直接从 `Accessor` 中读到 `kFeaGLocation`、`kFeaGScore`、其它 item 特征。

2. Analyzer / 构建 DAG 时对 Accessor 的预置
   - `StrategyAnalyzer::BuildFunctors` / `BuildDependent` 在构建 DAG 时，可能会预先向 `Accessor` 注册某些期待的 recall slot（调用 `AddRecallItemFeature(...)` 等），或为 merge/recall 做准备（在分析阶段插入空的 recall-entry），以便后续 functor 可以把异步结果写回到这些位置（见 strategy_analyzer.cc 中若干处对 `AddRecallItemFeature` 的调用）。  
   - 这些预置并不总是包含数据（往往是占位或 empty），真正的数据要么来自 `Bind`（请求里已带），要么由后续的 recall functor 在运行时调用外部服务并写回 `Accessor`。

3. Node 执行时如何读取与写回数据
   - 每个 `Node` 在创建时保存了 `Accessor*`（`new Node(accessor, functor, this)`），因此 `Node::Run()` / functor 内部可以随时通过 `accessor_` 读取/写入特征。
   - 读取接口示例（在 `Accessor` 里）：
     - `GetOriginItemFeaturePtr(const std::string& fea)`：读取原始 item 特征（如 `kFeaGLocation`）。
     - `GetCtxFeaturePtr(...)` / `GetCtxFeature<T>(...)`：读取上下文特征。
     - `GetRecallItem(strategy_id)` / `GetRecallFeaturePtr(strategy_id, fea)`：读取召回结果或召回特征（如果之前被写入）。
   - 写回接口示例：
     - `AddRecallItem(const std::string& strategy_id, ...)`：把召回到的 item 写到 `recall_items_` 中。
     - `AddRecallItemFeature(strategy_id, name, feature_ptr)`：把 recall 的 item 特征写入 `recall_items_[strategy_id].features`。
     - `AddItemFeature(...)`：给整个请求的 item 列表添加/覆盖 item-feature。
   - 典型流程：
     - 若算子是同步处理已有 item-feature（例如 arranger/prerank），它在 `Run()` 里直接读取 `Accessor` 的 item_feature_/ctx_feature_ 并处理，最后用 `functor_->GetCallback()()` 通知完成（触发子节点）。
     - 若算子需要调用外部召回（异步），它在 `Run()` 中调用 RPC（通过 `StrategyAsyncPool` 或 client stub），在 RPC 的回调里把结果用 `Accessor::AddRecallItem(...)` 写回，并在回调里执行 `functor` 的回调以唤醒依赖它的子节点。

4. Graph 调度与“谁先跑”
   - `Graph::Run()` 找到所有没有父节点（ParentCount()==0）的 start nodes 并通过 `StrategyAsyncPool::get_mutable_instance().Async([node](){ node->Run(); }, accessor_->trace_key());` 把它们提交到池中执行。  
   - 所以“最开始的 Node”在被调度时能访问到的就是 `Accessor` 当前已有的全部数据（由 Bind 和 Analyzer 的预置共同构成）。

## 举个具体的代码对应例子
- 请求里有 item list：
  - `Accessor::Bind(...)->BindRecGoods(...)` 会调用：
    - `AddItem(...)` 把每个 `Item` push 到 `origin_items_` / `entity_items_`，并且
    - `AddItemFeature(kFeaGLocation, feature::FeatureFactory::CreateVector<int64_t>(g_loc));` 等把位置/分数写入 `item_feature_`。
  - 对应节点（比如 arranger）在 `Node::Run()` 里会调用 `functor_->PrepareRun(accessor_)` / `functor_->Run(accessor_)`，在 functor 内部通过 `accessor_->GetOriginItemFeaturePtr(kFeaGLocation)` 读取这些数据。
- 召回算子：
  - Analyzer 可能为某些策略预置一个 recall 槽（`AddRecallItemFeature(strategy_id, "", nullptr)`），但没有数据；
  - 当 recall 算子运行时，它发起外部召回，回调里执行 `accessor_->AddRecallItem(...)` / `accessor_->AddRecallItemFeature(...)`，然后触发 functor 的回调，子节点就能在 `Accessor` 中看到召回结果。

## 常见边界情况
- 如果 `Accessor` 没有某个特征（没有被 Bind/预置），functor 要么：
  - 有退化路径（`has_degrade_run()` + `DegradeRun(...)`），
  - 或先发起 RPC 补数据（异步），
  - 或直接按缺失处理（返回、记录失败）。
- 多线程写入：`Accessor` 使用锁（`ctx_lock_` / `item_lock_` 等）保护并发写读，且很多写回都是在 RPC 回调线程中完成（由 AsyncPool 的 worker 执行），因此要注意生命周期（Accessor 与 Arena）和并发安全。
- 单元测试：测试里直接用 `accessor->AddItemFeature` / `AddRecallItemFeature` 注入数据，便于测试算子逻辑（见多个 utest 文件）。

## 结论
- “一开始的 Node 的数据输入”不是来自 Node 自己，全部来自 `Accessor`。`Accessor` 在请求绑定阶段（`Accessor::Bind` / `BindRecGoods` / `BindSrchGoods`）把请求上下文和请求携带的 item 列表转为内部特征写入；另外 `StrategyAnalyzer` 也会在构建阶段做一些预置（空槽、期望等）。若某些算子需要额外数据，会在 `Node::Run()` 发起异步 RPC，结果写回 `Accessor`，并在回调里触发下游节点。
