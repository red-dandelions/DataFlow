# 九、StrategyExecutor

---

## 高层概述 — 推荐系统中的 StrategyExecutor 在整套系统中做什么

业务背景（推荐平台的常见分层）：
- 推荐请求通常按阶段处理：召回（recall）→ 预排序（prerank）→ 重构/补全（rebuild）→ 排序（rank）→ 精排/再排序（rerank）→ 上报/埋点/report。
- 每个阶段可能由若干“策略”（strategy）组成。每个 strategy 对应一个“算子”（Functor）。算子可以是召回器（recaller）、编排器（arranger）、特征提取（extractor）、合并（merge）、上报（reporter）等。

StrategyExecutor 的职责（从大到小）：
1. 接受一个请求，并将请求数据绑定到内部的 `Accessor`（请求上下文、特征、候选项、埋点/监控数据都放在这里）。
2. 根据请求要跑的 `strategy_ids`，用 `StrategyAnalyzer` 将这些 strategy 构造成一组 Functor，并构建依赖 DAG（Directed Acyclic Graph）。
3. 把 Functor 节点转换成 `Graph`/`Node` 对象（节点包含 functor + 其 Accessor），然后并行/异步执行 DAG（由 `Graph` 和 `Node` 协作）。
4. 处理异步回调（异步算子内部触发完成回调），收集完成的结果，执行后置 finish job（例如上报类 Functor）。
5. 管理资源（functor 池、KV/ES 批量 helper、accessor/rebuild accessor 等）与超时/降级（通过 `StrategyController`）。
6. 返回最终 response（写回 gRPC/HTTP 层）。

换句话说：`StrategyExecutor` 是单次请求在推荐平台内部的“指挥/协调器”——把请求上下文（Accessor）交给一组按依赖执行的算子（Functor），负责并发、超时、降级与收尾汇报。

---

## 关键数据结构与类

### 1) `Accessor`（文件：accessor.h）
作用（核心）：
- `Accessor` 是一个“请求级上下文容器” —— 保存一个请求在整个策略执行过程中的所有上下文数据与临时结果：
  - 原始请求 proto（`api::RecommendRequest` / `api2::RecMsg`）与 response（`api2::RecMsg`）
  - 请求相关元数据：trace_id、site_id、scene_id、item_source 等
  - 上下文特征映射 `ctx_feature_`、物料特征映射 `item_feature_`
  - 召回候选 `recall_items_`（按 strategy_id 分桶保存召回出的候选项 + 特征）
  - 各种上报/埋点集合（`ctx_explain_`、`item_explain_`、`ctx_monitor_`、`item_rec_mark_` 等）
  - 工具对象引用：`KVModelHelper* kv_model_helper_`、`EsBatchHelper* es_batch_helper_`
  - 内部锁：`ctx_lock_`、`item_lock_`、`rsp_lock_` 保证并发读写安全
  - 其它：stage 成功计数、控制参数白名单、特征落地配置信息等

重要接口与用途（按功能分）：
- 绑定/初始化：
  - `Init()` / `Bind(...)`：将请求数据绑定到 `Accessor`，并做初始的 ctx/feature mapping、control param setup。
  - `SetArena(::google::protobuf::Arena*)`：将 protobuf arena 传入，供算子/graph 在该 arena 上分配 response 等，避免逐个 free。
- 数据读取/写入：
  - `GetCtxFeaturePtr`, `GetArrangedItemFeaturePtr`, `GetOriginItemFeaturePtr`：获取不同来源/阶段的特征指针。
  - `AddCtxFeature` / `AddItemFeature` / `AddRecallItem` / `AddRecallItemFeature`：被各类 Functor 填充。
- 监控/错误/可解释上报：
  - `AddCtxMonitorV2`：记录监控指标（strategy+metric），供 `MonitorReporter` 或上报系统收集。
  - `AddErrorReport` / `AddInfoReport`：错误/信息上报接口（会做日志 + 可解释信息 + 监控）。
- 多 Accessor 模式：
  - `accessor_` 与 `rebuild_accessor_`：`StrategyExecutor` 会同时持有两个 Accessor（见后），用于在“重构/重建”阶段（rebuild）需要与主流程分离数据时使用。`StrategyAnalyzer::AdaptAccessor` 会按 functor 的 stage 决定哪个 Accessor 给某个 Functor 使用。
- 其他：
  - `PreAllocateResource(strategy_id)`：用于在构建 graph 之前预申请资源（例如为某些 recaller 分配容器大小）。
  - `AddCtxTableHeader/Rows`：为调试/trace 构造表格信息。
  - `BuildTraceMsg()` / `RequestTraceMsg()`：构建请求 trace 字符串，供埋点。

概念理解：
- `Accessor` 就像请求执行期间的“黑板/中间仓库”。不同算子把结果写到这里，后续算子从这里读。它同时负责记录监控/埋点数据。

并发与生命周期要点：
- `Accessor` 被多个并发执行的 Node/Functor 访问，因此有读写锁以保障并发安全。
- Arena 的传入/设置非常重要：response 里创造的临时 proto（例如 rec_msg_rsp 的 field）通常会被放在 arena 上，避免复杂的内存管理。必须保证 arena 在整个请求周期内有效直到返回响应。

---

### 2) `Functor`（文件：functor.h）
作用（核心）：
- `Functor` 是所有“算子”的抽象基类。每个 strategy 在运行时都会被绑定成一个 Functor 实例（或从 pool 获取）。
- 一个 Functor 承载：策略 id、所属阶段（stage）、必需的输入特征名、输出特征名、是否异步、是否有降级逻辑等。

重要成员与方法（重点说明）：
- 生命周期/状态：
  - `Reset()`：重置内部状态（用于复用/pool）。
  - `Init()`：初始化（可能注册内部资源）；默认返回 true。
  - `Bind(strategy_id, StrategyParam&)`：将策略 id 和策略参数绑定到这个 Functor 上。
  - `set_strategy_id()` / `name()` / `Stage()`：元信息访问。
- 执行相关：
  - `PrepareRun(Accessor*)`：在真正 Run 之前的准备步骤（默认返回 true）。
  - `Run(Accessor*)`：算子的核心执行逻辑（纯 virtual，子类实现）。返回 bool 表示是否成功/有效等。
  - `support_async()`：标记算子是否内部会异步完成（如果 true，算子需要在内部某处触发 `cb` 来通知完成）。
  - `SetCallback` / `GetCallback`：用于 Functor 完成后对上层 graph 的回调。`GetCallback` 包含防重复调用的机制（`has_run_` 原子），并在重复调用时打印栈信息以便调试。
- 特征声明/管理：
  - `SetRequiredItemFeaName/SetOutputCtxFeaName/SetReportCtxFeaName/...`：用于声明输入/输出依赖，供 `StrategyAnalyzer` 构建 DAG 时计算依赖。
  - `SetRequiredAllFeatures(param)`：从 proto param 批量导入输入/输出特征名集合。
- DSL & dsl_helper：
  - Functor 持有 `DslHelper`，用于解析/执行 DSL 风格的表达式（例如某些 filter 或排序表达式）。
- 辅助功能：
  - `AsyncQueryItemFea(...)`：封装对 item feature service 的异步查询逻辑，内部会使用 `StrategyAsyncPool` 与 `acc::ItemFeatureClient`。方便 recaller / extractor 等在运行时发起 item feature 请求。

概念理解：
- 每个具体算子（recaller/arranger/merger/recaller/feature extractor/report 等）继承自 `Functor`，实现 `Run(Accessor*)`。通过 `required`/`output` 特征声明，`StrategyAnalyzer` 可以自动把这些算子按依赖连接成 DAG。

并发/异步：
- 算子可能是“同步”或“异步”两种模型：
  - 同步算子：`Run()` 执行完就返回结果（通常立即调用回调系统），Graph 根据返回情况继续推进。
  - 异步算子：`support_async()` 返回 true，算子内部会发起异步子请求（例如网络 I/O），并在真正完成时调用为自己设置的回调 cb。这要求 Graph/Node 能处理异步完成的通知。

错误/降级：
- 子类可以实现 `has_degrade_run()` / `DegradeRun(Accessor*)` 来支持算子内部的降级处理（例如热点降级、超时返回默认候选等）。

---

### 3) `StrategyAnalyzer`（文件：strategy_analyzer.cc）
功能（职责）：
- 将用户请求中的 `strategy_ids` 转换为一组实际要执行的 Functor（可能会把“合并器”要求的 recaller 自动插入）。
- 填充每个 Functor 的输入/输出依赖信息。
- 构建 DAG（函数之间的依赖关系），并把 Functor 分配到 Graph 节点中。
- 处理“rebuild”（重构）流程：当 has_rebuild_ 时，会把某些阶段使用 `rebuild_accessor_`（而不是主 `accessor_`），以实现主流程与重构流程的数据隔离。

主要函数与流程（按代码）：
1. `BuildDAG(strategy_ids)`：
   - 总调度：依次调用 `BuildFunctors`、`BuildDependent`、`BuildGraph`。
2. `BuildFunctors(strategy_ids)`：
   - 对给定的 strategy id 列表去重后，调用 `strategy_executor_->BindStrategyId(strategy_id, accessor)` 来创建/绑定 Functor（`BindStrategyId` 在 `StrategyExecutor` 中实现，返回 Functor*）。
   - 特殊处理：
     - 如果 functor 是 MERGER_ARRANGER，会把其所需的 recaller strategy 添加进来（并为相应 recaller 设置 merge_tag/recall_num 等），同时为 `kv_model_helper_` / `es_batch_helper_` 设定预期计数（`AddExpectCount`），以便 batched helper 预分配容器/并发槽位。
     - 处理 further_merge、recall_filter 等逻辑（把一些全局默认的 aggregator/further_merger 插入）。
   - 最后会把一些全局 finish/extra functors（如 MonitorReporter、ExplainReporter 等）也追加到 `functors_` 列表，以便作为 finish jobs 或普通阶段节点执行。
3. `BuildDependent()`：
   - 按 stage（RECALL/PRERANK/REBUILD/RANK/RERANK/REPORT）建立“依赖链”（例如 RECALL 阶段的输出是 MERGER 的输入等），并为某些常见的输出/输入特征设默认值（`kFeaGMatchItem` 等）。
   - 最终将 `functors_` 按 stage stable_sort，使不同阶段算子以阶段顺序排列。
4. `BuildGraph()`：
   - 根据各 functor 的 `GetOutputCtxFeaName()/GetOutputItemFeaName()` 和 `GetRequiredItemFeaName()/GetRequiredCtxFeaName()`，计算 DAG 边（哪些 functor 的输出被哪些 functor 依赖），同时考虑“并行 item 特征”集合（`parallel_item_feas`）等策略以决定并行/串行连接。
   - 为每个具有依赖的 functor 创建 `Graph` 节点（`strategy_executor_->graph_->AddNode`），并建立父子连接（parent->AddChildren(child)）。
   - 在建立每个 parent node 之前，会调用 `AdaptAccessor(functor)->PreAllocateResource(functor->strategy_id())`，以便根据 functor 的预期工作量预分配容器（减少执行时内存重分配）。

适配 Accessor：
- `AdaptAccessor(Functor*)` 根据 `has_rebuild_` 以及 functor 的 stage 返回使用 `accessor_` 还是 `rebuild_accessor_`。目的是把 rebuild 阶段与主流程隔离，避免干扰彼此的数据结构。

总结：
- `StrategyAnalyzer` 是策略解析器：从策略配置/规则 -> 生成可执行的 DAG（Functor 集合 + 依赖），并为每个节点分派合适的 Accessor。

---

### 4) `Graph` 与 `Node`（文件：graph.h）
作用（核心）：
- `Graph` 封装了 DAG 的运行与监控（含超时、运行统计、Dump/Report）。
- `Node` 表示 DAG 中一个可执行单元：包含 `Accessor*`, `Functor*` 和其子节点列表、父计数等。节点负责运行其 Functor，并在其父依赖满足时触发自身运行。

`Node` 的关键方法（及其意义）：
- 构造与 InitializeCallback：
  - `Node(Accessor* accessor, Functor* functor, Graph* graph)`：构造节点并关联 functor 与 accessor。
  - `InitializeCallback()`：设置 functor 的回调函数（cb），cb 在算子完成时调用（无论同步或异步），cb 会在 node 层面处理 parent/children 的通知逻辑。
- `AddChildren(std::shared_ptr<Node> child)`：建立 parent->child 邻接关系。
- `Run()`：节点运行自身的逻辑：
  - 如果 `Skip()` 为 true（例如策略被屏蔽或其他条件），节点会直接标记为完成并触发 children。
  - 否则：执行 `functor->PrepareRun(accessor)` -> `functor->Run(accessor)`。如果是异步算子，`Run` 返回后实际完成由其内部异步流程在未来调用 cb；如果 `Run` 同步完成，`InitializeCallback` 会在 `Run` 内部或Run后被立即触发。
- `RunChilds()`：当当前节点完成时，通知子节点减少 parent 未完成计数并当计数到 0 时触发子节点的 `Run()`。
- `Report()`：记录节点运行耗时、层级统计等 Prometheus 监控（`util::pmonitor`）。

`Graph` 的关键方法（用途）：
- `Bind(Accessor*, StrategyController*)`：把 graph 与 executor 的 accessor/controler 绑定（以便节点执行时访问 controller 的决策）。
- `AddNode` / `GetNode`：创建并记录节点。
- `Run(std::function<void()>&& end_cb)`：触发图的执行（通常 graph 会遍历没有父节点的 entry nodes 开始 Run），并在所有节点完成时调用 end_cb（也就是 StrategyExecutor 的最终回调）。
- `HasLoop()`：检测有无环（安全检查）。
- `Dump()` / `Report()`：可视化/监控输出。

并发细节：
- `Node` 里使用 `parent_done_cnt_`（原子）与 `parent_cnt_`（父总数）。当 parent 回调时，`parent_done_cnt_` 增加，等于 `parent_cnt_` 时才执行该节点。这样保证父节点全部完成后才启动子节点。
- 超时/timeout_{500}：每个 Node 可有其单独 timeout 默认 500ms，可以在 `InitializeCallback`/Graph run 时注册 Alarm（在 gRPC Server 的上下文中），或 Node 内部在 Run 时比较时间戳并采取降级/终止措施。

总结：
- `Graph`/`Node` 把 Functor 的“函数依赖关系”具体化为并行可执行节点，负责在运行时以异步安全的方式协调算子执行与子节点触发。

---

### 5) `StrategyController`（文件：strategy_controller.h）
职责（高层）：
- 对于一次请求执行周期，`StrategyController` 管理运行时策略执行的“控制规则”：
  - 哪些策略被禁用（`disable_strategy_ids_` 等）
  - 是否全局禁用（`disable_all_`）
  - 哪些 stage 必须运行（`must_stages_`）
  - 是否出现降级（`has_degrade_`），以及 pm_type_/degrade_type_ 标记
- 提供判断接口：
  - `Bind(Accessor*)`：把 controller 与请求关联，并可能基于请求上下文初始化运行时黑/白名单。
  - `AllowBuild(const Functor*)`：在构建 DAG 时用于判断某个 Functor 是否允许被创建并加入 DAG（例如全局禁用、按策略 id 禁用）。
  - `AllowRun(const std::shared_ptr<Node> node)`：在 Graph 运行时判断某个节点是否可以执行（例如跑到一个 stage，但 controller 根据实时配置决定跳过）。
  - `AddRuntimeMsg()`：在运行过程中添加运行时消息（例如日志或统计），用于后续报告或决策。
  - `has_degrade()`：是否触发降级逻辑的查询：`StrategyExecutor` 或 Functor 可据此选择降级路径。

业务用途：
- 方案A/方案B 的 AB 测试开关、按流量/请求来源屏蔽某些策略、突然发现某些外部服务异常时临时禁掉特定 recaller/merger，都是通过 `StrategyController` 的配置/决策实现。

---

## `StrategyExecutor` 本体（接口与每个方法的作用）

文件：strategy_executor.h 中声明的方法及在代码中的角色如下（我会按头文件和在其他文件中看到的使用来解释）：

成员变量（关键）：
- `bool is_async_`：executor 本身是否作为异步执行单元。
- `api2::RecMsg* rsp_`, `const api2::RecMsg* req_`：请求/响应 proto 指针（当使用 api2 时）。
- `acc::ItemFeatureClient* item_feature_client_`：对 item feature 服务的客户端（用于在 Functor 内做异步/同步特征查询）。
- `std::unique_ptr<Accessor> accessor_, rebuild_accessor_`：两个 Accessor 上下文实例（详见 Accessor 部分）。
- `std::vector<std::string> strategy_ids_`：本次请求的策略 ids 列表。
- `std::vector<std::pair<Functor*, Accessor*>> finish_jobs_`：执行完 DAG 后还要执行的收尾算子（例如上报、埋点之类的 functor 与其 Accessor）。
- `std::unordered_map<std::string, Functor*> functor_map_`：name->Functor（实例/模板对象），便于快速查找（可能是 pool 中的实例或资源）。
- `std::unordered_map<std::string, acc::DynAllocator<std::unique_ptr<Functor>>> functor_pool_`：按 functor 名称维护 Functor 池（用于重用对象，避免频繁 new/delete）。
- `std::unique_ptr<KVModelHelper> kv_model_helper_;`、`es_batch_helper_`：recall 模块的 batch helpers，用于对 KV/ES 请求做批量合并 & 并发控制。
- `std::unique_ptr<StrategyAnalyzer> analyzer_;`
- `std::unique_ptr<StrategyController> controller_;`
- `std::unique_ptr<Graph> graph_;`
- `std::vector<std::unique_ptr<Functor>> functor_resource_`：按需创建并持有的 functor 资源（防止被析构）。

主方法和行为（按头文件）：

1. StrategyExecutor() 构造 / ~StrategyExecutor()
   - 构造函数会创建 `accessor_` / `rebuild_accessor_` 并初始化（`accessor_->Init()`）。构造里还会初始化 `kv_model_helper_`、`es_batch_helper_`、`analyzer_`、`controller_`、`graph_` 等成员（实现里有 omitted 行，但这是常见做法）。
   - `Init(bool is_async = false)`：总体初始化。通常做：
     - 初始化 helper（KV/ES）；
     - 初始化 analyzer/controller/graph；
     - 根据 is_async 设置 executor 行为；
     - 可能注册一些全局 reporters 或 pool 等。
   - `Reset()`：重置 executor 内部状态（清空已绑定的 request/response、策略 ids、finish_jobs、functors 等），确保对象可复用。

2. Bind(...)
   - `Bind(const api::RecommendRequest& req, const std::vector<std::string>& strategy_ids, acc::ItemFeatureClient* client)`（用于老版 proto `api::RecommendRequest`）：
     - 主要工作：把请求绑到 `accessor_` 里（`accessor_->Bind(req)`），设置 `item_feature_client_`，把 `strategy_ids_` 填入，并把 arena 关联上（如果有）。
     - 为后续 `Analyzer` 构建 DAG 提供上下文。
   - `Bind(const api2::RecMsg& req, std::vector<std::string>&& strategy_ids, api2::RecMsg* rsp)`（用于 api2）：
     - 类似上面，但支持新的 proto 结构：`req_`、`rsp_` 的记法与上下文不同，但总体功能一致。

3. `Functor* BindStrategyId(const std::string& strategy_id, Accessor* init_accessor = nullptr)`：
   - 关键方法：给出 strategy id，创建/获取对应的 `Functor` 实例：
     - 首先从 `functor_pool_` 或 `functor_map_` 查找是否已有实例或注册 factory；
     - 如果池中没有，会 new 一个新 Functor（见 `BasicFunctorPool::RegisterFunctor` 的 usage），并 `Init()`、`Bind()`（将 strategy_id 与 strategy param 绑定）。
     - 返回 `Functor*`（用于 Analyzer 构建 functors 列表），并可能设置 `init_accessor` 给需要用初始 accessor 的 functor。

4. `bool BindFunctor(const std::vector<std::string>& strategy_ids)`：
   - 将多个 strategy_id 绑定为 functor（调用 `BindStrategyId`），并把他们注册到 `functor_map_` 或 `functor_resource_` 等，做好下一步 analyzer 的准备（通常在 Analyzer 的 BuildFunctors 里也会调用类似逻辑）。

5. `bool RunFunctor(const std::string& name)`：
   - 运行单个 functor（通常用于 finish jobs 或单独调试），会调用 functor->PrepareRun(accessor) -> functor->Run(accessor)。

6. `bool AsyncDAG(std::function<void()>&& cb)` / `AsyncDAG(const std::vector<std::pair<std::string, std::string>>& edges, std::function<void()>&& cb)`：
   - 触发 analyzer 构建 DAG，并把 DAG 交给 `graph_->Run(end_cb)`。 `end_cb` 在 graph 全部节点完成时调用，目前实现会把结果组装并执行 `cb`。
   - `AsyncDAG` 返回后，DAG 在后台运行（可能有异步算子），最终会在 `cb` 被调用时告知上层请求完成并可以把 response 返回。

7. `bool RunFinishJob()`：
   - 在主 DAG 执行完后执行收尾任务（`finish_jobs_`），典型的 finish job 包括：
     - `SvrMarkReporter`、`ExplainReporter`、`StrategyReporter`、`TraceReporter`、`FeatureLandingReporter` 等：这些算子一般用来上报监控、生成可解释信息、做日志或 Kafka 的埋点推送。
   - `RunFinishJob()` 会以同步或异步方式调用这些 reporter 的 `Run` 或 `Async` 方法。此方法通常不会阻塞主业务太久（有些 reporter 本身是异步的）。

8. Reporting 函数（ExplainReport、SvrMarkReport、MonitorReport、StrategyReport、FeatureLandingReport）
   - 这些是对外提供的便利调用，通常为触发特定上报算子的执行，内部会从 pool 中取 reporter、设置 context、触发 run。

9. `bool GetStrategyId(const std::string& old, std::string& strategy_id)` / `MigrateStrategy()`：
   - 这些函数用于策略 id 命名/迁移兼容性：有时策略 id 发生变更，系统中会有映射规则或迁移逻辑来确定新 id。
   - `MigrateStrategy()` 可能会检查策略版本与当前模型是否兼容，并替换策略 id 列表（实现细节在 omitted 部分）。

10. `bool SetArena(::google::protobuf::Arena* arena)`：
    - 将 protobuf arena 传给 executor（并转给 accessor），确保在本次请求内所有 proto 分配都用同一个 arena。

---

## 从请求到响应的执行序列

一次请求在 `StrategyExecutor` 中的处理流程。假设这是 `api2::RecMsg` 的路径（`api` 路径基本相同，结构差异小）：

1. gRPC server 接收到请求，获取 `StrategyHandle`（server context），并在 `StrategyHandle::HandleRequest()` 中分配一个 `StrategyExecutor`（或从 `StrategyExecutorPool` 取出）。
2. 在 `StrategyHandle` 中调用 `executor->SetArena(arena)` 将 protobuf arena 绑定到 executor（从 server 的 Context 中获取 arena）。
3. 调用 `executor->Bind(req, strategy_ids, rsp_ptr)`：把请求和要执行的 `strategy_ids` 绑定到 `accessor_`。`accessor_->Bind` 会做必要的请求解析（例如拆分 strategy_ids、提取控制参数、设置 site/user 等）。
4. `executor->analyzer_->set_has_rebuild(flag)`：根据请求的某些控制参数，可能会设置 has_rebuild_（是否走重构流程）。
5. `executor->Analyzer->BuildDAG(strategy_ids)`：
   - `BuildFunctors`: 为每个 strategy id 创建/获取 Functor（`BindStrategyId`），把其加入 functor 列表；如果是 merger 类型，自动插入其所需的 recall 策略等；设置 `kv_model_helper_`/`es_batch_helper_` 的期望并预分配资源。
   - `BuildDependent`: 根据各 functor 的 stage 设置默认的 required/output 特征名（例如 recall->match_item, prerank->prerank_item 等）。
   - `BuildGraph`: 根据特征依赖关系构造 dag_map（Functor* -> set<Functor*>），对每个 functor 创建 `Graph::AddNode(accessor, functor)` 并用 `parent->AddChildren(child)` 连接。
6. `executor->graph_->Run(end_cb)`：执行 Graph。
   - Graph 会找到所有没有父节点（entry nodes），对这些节点调用 `Node::Run()`。
   - `Node::Run()`：
     - 如果 `controller_->AllowRun(node)` 表示不允许运行则跳过。
     - 调用 functor->PrepareRun(accessor)（准备阶段：例如确保所需特征存在、设置 trace/tt等），然后调用 `functor->Run(accessor)`。
     - 若 functor 是同步执行（普通 Run 立即返回），则 functor 执行完后会触发 `functor` 的回调（`InitializeCallback` 里设置），进而 `Node` 在回调中执行 `RunChilds()`：减少子节点 pending parent 计数，并当子节点 parent_done == parent_cnt 时触发子节点 `Run()`。
     - 若 functor 是异步执行（`support_async()` true 或 Run 内部异步），则 `Run()` 返回后实际完成将由 functor 在内部异步 I/O 完成后调用其回调，回调会最终触发 `Node` 的 `RunChilds()`。
7. children node 依次执行，整个 DAG 并发推进，直到所有节点都完成。Graph 维护 `end_done_cnt_`，在全部节点完成时会调用 `end_cb`（通常这个 `end_cb` 会触发 executor 的 `RunFinishJob()`）。
8. 在 `end_cb`（DAG 完成）中：
   - `executor->RunFinishJob()` 被调用，执行 `finish_jobs_`（一些 reporter 等），这些 reporter 可能将数据写入 response、或做异步上报（Kafka、Prometheus）。
   - 将最终的 response 写回给上层（gRPC resp writer），并释放/归还 executor 到池。
9. 返回客户端响应（并发/异步处理由 server layer 与 executor 配合实现超时管理、错误处理）。

---

## 细化：常见的 Functor 类型与行为（如何对接 Accessor / DAG）

常见 Functor 类型（代码库中可以看到很多实现）：
- Recaller（召回器）：产生候选 item 列表（`Accessor::AddRecallItem`），通常会调用外部召回服务（KV 模型、ES、havnask、FAISS 等）。可能会是异步（network)。
- Arranger / Merger（编排/合并器）：把多个 recaller 的候选合并、去重、按策略混排，并产生下一阶段的 item 列表（例如 `kFeaGMergerItem / kFeaGMatchItem` 等）。
- Extractor（特征提取）：给候选补充 item-level 或 ctx-level 特征（可能调用 item feature 服务）。
- RebuildArranger（重构器）：对候选集做更复杂的重构（例如位置相关调整），并可能输出给 rebuild_accessor。
- Rank / Rerank：排序模型（可能调用在线/离线模型服务）给 item 打分并排序。
- Reporter（上报器）：生成埋点、监控或响应中需要的可解释字段。通常作为 `finish_jobs_` 或在特定 stage 后触发。

每个 Functor 与 Accessor 的典型交互：
- 读取：`Accessor::Get...FeaturePtr()` 获取 input 特征，或读取 prior stage 产出的 item 列表 `Accessor::GetRecallItem(strategy_id)`.
- 写入：`Accessor::AddRecallItem`, `Accessor::AddCtxFeature`, `Accessor::AddItem...`。
- 上报：`Accessor::AddCtxMonitorV2`、`AddErrorReport` 等。

---

## 并发、超时、降级与常见陷阱（以及该如何在代码中检查或改善）

并发点：
- 多个 Node 并发运行，多个 Functor 并发操作同一个 `Accessor`（读多写多）。`Accessor` 在设计上有读写锁（`ctx_lock_`, `item_lock_`, `rsp_lock_`）保证数据安全。
- Functor 内部可能会发起异步网络调用（item feature / external recaller），这些回调会在未来线程/IO 完成时触发 functor 的回调 `cb`，所以 `Graph` 和 `Node` 必须能正确处理异步通知。

超时与取消：
- Node/Graph 有 timeout 设定（`Graph::timeout_` / `Node::timeout_`），需要在实现中注册 alarm（server_impl 中的 Alarm）或内部用时间检查来强制降级/终止。
- 使用 protobuf Arena 时要保证 Arena 在异步回调发生之前仍然有效（常见坑：如果你在 request 处理线程返回之前释放了 Arena，但仍有异步回调会访问 Arena 分配的内存，就会出现内存错误）。因此，executor/handler 通常会把执行延续到所有异步任务完成后才释放 Arena。

降级：
- `StrategyController::has_degrade()` 是判断是否出现降级条件（如外部服务不可用、超时或策略被临时禁用）。
- Functor 实现应有 `has_degrade_run()` / `DegradeRun()`，并在外部服务不可用时执行降级逻辑（例如返回默认候选、空集合或使用缓存数据）。

常见坑 / 风险：
- Null deref：`StrategyHandle::HandleRequest()`（你之前展示过）在 rule-not-found 分支直接调用 `HandleResponse()` 而未保证 `executor_` 非空，容易 NPE/UB。类似问题也可能出现在其他早期 `return` 的分支未正确清理或释放资源时。
- Arena 生命周期：如上，必须确保 Arena 在任何异步回调完成前不被释放。
- Functor 重用：从 `functor_pool_` 取出的 Functor 必须在 Reset/Init 后可安全重用，若 Functor 内部持有了对请求生命周期敏感的指针（例如 raw 指向 Accessor 内结构），在复用前必须清理。
- 并发写入 Accessor 时的死锁/性能问题：读写锁的粒度要足够细（Accessors 使用多个锁分离 ctx / item / rsp）。
- Graph 循环依赖：`StrategyAnalyzer::HasLoop()`/`Graph::HasLoop()` 必须在构建时检查，防止死循环。

---

## 调试与排查

1. 单元/集成测试：
   - 为常见 strategy 流（single recaller、merger + recall、rank）编写小用例，断言 `Accessor` 中的 candidate 数量和 response 字段。
   - 针对有异步 I/O 的 Functor，写模拟 client（或 mock）来控制返回延迟/错误，验证降级逻辑是否触发。
2. 异常日志：
   - 在 Functor 的 `Run()`/`Async` 的开始与结束打印关键 trace（strategy_id、stage、timing）并使用 `Accessor` 中的 `trace_id` 关联日志。
3. Arena 生命周期问题检测：
   - 如果怀疑是 Arena 引起的崩溃，开启 ASAN 或在回调中打印 arena 地址，验证在回调触发时 arena 是否还在。
4. DAG 可视化：
   - 使用 `StrategyAnalyzer::dag()`（它调用 `Graph->Dump()`）输出 DAG 结构，便于观察算子依赖关系，确认 `BuildDependent()` 逻辑是否正确。
5. 性能剖析：
   - 在 Node/Graph `Report()` 中已经存在 pmonitor 点（见 Graph），可以导出并分析阶段耗时分布。
6. 常见问题定位：
   - 如果出现“某些 strategy 没生效”或“某些阶段未被执行”，首先检查 `StrategyController` 是否把这些策略禁用了（runtime 配置），然后 `BuildDAG` 是否将其加入 `functors_`（日志输出 functor 列表）。

---

## 代码与业务场景举例

- MergeArranger 的行为（在 `StrategyAnalyzer::BuildFunctors` 中被特别处理）：
  - 如果规则中配置了一个 Merger（例如合并多路召回），`BuildFunctors` 会把 merger 所需的 recall 策略自动加进 `functors_` 并把 recall 的 `merge_tag`、`recall_num`、`disable_deduplicate` 等字段设置好，接着把 `kv_model_helper_` 和 `es_batch_helper_` 的 `AddExpectCount` 调整为预期并发/调用数值，预分配资源。
  - 业务意义：Merger 在运行时期待来自不同 recaller 的候选，Analyzer 在构造阶段就把这些 recaller 插入并配置好，Graph 运行时会先触发各 recaller 并把结果合并后交给 Merger。

- Rebuild 场景：
  - 当 `has_rebuild_` 为 true 时，Analyzer 会为部分算子使用 `rebuild_accessor_`（而非主 accessor）。业务上这是当需要“先做一个完整的预处理/补全、然后在主流程里应用”时的分支。举例：先在 rebuild accessor 上做 prerank/重构，然后把结果回写到主 accessor。

- Finish Job（上报）：
  - `finish_jobs_` 中包括 `ExplainReporter`、`SvrMarkReporter`、`StrategyReporter` 等。这些算子通常写入 `Accessor` 的 response 字段或将监控/trace 推送到 Kafka。业务上这是“把本次请求的埋点/可解释信息/统计指标输出”的步骤，通常不影响用户看到的推荐结果但对离线分析和监控至关重要。

---

## 核心函数与代码块逐项回顾（按你请求，每个函数/块说明用途与关键逻辑）

 `StrategyExecutor` 头文件中每个对外接口再次逐一解释它们在运行中的“实际责任”并指出你在实现或修复时要注意的点：

- `StrategyExecutor()`（构造）：
  - 责任：创建 `accessor_` / `rebuild_accessor_`，初始化 `kv_model_helper_`、`es_batch_helper_`、`analyzer_`、`controller_`、`graph_`。设置默认状态值。注意确保这些子组件在后面 Run 时线程安全（它们基本都是 per-executor 实例）。
- `bool Init(bool is_async)`：
  - 责任：执行一次性初始化（注册 pool、初始化 helper、设置 is_async_），打开可能需要的线程/连接。如果 is_async_ true，表明 executor 本身会以异步方式工作（例如在一个协程/线程池里），需要与 server 层的超时/回收策略配合。注意如果 Init 中创建外部连接（如 model clients），要处理失败返回。
- `bool Reset()`：
  - 责任：清理本次请求残留数据：重设 `accessor_`/`rebuild_accessor_` 的状态、清空 `strategy_ids_`、释放/重置 functor 引用、清理 finish_jobs_、重置 controller。要确保 Reset 在所有异步任务完成之后调用（防止回调持有已被 reset 的指针）。
- `bool Bind(const api::RecommendRequest& req, const vector<string>& strategy_ids, acc::ItemFeatureClient* client)` 与 `Bind(api2::RecMsg...)`：
  - 责任：把请求与 executor 绑定，为 analyzer/graph 构建上下文。注意保证传入的 `client` 生命周期长于 executor 使用期（或 executor 记录引用不重复使用）。
- `Functor* BindStrategyId(const std::string& strategy_id, Accessor* init_accessor = nullptr)`：
  - 责任：从 pool 创建或复用 Functor，并用策略参数绑定；如果无法创建，返回 nullptr。注意：实现要保证当失败时不会留下半初始化对象，并适当记录日志（以便 analyzer 跳过）。
- `bool BindFunctor(const vector<string>& strategy_ids)`：
  - 责任：为一组策略批量做 BindStrategyId；可以检查 controller 是否允许（AllowBuild）。
- `bool AsyncDAG(std::function<void()> && cb)`：
  - 责任：把构造好的 functors->graph 交给 `Graph::Run` 执行并在全部完成时调用 cb（cb 通常负责 RunFinishJob 并返回响应）。注意 cb 的异常安全与 arena 生命周期。
- `bool RunFinishJob()`：
  - 责任：执行 `finish_jobs_` 中的 reporter，例如上报 response、采样、监控等。因为这些操作可能耗时或是异步，建议这些 reporter 的实现尽量异步化或有良好超时控制。
- `bool SetArena(::google::protobuf::Arena* arena)`：
  - 责任：把 arena 设置到 executor 与 accessor，确保 response 所有 proto 分配都在该 arena 上。注意：不要在返回 response 前释放 arena。
- `bool MigrateStrategy()` / `GetStrategyId()`：
  - 责任：兼容/映射策略 id（例如新老版本策略 id 映射），以便配置变化时不中断现网流量。实现细节要保证线程安全及配置热更能力。

---

## 典型错误场景与修复

优先级高（应立刻检视）：
1. Arena 生命周期与异步回调冲突（极易引发随机崩溃）：
   - 修复：保证只有在所有异步回调完成后才释放 Arena，或为每个异步子任务创建独立短生命周期内的对象，避免指向 arena 的悬空指针。
2. Null deref / 不当调用 finish 回调（你之前的 `HandleRequest` 问题）：
   - 修复：在任何路径中调用 `HandleResponse()`（或任何依赖 `executor_` 的方法）前，确保 `executor_` 已创建并有效；在 rule-not-found 时应该生成错误 response 并直接 `ReturnResponse()`。
3. Functor pool/复用问题：
   - 修复：确保 Functor 的 `Reset()` 方法能清除对上一次 request 的所有引用（指针/临时数据），并在复用前再次 `Init()` 或 `Bind()`。

中等优先级：
- `Graph` 的超时/错误传播策略：如果某个 Node 超时或失败，Graph 应该有机制传播错误（例如标记 controller 为 degrade 或触发 fallback path）而不是静默跳过。
- `StrategyController` 的动态更新：提供接口在运行时更新禁用名单（例如 consul 或 kv 配置变更），并保证正在运行的 executor 读取到最新信息。
