## 二、注册基础 Functor
`abc::recommend_plt::feature_generate::FunctorAllocateHandlers` 是一个基于 Boost 单例模板的函数工厂注册器（factory registry）。调用 `FunctorAllocateHandlers::get_mutable_instance().Init()` 会在该单例对象内部向 `init_func_map` 中批量注册大量“函数构造器”（name -> factory lambda）。之后运行时可以通过 `FunctorAllocateHandlers::get_mutable_instance().Get(name)` 动态构造对应的 `Function` 实例（返回 `FunctionPtr`），供 `FunctionFactory` 等使用，实现按需（lazy）创建并复用实现类对象。

## 单例 & 类型说明
- 定义位置：function_factory.h
- 类声明：
  - class FunctorAllocateHandlers : public boost::serialization::singleton<FunctorAllocateHandlers>
  - 因为继承自 `boost::serialization::singleton`，可以使用静态方法 `get_mutable_instance()` 获取该单例实例（注意：这是 Boost 单例提供的 API 名称）。
- 内部数据：
  - `std::unordered_map<std::string, std::function<FunctionPtr()>> init_func_map;`
    - key = 函数名字（例如 "Add", "Sub" 等）
    - value = 工厂函数 / lambda，调用后返回 `FunctionPtr`（代码中使用 `std::make_shared<ConcreteFunction>`）
- 提供接口：
  - void Init();
  - void Register(const std::string& function_name, std::function<FunctionPtr()> func);
  - FunctionPtr Get(const std::string& function_name) const;

## get_mutable_instance().Init() 做了什么
- `Init()` 本身在 `function_factory.cc` 中实现为：
  - 它依次调用若干注册方法：
    - `RegisterBasicFunctions();`
    - `RegisterAggrFunctions();`
    - `RegisterAlgorithmFunctions();`
    - `RegisterBucktingFunctions();`
    - `RegisterMathFunctions();`
    - `RegisterStringFunctions();`
    - `RegisterOtherFunctions();`
    - `RegisterNullFunctions();`
- 每个 RegisterXxx 函数内部使用宏：
  - #define REGISTER(name, func) \
        Register(name, []() { return std::make_shared<func>(); });
  - 示例： REGISTER("Add", BinaryFunction<Plus>);
  - 也就是说 `Register("Add", [](){ return std::make_shared<BinaryFunction<Plus>>(); });`
- 因此 `Init()` 的效果是把仓库里实现的**所有**内建函数都以名字 -> 构造 lambda 的方式注入 `init_func_map`，供后续按名创建实例。

## Register / Get 的行为（语义与实现）
- Register(const std::string&, std::function<FunctionPtr()> func)
  - 将给定的 factory 存入 `init_func_map[function_name] = func;`
  - 若重复注册则覆盖（实现使用直接赋值）。
- Get(const std::string& function_name) const
  - 在 `FunctorAllocateHandlers` 中：查 `init_func_map`，若找到就调用存的 lambda，返回新创建的 `FunctionPtr`；否则返回 nullptr。
  - 这是“每次调用都会新建一个实例”的工厂行为（没有内部缓存，每次 Get 都构造）。

## 与 `FunctionFactory` 的协作（实际用法 / 调用链）
- `FunctionFactory`（header中也有）维护一个 `functions` map（string -> FunctionPtr），用于缓存已经创建并复用的 `Function` 实例。
- `FunctionFactory::Get(const std::string& function_name)` 的实现逻辑：
  1. 在 `functions` map 中查找已有实例；若存在直接返回（缓存命中）。
  2. 若不存在，则调用 `FunctorAllocateHandlers::get_mutable_instance().Get(function_name)`：
     - 该调用会触发对应的 factory lambda，返回一个新建的 `FunctionPtr`（如果注册过）。
  3. 如果得到非空 `FunctionPtr`，将其插入 `functions`（缓存）并返回；否则返回 nullptr。
- 因此调用流程典型为：
  - 启动时：main 调用 `FunctorAllocateHandlers::get_mutable_instance().Init();`（把所有名字注册好）
  - 运行时：某处需要 "Add" 功能，调用 `FunctionFactory::Get("Add")` -> 若未创建过则通过 FunctorAllocateHandlers 创建并缓存 -> 返回可用的 `FunctionPtr`。

## 设计意图和优点
- 把所有函数的“如何创建”逻辑集中注册，便于组织大量函数实现文件（你 repo 中确实包含很多实现文件）。
- 支持按需实例化（FunctionFactory 缓存层） + 工厂注册器（FunctorAllocateHandlers）解耦函数名与实现类。
- 通过 Lambda 返回 `std::shared_ptr`，生命周期简单，便于复用与释放。

## 并发 / 生命周期 / 边界考虑
- 调用时序：
  - 推荐在单线程上下文（程序初始化阶段）调用 `Init()`，然后再启动多线程（ `main()` 确实在 `Init()` 后开始 spawn 线程），这是安全且常见的做法。
- 并发安全：
  - `init_func_map` 是 `std::unordered_map`，`Register` 在 Init 时写入；`Get` 是 const 方法且只读访问（但会调用 lambda 并分配对象）。
  - 并发读（多个线程同时调用 `Get`）在 C++ 容器上是安全的（多线程同时只读一个未修改的容器通常是安全的），但若存在并发写（在 Init 之后再次调用 Register）会产生数据竞争。既然你的代码在启动时就初始化并随后只读，实际风险极低。
  - `FunctionFactory::Get` 在首次创建并插入 `functions` 时会写入 `functions` map；如果多个线程同时首次请求同一函数名，存在竞态（可能重复创建多个实例、插入冲突），`FunctionFactory` 没有锁保护。实际项目里常见策略：
    - 在启动时把所有常用实例预创建并缓存（避免并发插入）。
    - 或者在 `FunctionFactory` 中加入 mutex 或使用 double-checked locking 来保证线程安全插入。
- 错误 / 缺失注册：
  - 如果调用 `Get("UnknownName")`，返回 nullptr。调用方需检查 nullptr 并处理错误。
- 内存/覆盖：
  - 重复注册会覆盖旧的 factory，但 Init 中每个名字只注册一次，所以问题不大。

## 小示例（调用链梳理）
- 启动：
  - main -> FunctorAllocateHandlers::get_mutable_instance().Init();
- 运行时某处需要 "Add"：
  - auto f = function_factory.Get("Add");
    - function_factory 查缓存 (functions) -> not found
    - 调用 FunctorAllocateHandlers::Get("Add") -> 返回 std::make_shared<BinaryFunction<Plus>>()
    - function_factory 插入并返回该实例
