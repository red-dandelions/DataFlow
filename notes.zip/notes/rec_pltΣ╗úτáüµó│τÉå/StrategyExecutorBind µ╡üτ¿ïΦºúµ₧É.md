## StrategyExecutor::Bind 流程解析
- 输入：
  - `req`：请求消息（`api2::RecMsg`），包含上下文、策略 id 列表等；
  - `strategy_ids`：要执行的策略 id 列表（右值，可被交换）；
  - `rsp`：用于填充响应的指针（`api2::RecMsg*`）。
- 输出：
  - 返回 bool：true 表示请求在 executor 层已成功「绑定」并初始化好辅助组件（Graph、ES/KV helper 等），false 表示绑定失败（会中断后续执行）。
- 成功准则：
  - `accessor_`、`controller_`、`graph_`、`es_batch_helper_`、`kv_model_helper_` 等与该请求的绑定都成功。
- 失败模式：
  - 若 `accessor_->Bind(...)`、`controller_->Bind(...)`、`graph_->Bind(...)` 或 `kv_model_helper_->Bind(...)` 失败，函数返回 false；中间会记录日志/上报错误。

---

## 逐段详解（按执行顺序）

1) 将请求与策略放入成员变量
```cpp
req_ = &req;
rsp_ = rsp;
strategy_ids_.swap(strategy_ids);
```
- 目的：把传入请求指针/响应指针和策略 id 列表存到 `StrategyExecutor` 的成员，后续方法可以直接访问（例如 `MigrateStrategy()`、`accessor_->Bind()` 等）。
- 注意：先保存 `req_` 很重要，因为后续 `MigrateStrategy()` 会读取 `req_` 的字段。

2) 策略迁移（动态替换/扩展）
```cpp
MigrateStrategy();
```
- 会检查 `strategy_ids_` 中是否有特定前缀（如 `recplt_mc`, `recplt_filter` 等），按动态配置替换/扩展为新的实际策略 id 列表，必要时做监控埋点（PM_ADD）。

3) 把请求解析并填充到 Accessor（请求上下文对象）
```cpp
if (!accessor_->Bind(&req, rsp, strategy_ids_)) {
    return false;
}
```
- `accessor_->Bind(...)` 的职责：解析 `req` 内的 ctx features、site/user/item 信息、trace id 等，并把策略 id 列表记录在 `accessor` 中，完成后续 functor/graph 会使用这些上下文。
- 失败：如果 Bind 解析失败（例如入参不合法），函数直接返回 false。

4) 绑定 StrategyController 并设置 control params
```cpp
if (!controller_->Bind(accessor_.get())) {
    LOG_ERROR << "controller Bind fail";
    return false;
}
accessor_->SetupControlParams();
```
- `controller_->Bind` 读取 Accessor 中的 control param（例如 disable 列表、must_run、auto_degrade 等）并初始化 `StrategyController` 的状态。
- `accessor_->SetupControlParams()` 则可能把控制参数转成 accessor 方便后续使用。
- 失败：若 controller 绑定失败，记录错误并返回 false。

5) 判断是否需要 rebuild 流程（设置 analyzer 的标志）
```cpp
if (accessor_->GetCtxFeature<int64_t>(kFeaCPPrefix + "RebuildArranger_" + kOutputNum) > 0
    || accessor_->GetCtxFeature<int64_t>(kStrategyRebuildTruncateNum) > 0) {
    analyzer_->set_has_rebuild(true);
}
```
- 检查两个 ctx feature（control param）是否提示需要执行 Rebuild 阶段，如果是，告诉 `analyzer_` 构建 DAG 时考虑 rebuild 相关的 functor/arranger。

6) 绑定 Graph（把 Accessor/Controller 传给 Graph）
```cpp
if (!graph_->Bind(accessor_.get(), controller_.get())) {
    LOG_ERROR << "graph Bind fail";
    return false;
}
```
- `graph_->Bind` 会把请求级上下文与控制器传给 Graph，Graph 在后续运行时会读取这些信息来决定节点执行与超时等。失败则返回 false。

7) 计算并设置 Graph 的超时时间（动态 relax）
```cpp
const auto timeout = accessor_->GetCtxFeature<fmp::INT64>(kSvrStrategyTimeout, 500);
const auto relax_ms = std::min<int64_t>(timeout * 0.05, 50);
const auto dyn_relax = accessor_->GetCtxFeature<fmp::INT64>(kSvrStrategyRelax, relax_ms);
graph_->SetTimeout(timeout - dyn_relax);
```
- 取 ctx 中的 `kSvrStrategyTimeout`（默认 500ms），计算一个 relax（最多 50ms 或 5%），再取 `kSvrStrategyRelax`（若请求自定义），最终把 `timeout - dyn_relax` 传给 graph。
- 目的是给整体策略执行预留一个可调节的尾部时间窗口（例如做 response 构建/上报等）。
- 建议：应确保 `timeout - dyn_relax` 不为负（代码没有显式 clamp）。

8) 绑定 EsBatchHelper 并传入 pool 回调
```cpp
es_batch_helper_->Bind(accessor_.get(),
    [=](const match::SrchRecallRequest& req,
        int32_t timeout, EsBatchHelper::ResponseCb&& cb) {
    auto pool_ptr = StrategyAsyncPool::get_mutable_instance().AsyncPool();
    pool_ptr->Invoke<match::SrchRecallService>(
            &match::SrchRecallService::Stub::PrepareAsyncDoSrchRecall,
            req,
            timeout,
            std::move(cb),
            accessor_->trace_key()
    );
});
```
- 意图：告诉 `es_batch_helper_` 当需要发送合并的召回请求时，应如何把请求提交到异步 RPC 层（`StrategyAsyncPool`）。
- 这个 lambda（pool_cb）做了：
  - 从全局/单例 `StrategyAsyncPool` 获取一个 async pool；
  - 调用 pool 的 `Invoke<match::SrchRecallService>(...)`，把 `req`、`timeout`、回调 `cb`（通过 `std::move`）和 `accessor_->trace_key()`（用于 trace）传入；
  - `Invoke` 将异步发起 gRPC 请求（PrepareAsyncDoSrchRecall）并在 RPC 完成后执行 `cb`。
- 注意点：
  - lambda 使用 `[=]` 捕获（按值捕获外部可用变量）；其中访问 `accessor_`（成员变量）会以 `this` 的形式被访问/捕获（需注意生命周期，见后文）。
  - `cb` 是右值引用（`ResponseCb&&`），内部用 `std::move(cb)` 将回调所有权转交给 `Invoke`。
  - `es_batch_helper_` 在 later 时刻会调用这个 lambda（即它会保存 lambda 并在需要时触发），因此 lambda 内部捕获的指向 `accessor_`/`this` 的指针必须在回调调用时仍然有效。

9) 绑定 KV helper 并返回最终结果
```cpp
return kv_model_helper_->Bind(accessor_.get());
```
- 最后一步把 `accessor` 绑定给 `kv_model_helper_`，并把 `kv_model_helper_->Bind(...)` 的返回值直接作为 `StrategyExecutor::Bind` 的结果。
- 若 `kv_model_helper_->Bind` 返回 false，则该 Bind 失败；如果返回 true，则表示 request 在 executor 层绑定成功，后续可开始 Analyzer/BuildDAG/Run。

# Accessor::Bind

- 输入：
  - `rec_msg_req`：请求（`api2::RecMsg*`），包含 context、user、item 列表、srch_request（可选）等。
  - `rec_msg_rsp`：输出响应的 protobuf 指针，供后续填充。
  - `strategy_ids`：策略 id 列表（可修改，后续 `ParseInterleavingRule` 可能会插入 interleaving 策略）。
- 输出：
  - 返回 bool（本函数实现总是返回 true，除非中间抛异常），同时会把大量请求相关的数据填充进 `Accessor` 的成员（`rec_msg_req_`、`rec_msg_rsp_`、`ctx_feature_`、`item_feature_`、`origin_items_` 等）。
- 目的：
  - 将外部请求解包并初始化请求级上下文（Accessor），为后续 Analyzer/Graph/Functor 执行提供所需信息。

---

## 逐段说明

1) 绑定请求指针与基础字段（成员赋值）
```cpp
rec_msg_req_ = rec_msg_req;
rec_msg_rsp_ = rec_msg_rsp;
debug_mode_ = rec_msg_req->context_msg().debug_mode();
svr_mark_mode_ = rec_msg_req->context_msg().svr_mark_mode();
rec_mark_mode_ = rec_msg_req->context_msg().rec_mark_mode();
item_type_ = rec_msg_req->context_msg().item_type();
item_source_ = rec_msg_req->context_msg().item_source();
req_source_ = rec_msg_req->context_msg().req_source();
scene_id_ = rec_msg_req->context_msg().scene_id();
trace_id_ = rec_msg_req->trace_id();
step_id_ = rec_msg_req->context_msg().step_id();
site_id_ = rec_msg_req->context_msg().site_id();
site_uid_ = rec_msg_req->context_msg().site_uid();
request_id_ = rec_msg_req->context_msg().request_id();
request_time_ =  rec_msg_req->context_msg().request_time();
error_log_enable_ = rec_msg_req->context_msg().log_mode();
poskey_ = rec_msg_req->context_msg().poskey();
auto& dev_id = rec_msg_req->user_msg().device_id();
auto& cookie_id = rec_msg_req->user_msg().cookie_id();
trace_key_ = std::to_string(scene_id_) + "_" + trace_id_;
SPDLOG_SET_TRACE_INFO(trace_id_, std::to_string(scene_id_), std::to_string(item_source_), step_id_);
```
- 做了什么：把 `rec_msg_req`/`rec_msg_rsp` 存入内部成员；把 request header/上下文的常用字段抽取到 Accessor 成员（如 scene、trace、site、item_type、item_source、step、request_time、poskey 等）；计算 `trace_key_`（scene_id_traceid）并设置日志追踪上下文（宏 `SPDLOG_SET_TRACE_INFO`）。
- 副作用：后面代码以及其他组件会读取这些成员；`rec_msg_rsp_` 被保存以便 later 填充响应字段。
- 注意：没有对 `rec_msg_req`/`rec_msg_rsp` 做空指针检查（假设调用方保证非空）。

2) 填充若干上下文特征（context features）
```cpp
AddCtxFeature("mid", rec_msg_req->user_msg().mid());
AddCtxFeature("devid", rec_msg_req->user_msg().device_id());
AddCtxFeature("cookie_id", rec_msg_req->user_msg().cookie_id());
AddCtxFeature("ugid", rec_msg_req->user_msg().ugid());
AddCtxFeature("language_flag", rec_msg_req->context_msg().language_flag());
AddCtxFeature("request_id", request_id_);
AddCtxFeature("user_id", cookie_id.empty() ? dev_id : cookie_id);
AddCtxFeature("poskey", poskey_);
```
- 做了什么：将常用的用户/设备/语言/请求 id 等信息包装成 `ctx_feature_`（通过 `AddCtxFeature`，它会加写锁并把值放到 `ctx_feature_`）。
- 目的：使 Functor/Analyzer 可以通过 `GetCtxFeature` 快速访问。

3) 保存原始 context map 与 user profile 引用、清零阶段计数
```cpp
raw_ctx_ = &rec_msg_req->context_msg().context_map();
raw_user_profile_ = &rec_msg_req_->user_msg().user_profile();
stage_expect_cnt_.fill(0);
stage_success_cnt_.fill(0);
```
- 做了什么：保持对原始 protobuf map 的 const 指针（便于 later 需要原始 string map 时直接访问），并将 stage 的计数器重置为 0。
- 注意：`raw_ctx_` 指向外部 protobuf 存储，不能在请求销毁后使用。

4) 处理 srch_request 特殊路由情况（300 场景）
```cpp
const bool use_srch_request = (scene_id_ == 300 && rec_msg_req->has_srch_request());
const auto& req_context_map = use_srch_request ? rec_msg_req->srch_request().context() : rec_msg_req->context_msg().context_map();
for (const auto& p: req_context_map) {
    AddCtxFeature(p.first, p.second);
    // 处理 goods_id/top_goods_id 特殊字段 -> 衍生 main_goods_id/top_goods_id
    // 处理 ctrl_white_list 字段，拆分并插入 ctrl_white_list_ 集合
}
```
- 做了什么：如果是特定场景（scene_id == 300）并且请求里有 `srch_request`，则从 `srch_request` 的 context 读取 context map；否则读取普通 context_map。然后把每个 key/value 加入 `ctx_feature_`。对 `goods_id`/`top_goods_id` 另外生成派生字段（main_goods_id(s)），并对 `ctrl_white_list` 做逗号分割后填入集合 `ctrl_white_list_`。
- 目的：兼容路由类型请求，保持字段来源正确。
- 注意：注释里明确“这段代码顺序不能随意调整”，因为 `ctx_feature_` 的类型与插入逻辑与后续代码有关。

5) 复制额外的 trans/scene 参数
```cpp
for (const auto& p: rec_msg_req->context_msg().trans_ctx_feature()) {
    AddCtxFeature(p.first, p.second);
}
for (const auto& kv: rec_msg_req->context_msg().scene_info().svr_param()) {
    AddCtxFeature(kv.first, kv.second);
}
for (const auto& kv: rec_msg_req->context_msg().scene_info().str_svr_param()) {
    AddCtxFeature(kv.first, kv.second);
}
```
- 做了什么：把转发的 context 特性 & scene 的 server 参数全部注入到 `ctx_feature_`。
- 副作用：增加更多可能被策略/feature 映射使用的上下文键。

6) 解析 interleaving（插屏/插入）规则并可能修改策略列表
```cpp
ParseInterleavingRule(rec_msg_req, strategy_ids);
```
- 做了什么：分析请求中的 interleaving 规则（`interleaving_rule()`），并根据规则在 `strategy_ids` 中插入对应的 interleaving 策略、fuse 算子或其它辅助策略（见实现：插入 `kGlobalInterleavingCombineId`、inl_fuse、further_fuse 等），同时填充 `inl_id_mp_`、`inl_name_mp_`、`inl_sid_mp_` 等映射。
- 目的：确保策略序列包含 interleaving 所需的算子并记录映射关系以供后续 `BindStrategyId`/functor 处理。
- 注意：此方法会修改 `strategy_ids`（传入的是引用），所以后续基于该列表的逻辑会使用修改后的顺序/内容。

7) 根据 svr_mark_mode 设置全量埋点模式
```cpp
if (rec_msg_req->context_msg().svr_mark_mode() == 2) {
    set_svr_mark_full_mode(true);
}
```
- 作用：当后端埋点模式为 2 时，启用 `svr_mark_full_mode_`（影响后续上报字段）。

8) 解析 user profile tags 并把 tag 加入 ctx feature
```cpp
int has_user_profile = 0;
for (const auto& tag: rec_msg_req->user_msg().user_profile().tags()) {
    const auto key = "user_" + std::to_string(tag.hkey());
    auto fea = feature::FeatureFactory::CreateVector<int64_t>(tag.value().values());
    AddCtxFeature(key, fea);
    has_user_profile = 1;
}
AddCtxFeature(kHasUserProfile, has_user_profile);
```
- 做了什么：把用户 profile tags（每个 tag 有 hkey/value）转成特征 vector 并保存为 `user_<hkey>` 的 ctx feature，同时设置 `kHasUserProfile` 标志（1/0）。
- 目的：为特征抽取/召回器提供用户画像特征。

9) 把请求中 `trans_item_feature`（预先带上来的 item group features）添加到 group_data（用于 `GetItemFeatureImpl`）
```cpp
for (const auto& kv: rec_msg_req->item_msg().trans_item_feature()) {
    fmp::FeatureGroupData gdata(kv.second);
    AddItemFeature(std::move(gdata));
}
```
- 做了什么：将外部携带的 item group feature（结构化的 group）合并到 `group_data_vec_`，并在 `feature_pos_map_` 中登记位置元信息（`AddItemFeature(fmp::FeatureGroupData&&)` 会更新 `feature_pos_map_`）。
- 后续意义：`GetItemFeatureImpl` 可以从这些 group 数据中按 item idx 抽取 item-level features。

10) 根据是否是 search route 决定如何填充 item 列表（调用 BindSrchGoods 或 BindRecGoods）
```cpp
if (use_srch_request) {
    if (debug_mode_) {
        AddCtxExplain("srch_req", "srch_req", feature::FeatureFactory::CreateSingle<std::string>(rec_msg_req->srch_request().ShortDebugString()));
    }
    BindSrchGoods(rec_msg_req); // 路由传参接口进行 item 的赋值
} else {
    BindRecGoods(rec_msg_req);  // 推荐接口 item 的赋值
}
```
- 做了什么：如果是 search 路由（use_srch_request），把 srch_request 提供的 recall_goods 解析为 internal `Item` 列表（通过 `BindSrchGoods`）；否则通过 `BindRecGoods` 从通用 `item_msg` 填充。
- `BindRecGoods/BindSrchGoods` 会：
  - 遍历 item 列表，创建 `Item`（id, score, item_source 等），调用 `AddItem` 把它加入 `entity_items_`、`origin_items_`、`arranged_items_`；
  - 创建若干 item-level 特征（例如 GScore、GLocation、GMixItemSource、GLayer 等）并放入 `item_feature_`（通过 `AddItemFeature`）。

11) 再次添加多个关键 ctx 特征（注意顺序重要）
```cpp
AddCtxFeature("trace_id", rec_msg_req->trace_id());
AddCtxFeature("scene_id", rec_msg_req->context_msg().scene_id());
AddCtxFeature("step_id", rec_msg_req->context_msg().step_id());
AddCtxFeature("site_id", rec_msg_req->context_msg().site_id());
AddCtxFeature("site_uid", rec_msg_req->context_msg().site_uid());
AddCtxFeature("item_source", rec_msg_req->context_msg().item_source());
AddCtxFeature("item_type", rec_msg_req->context_msg().item_type());
AddCtxFeature("req_num", rec_msg_req->context_msg().req_num());
AddCtxFeature("req_source", rec_msg_req->context_msg().req_source());
AddCtxFeature("language", rec_msg_req->context_msg().language_flag());
AddCtxFeature("member_id", rec_msg_req->user_msg().mid());
AddCtxFeature("item_source_req", std::to_string(rec_msg_req->context_msg().item_source()));
std::unordered_map<int64_t, std::string> rule_map(rec_msg_req->context_msg().rule_map().begin(), rec_msg_req->context_msg().rule_map().end());
AddCtxFeature("rule_map", feature::FeatureFactory::CreateFeatureMap(std::move(rule_map)));
```
- 做了什么：填充更多上下文 key/values。把 `rule_map`（int64 -> string）转为 `FeatureMap` 并加入 `ctx_feature_`。
- 注：代码注释特别提醒“顺序不能随意调整”，因为上面某些字段的类型/存在会影响后续逻辑或 feature 映射。

12) 分割策略集合到 scene/hp 参数集合
```cpp
SplitHpAndScene(strategy_ids);
```
- 做了什么：把 `strategy_ids` 列表按某些切换算子（`kSceneSave`, `kHpSave`）分为 `scene_param_ids_` 与 `hp_param_ids_` 两组（用于后续策略参数分组）。

13) 上下文映射、填充默认、特征映射设置、构建 trace 字符串
```cpp
SetupCtxMapping(rec_msg_req);
PaddingCtxFeature();
SetupFeatureMapping();
BuildTraceMsg();
```
- `SetupCtxMapping`：把一些常用字段存入 `req_fea_val_map_`（用于后续 feature mapping lookup），比如 user_id、scene_id、site_id、language 等。
- `PaddingCtxFeature`：保证某些 ctx keys 存在（page_cate、device_model 等），避免 later 访问为空。
- `SetupFeatureMapping`：基于某些 raw features（site_uid、cate 等）查询 kv 映射表（`DataAutoApi::GetKVModelFromPVC`），把映射结果写回到 ctx_feature（例如 site_country）并更新 `req_fea_val_map_`。
- `BuildTraceMsg`：构造一条简短的 trace 字符串 `request_trace_msg_`。

14) 把策略按 class 分类并生成相应 ctx feature（AddClassifiedStrategyIds）
```cpp
AddClassifiedStrategyIds(strategy_ids);
```
- 做了什么：通过 DataAutoApi 获取每个策略的 `StrategyParam`，把同类型（functor name）策略聚集成列表，然后把这些列表作为 ctx feature 写入，方便 Functor/Analyzer 以类型为单位读取策略列表。

15) 解析并注入以 `kParamPrefix` 开头的策略参数为 ctx feature
```cpp
for(const auto& param : strategy_ids) {
    auto it = std::find_if(kParamPrefix.begin(), kParamPrefix.end(),
        [&param](const std::string& prefix) { return boost::starts_with(param, prefix);});

    if (it != kParamPrefix.end()) {
        std::vector<std::string> param_val;
        boost::split(param_val, param, boost::is_any_of(":"));
        if (param_val.size() == 2) {
            AddCtxFeature(param_val[0], param_val[1]);
        }
    }
}
```
- 做了什么：对于以某些前缀（kParamPrefix）开头的策略 id，如 `foo:bar` 形式，把 `foo`=`bar` 注入到 ctx_feature（把策略参数变成 ctx-level 参数）。

16) 最终把经过处理的策略 ids 存到 `strategy_ids_`
```cpp
strategy_ids_ = strategy_ids;
```
- 副作用：Executor/Analyzer 会用 `accessor_->strategy_ids()` 或 `StrategyExecutor` 中的 `strategy_ids_`（注意 StrategyExecutor 在 Bind 前可能已经有自己的 list）。

17) 特殊实验判断（南京精排）与高效监控标志
```cpp
if ((item_source_ == api2::ItemSource::CLEAR || item_source_ == api2::ItemSource::TRAFFIC)
    && scene_id_ == 105) {
    AddCtxFeature("is_nanjing_rank", 1);
}
set_high_efficiency_monitor_flag(GetCtxFeature<fmp::STRING>("recplt_high_efficiency_enable", "0") == "1");
```
- 做了什么：基于 item_source 与 scene_id 判断并设置 `is_nanjing_rank`，并读取 control/dynconf 参数决定是否启用高效监控标志。

18) 预分配和初始化 response protobuf 的一些结构（避免并发写造成问题）
```cpp
// protobuf 不是线程安全的, 多线程写不同字段会丢数据，预先分配map槽位就OK
rec_msg_rsp_->mutable_item_msg()->mutable_trans_item_feature()->insert({item_source(), {}});
rec_msg_rsp_->mutable_trace_msg()->add_error_code(0);
```
- 做了什么：向 `rec_msg_rsp_` 的 `trans_item_feature` map 插入一个空条目（key 为 `item_source()`），以及在 trace_msg 中加入一个 error_code = 0。目的是预先分配 map 的槽位，降低后续多线程写同一 pb 时的数据丢失风险（注释已说明：protobuf 非线程安全，预分配 map 槽位可缓解部分并发写问题）。
- 注意：这只是减缓并发问题，不能完全保证线程安全；对 protobuf 的并发写仍需谨慎（最好由单个线程负责写 response 或在锁内写）。

19) 返回 true
```cpp
return true;
```
- 说明：Bind 执行完成，Accessor 已被初始化好供后续阶段使用。

---

# Controller::Bind

- 输入：`accessor`（请求级上下文，已由 `Accessor::Bind` 填好）
- 输出：返回 bool（此实现总是返回 true）
- 副作用：
  - 将 `accessor_` 保存到 controller；
  - 可能从 `StrategyExecutor` 中临时分配并运行若干 `ControlParamExtractor` functor（这些 functor 会被加入 executor 的 functor 池/资源）；
  - 从 `accessor` 中读取各种 Control Param（CP），并填充 controller 的内部状态：`disable_*` 集合、`must_stages_`、`disable_all_`、`degrade_type_`、`pm_type_`、并把一些 `CP_replace_param` 写回到 `accessor->ctx_feature_`。

## 逐段解释

1) 入口与初始化
```cpp
accessor_ = accessor;
std::unordered_set<std::string> cp_ids;
StrategyParam param;
auto& data_api = model::DataAutoApi::get_mutable_instance();
```
- 把 `accessor` 保存在 `this->accessor_`，准备读取 ctx 特征。
- 创建 `cp_ids` 用于去重 CP id，避免重复处理同一 CP。

2) 从不同层级的 CP id（general/scene/step）读取并执行 ControlParam 提取器
```cpp
for (const auto& stg_conf: {"general_cp_id", "scene_cp_id", "step_cp_id"}) {
    if (auto fea = accessor->GetCtxFeaturePtr<fmp::INT64>(stg_conf)) {
        const auto cp_id = std::to_string(fea->data());
        const std::string rec_cp_id = "rec_recall_cp:" + cp_id;
        const std::string scc_cp_id = "scc_recall_cp:" + cp_id;
        if (cp_ids.count(cp_id)) { continue; }
        cp_ids.insert(cp_id);
        const auto& str_cp_id = data_api.GetStrategyParam(rec_cp_id, &param) ? rec_cp_id : scc_cp_id;
        if (auto functor = executor_->BindStrategyId(str_cp_id)) {
            auto extractor = static_cast<ControlParamExtractor*>(functor);
            extractor->Run(accessor);
        }
    }
}
```
- 意图：三个层级（general/scene/step）可能各自有 control param id（整数），读取这些 id：
  - 构造两个可能的策略 id：`rec_recall_cp:<id>`（优先）和 `scc_recall_cp:<id>`（fallback）；
  - 用 `DataAutoApi::GetStrategyParam` 检测 `rec_recall_cp:` 是否存在配置；若存在就用它，否则使用 `scc_recall_cp:`；
  - 去重：若同一 `cp_id` 在多个层级出现，避免重复处理；
  - 调用 `executor_->BindStrategyId(str_cp_id)`：这会从 FunctorPool 获取一个对应 functor（应该是 `ControlParamExtractor`），并将其加入 executor（即在 `functor_map_` / `functor_resource_` 中占位）；
  - 将 functor 强制转型为 `ControlParamExtractor*` 并执行 `extractor->Run(accessor)`：运行时提取 CP（control param）并把其写回到 `accessor` 的 ctx_feature（该 extractor 的实现会将 CP 的各项写入 `CP_*` 键）。
- 隐含行为要点：
  - 这里会在 controller 绑定阶段“动态分配并运行”策略对应的 functor（control param extractor），而不是在 Analyzer 构图阶段统一创建。这使得 CP 提取早于 Analyzer/Graph，CP 值能立即影响后续的 Bind/Build/Run 行为。
  - `executor_->BindStrategyId` 在内部会调用 `GetStrategyParam` 再分配 functor；若 `str_cp_id` 不存在（两者都不存在），`BindStrategyId` 会返回 nullptr（无进一步动作）。

3) 处理 must_stages（必须执行的阶段）
```cpp
const std::vector<std::string> stage{"",kFeaCPMustPrerank,"",kFeaCPMustRank,"",""};
for (int i = 0; i < stage.size(); ++i) {
    if (!stage[i].empty() && accessor->GetCtxFeature<fmp::INT64>(stage[i])) {
        must_stages_[i] = true;
    }
}
```
- 解释：通过一个字符串向量映射一些 control-feature 名（只有索引对应位置非空时才检查），如果对应 ctx feature 存在且为真，则把 `must_stages_[i]` 标为 true。
- 目的：`must_stages_` 用于在 `AllowBuild` 中决定在没有用户画像时某些阶段（prerank/rank）是否仍必须执行。
- 注意：这种用法依赖 `stage` 向量索引和 `must_stages_` 下标语义一致（有点隐式，易碎）。

4) 读取各种 disable 列表（id/name/type/stage/prefix）和 disable_all
```cpp
if (auto fea = accessor->GetCtxFeaturePtr<fmp::LIST_STRING>(kFeaCPDisableStrategyId)) {
    disable_strategy_ids_.insert(fea->data().begin(), fea->data().end());
}
... // 同理读取 name/type/stage/prefix
if (auto fea = accessor->GetCtxFeaturePtr<fmp::INT64>(kFeaCPDisableStrategyAll)) {
    disable_all_ = static_cast<bool>(fea->data());
}
```
- 将请求上下文里来自 CP 的各种“禁用”设置读入 controller 的集合字段，以便 `AllowRun` 使用这些集合判断是否跳过某个 functor/strategy。

5) 处理 CP 替换参数（`CP_replace_param`）
```cpp
if (auto fea = accessor->GetCtxFeaturePtr<fmp::LIST_STRING>(kFeaCPReplaceParam)) {
    for (auto& param: fea->data()) {
        const auto vec = util::Split2(param, ':');
        if (vec.size() == 2) {
            accessor->AddCtxFeature(vec[0], vec[1]);
        }
    }
}
```
- 解释：CP 中可以包含格式为 `key:val` 的字符串列表，Bind 会把这些对解析并把 `key=val` 写进 `accessor->ctx_feature_`。这是 runtime 覆写上下文/参数的一种方式（例如临时切换参数）。

6) 随机百分比停用阶段（percent sampling）
```cpp
if (auto fea = accessor->GetCtxFeaturePtr<fmp::INT64>(kFeaCPPercentPreRank)) {
    if (Sample100(fea->data())) {
        disable_strategy_stages_.insert(stage2str[PRERANK]);
    }
}
if (auto fea = accessor->GetCtxFeaturePtr<fmp::INT64>(kFeaCPPercentRank)) {
    if (Sample100(fea->data())) {
        disable_strategy_stages_.insert(stage2str[RANK]);
    }
}
```
- 解释：按百分比采样（`Sample100(n)` 表示按 n% 概率触发）。如果采样触发，则把对应阶段（PRERANK 或 RANK）加入 `disable_strategy_stages_`，从而禁用该阶段。
- 用途：临时做流量/功能切换或 A/B 随机降级。

7) Monitor / Prometheus 类型的动态设置
```cpp
if (auto fea = accessor->GetCtxFeaturePtr<fmp::INT64>(kFeaCPMonitorDegradeType)) {
    if (fea->data() != degrade_type_) {
        degrade_type_ = fea->data();
        COLLECT_MONITOR_SET_DEGRADE(degrade_type_);
    }
}
if (auto fea = accessor->GetCtxFeaturePtr<fmp::INT64>(kFeaCPMonitorPrometheusType)) {
    if (fea->data() != pm_type_) {
        pm_type_ = fea->data();
        COLLECT_MONITOR_SET_PROMETHEUS(fea->data());
    }
}
```
- 解释：从 CP 读取监控/降级类型设置；如有变化，更新 controller 的内部记录并调用全局监控配置接口（宏）设置监控维度/导出方式。
- 副作用：运行时改变监控/降级配置（进程级或线程安全的宏需保证可并发修改）。

8) 返回 true
```cpp
return true;
```
- 说明：Bind 完毕，Controller 的状态已根据 CP 初始化。

---

## 相关联的后续行为（为什么要在 Bind 执行这些）
- 运行 ControlParamExtractor（通过 executor->BindStrategyId(...)->Run）能把 CP 的具体字段写入 `accessor`，这些 CP 键随后会被 controller 读取（例如 `CP_disable_strategy_id`、`CP_replace_param` 等）。因此 Controller 在 Bind 阶段主动“加载并运行” CP 提取器，确保 CP 可用。
- Controller 的内部集合（disable ids/types/stages/prefixs、must_stages）在后续 `Analyzer` 构图或 `Graph` 执行时通过 `AllowBuild`/`AllowRun` 生效，从而控制哪个 functor （策略）被构建或执行。

---

# Accessor::SetupControlParams

- 功能：从 ctx 特征（Control Params / 动态配置）读取多个控制开关 / 采样 / 上报相关参数，设置 `Accessor` 的运行标志（布尔开关、采样决定、上报策略等），并执行若干初始上报（context explain / data version）。
- 输出：在 `Accessor` 内部设置一系列标志（如 feature_landing_enable_、strategy_report_fea_enable_、monitor_report_enable_、trace_report_enable_ 等）；无外部返回值。

---

## 逐行/逐段解释（按实现顺序）

1) feature_landing（落地特征）逻辑
- 代码要点（语义）：
  - 读取控制特征 `is_feature_landing`（通过 `GetControlCtxFeature<fmp::INT64>("is_feature_landing")`），如果存在：
    - 读取 `feature_landing_enable`（字符串形式，默认 "0"）；
    - `enable1 = is_landing == 1 && (req_source == 0 || landing_enable != "0")`
    - `enable2 = is_landing == 2 && landing_enable != "0"`
    - `enable3 = GetControlCtxFeature<fmp::STRING>("feature_landing_sample", "1") == "1"`
    - 最终：`feature_landing_enable_ = (enable1 || enable2) && enable3`
- 目的与含义：
  - `is_feature_landing` 决定是否可能打开 feature landing；
  - 根据不同值（1 或 2）和 `feature_landing_enable` 配置，结合采样 `feature_landing_sample`，决定是否真的启用 feature landing。
- 使用场景：
  - 线上控制是否把额外的“落地特征”上报/记录到外部系统（例如做特征回放或离线验证）。
- 注意：
  - `req_source() == 0` 的检查用于区分内部/外部请求来源（通常内部请求默认可见）。

2) strategy report（策略上报）相关
- 代码要点（语义）：
  - 先检查动态配置 `GetDynConf<bool>("strategy_report_enable", true)` 与控制特征 `CP_stage`（`GetControlCtxFeature<fmp::INT64>("strategy_report_enable", 1)`）。
  - 如果总体开启：
    - 读取 `kStrategyReportFeaRate`（采样比例，整数），通过 `Sample100` 做采样决定 `strategy_report_fea_enable_`；
    - 读取 `kStrategyReportMetricRate`（metric 采样），用 `Sample100`（并支持 multi 比例返回）设置 `strategy_report_metric_enable_` 与一个 multi 值写入 ctx（`kStrategyReportMetricMulti`）。
- 目的：
  - 控制是否进行策略级别的特征或指标上报（用于离线分析或评估）。
- 细节：
  - `Sample100` 抽样函数会基于随机/trace 做 0-99 的采样；`multi` 用于统计多重采样倍数（便于上报计数恢复）。

3) ABT / kafka 与 TF item mapping 等开关
- 代码要点（语义）：
  - `abt_kafka_enable_` = (req_source==0 || GetControlCtxFeature("abt_kafka_enable","0") == "1")
  - `tf_item_country_map_enable_` = control feature `rec_tf_model_item_country_mapping_enable` == "1"
  - `tf_item_country_map_country_` = control feature `rec_tf_model_item_country_mapping_country`（字符串）
  - `rerank_hit_report_enable_` = `GetControlCtxFeature<int64_t>("rerank_hit_report_enable", 0) == 1`
  - `monitor_report_enable_` = `GetDynConf<bool>("monitor_report_enable", true)`
  - `trace_report_enable_` = `GetControlCtxFeature<fmp::STRING>("trace_enable", "") == "1"`
  - `report_recplt_recmark_enable_` = `GetControlCtxFeature<fmp::INT64>("report_recplt_recmark", 0) == 1`
- 目的：
  - 控制各种上报、Kafka 相关、以及 TF 模型的国家映射特性是否启用，均以 CP/动态配置为准，可针对单请求覆盖/采样。
- 影响：
  - 后续 Reporter 类（如 AbtKafkaReporter、FeatureLandingReporter、MonitorReporter、TraceReporter 等）会看这些开关决定是否实际上报、构建额外字段或执行昂贵逻辑。

4) filter_roi_opt 实验参数解析（从 rule_map）
- 代码要点（语义）：
  - 若存在 `rule_map`（ctx feature，类型为 `FeatureMap<int64_t,string>`），取 `common::ItemSource::NATURAL` 对应条目（即某个 item_source 的规则串），判断该字符串是否包含子串 `recplt_filter_roi_opt`，若包含则把 `filter_roi_opt_enable_ = true`。
  - 同时 `AddCtxFeature("recplt_filter_roi_opt", filter_roi_opt_found)` 与 `AddCtxExplain("recplt_filter_roi_opt", std::to_string(filter_roi_opt_found))`（用于 debug explain）。
- 目的：
  - 在 CP / rule_map 中以字符串方式开启某个实验分支 `filter_roi_opt`（可能控制过滤/ROI 相关优化）。
- 注意：
  - `rule_map` 是按 item_source/key 存放的字符串 map，读取方式需保证 key 存在安全。

5) ReportCtxFeature() 与 ReportDataVersion()
- 代码要点：
  - `ReportCtxFeature()`：当 debug 模式打开时，把 ctx_feature_ 中的关键字段和 env/async pool 下游信息以 explain 形式收集（方便 debug）。
  - `ReportDataVersion()`：当 debug mode 打开时，读取版本管理器 `VERSION_MGR.Get().GetAllLastVersion()` 并把每个数据模型的版本/更新时间写入 ctx table（供 explain / debug）。
- 目的：
  - 在 debug 模式下，提供可解释的上下文与数据版本信息，便于诊断及线上排查。

---

## 这些标志后续在哪里被使用（影响点）
- `feature_landing_enable_` → 由 `FeatureLandingReporter` 或相关模块决定是否构建并上报 feature-landing 数据。
- `strategy_report_fea_enable_` / `strategy_report_metric_enable_` → 决定 `StrategyReporter` 是否收集并上报策略特征/指标。
- `abt_kafka_enable_` → 控制 ABT/实验相关 Kafka 上报路径。
- `tf_item_country_map_enable_` → 在 TF 模型输入预处理/映射过程中使用，影响模型输入的特征名/值转换。
- `monitor_report_enable_` / `trace_report_enable_` → 控制 `MonitorReporter`、`TraceReporter` 的行为（是否上报、是否收集更多指标）。
- `filter_roi_opt_enable_` → 影响某些 filter / arranger 的内部逻辑（实验分支）。

---

# Graph::Bind

函数实现如下：

```cpp
bool Graph::Bind(Accessor* accessor, StrategyController* controller) {
    accessor_ = accessor;
    controller_ = controller;
    return true;
}
```

# 其他EsBatchHelper::Bind 和 KVModelHelper::Bind

```cpp
bool EsBatchHelper::Bind(Accessor* accessor, PoolCb&& pool_cb) {
    accessor_ = accessor;
    pool_cb_ = std::move(pool_cb);
    es_country_enable_ = false;
    if (util::GetEnv("ES_COUNTRY_ENABLE") == "true") {
        es_country_enable_ = true;
    }
    return true;
}
```

```cpp
bool KVModelHelper::Bind(Accessor* accessor) {
    acc::KVModelClient::BaseInfo base_info;
    base_info.debug_mode = accessor->debug_mode();
    base_info.seq_no = accessor->trace_id();
    base_info.dim_map = &(accessor->GetReqFeaValMap());
    kv_model_client_->Bind(base_info);
    const auto svr_timeout = GetServiceTimeout(kServiceRedis, 50);
    accessor_ = accessor;
    return true;
}
```

