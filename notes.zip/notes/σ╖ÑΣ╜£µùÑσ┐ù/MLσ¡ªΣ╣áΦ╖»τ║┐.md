ML书籍顺序

1. 基础：《Deep Learning》（花书）
2. 进阶：《Deep Learning with PyTorch》
3. 大模型：《Transformers for Natural Language Processing》、《Generative Deep Learning》

论文：《Attention Is All You Need》、GPT 系列、Diffusion 模型

DeepSpeed相关论文

------

## 一、DeepSpeed / ZeRO 技术的演进脉络

DeepSpeed 是微软推出的一个用于大规模分布式训练优化的库，其核心在于内存优化、并行策略、通信优化、推理加速、量化压缩等多个方向。其发展脉络大致可分为以下阶段：

| 阶段 / 关键技术                                   | 主要挑战                                                     | 解决方案 / 关键思想                                          |
| ------------------------------------------------- | ------------------------------------------------------------ | ------------------------------------------------------------ |
| **ZeRO / DeepSpeed 初始**                         | GPU 显存受限 → 无法训练更大模型                              | 引入 **Zero Redundancy Optimizer（ZeRO）**，将模型、梯度、优化器状态在多个设备间做分割 / 分区，减少每个设备的内存冗余。 ([arXiv](https://arxiv.org/abs/1910.02054?utm_source=chatgpt.com)) |
| **ZeRO-Infinity / Offload + 异构内存**            | 即使用 ZeRO，GPU 显存仍然是瓶颈                              | ZeRO-Infinity 把 CPU 内存 / NVMe 存储也纳入管理，做到参数 / 激活 / 优化器状态的混合放置 / 分区与迁移，从而“跨越 GPU 内存墙”。 ([微软](https://www.microsoft.com/en-us/research/blog/zero-infinity-and-deepspeed-unlocking-unprecedented-model-scale-for-deep-learning-training/?utm_source=chatgpt.com)) |
| **通信优化 / ZeRO++**                             | 随着规模扩大，通信开销成为瓶颈                               | ZeRO++ 提出多种通信压缩 / 重映射 / 低精度通信策略，减少 ZeRO 的通信体量，从而提高吞吐。 ([微软](https://www.microsoft.com/en-us/research/publication/zero-extremely-efficient-collective-communication-for-giant-model-training/?utm_source=chatgpt.com)) |
| **针对推理 / 多专家 /长序列 /检查点 /容错等扩展** | 推理时也要用很大模型 / 多专家模型 / 长上下文 / checkpoint 太慢 / 稳定性 | DeepSpeed Inference、DeepSpeed-MoE、混合并行 / 混合专家 (Mixture-of-Experts) 策略、通用 checkpoint 方案、长序列训练优化等一系列拓展。 ([微软](https://www.microsoft.com/en-us/research/project/deepspeed/publications/?utm_source=chatgpt.com)) |

微软的 DeepSpeed 项目主页就列出其近年来的出版物，可以看到从 2020 年起到 2024 年，围绕 ZeRO、通信优化、推理优化、检查点策略、长序列模型训练等方向不断推进。 ([微软](https://www.microsoft.com/en-us/research/project/deepspeed/publications/?utm_source=chatgpt.com))

------

## 二、核心 / 推荐阅读的论文（经典与较新的）

下面这些是推荐优先读的，有助于理解 DeepSpeed 的核心机制以及当前的前沿改进：

| 论文 / 报告                                                  | 年份 / 出版 | 主要贡献 / 看点                                              |
| ------------------------------------------------------------ | ----------- | ------------------------------------------------------------ |
| **“ZeRO: Memory Optimizations Toward Training Trillion Parameter Models”** | 2020        | DeepSpeed / ZeRO 的奠基论文，提出了优化器状态 / 梯度 / 参数的分割策略，显著减少每个设备的内存冗余，从而能训练更大的模型。 ([arXiv](https://arxiv.org/abs/1910.02054?utm_source=chatgpt.com)) |
| **“ZeRO-Infinity: Breaking the GPU Memory Wall for Extreme Scale Deep Learning”** | 2021        | 在 ZeRO 的基础上引入了将 CPU / NVMe 也纳入管理的机制，允许跨异构内存资源进行扩展，突破纯 GPU 内存限制。 ([微软](https://www.microsoft.com/en-us/research/blog/zero-infinity-and-deepspeed-unlocking-unprecedented-model-scale-for-deep-learning-training/?utm_source=chatgpt.com)) |
| **“ZeRO++: Extremely Efficient Collective Communication for Giant Model Training”** | 2024        | 针对 ZeRO 在极大规模下通信开销大的问题，提出了通信压缩 / 重组织 / 新通信策略的方案，减少通信体量、提升效率。 ([arXiv](https://arxiv.org/pdf/2306.10209?utm_source=chatgpt.com)) |
| **“A Hybrid Tensor-Expert-Data Parallelism Approach to Optimize Mixture-of-Experts Training”** | 2023        | 在 Mixture-of-Experts（MoE）场景下，如何将 tensor parallel、expert parallel 和 data parallel 混合使用，以扩展模型规模和效率。此方案在 DeepSpeed 中有实现。 ([arXiv](https://arxiv.org/abs/2303.06318?utm_source=chatgpt.com)) |
| **“DeepSpeed Inference: Enabling Efficient Inference of Transformer Models at Unprecedented Scale”** | 2022        | 专门针对推理优化的工作，如何在有限显存情况下用零冗余技术（ZeRO stage for inference / 参数 offload / 层切入）来运行超大模型。 ([微软](https://www.microsoft.com/en-us/research/project/deepspeed/publications/?utm_source=chatgpt.com)) |
| **“Toward Understanding Bugs in Distributed Training and Inference Frameworks for Large Language Models”** | 2025        | 虽然不是纯 DeepSpeed 算法优化的论文，但它做了一个对 DeepSpeed / Megatron-LM / Colossal-AI 等框架中出现的 bug 情况的经验性研究，对理解这些系统在工程层面的复杂性很有帮助。 ([arXiv](https://arxiv.org/abs/2506.10426?utm_source=chatgpt.com)) |

此外，微软 DeepSpeed 项目页有一个完整的出版物列表，包含很多较新的、专门方向的论文（比如 checkpointing、长序列优化、Domino 通信省略、系统容错、压缩等）你可以作为查阅资源： ([微软](https://www.microsoft.com/en-us/research/project/deepspeed/publications/?utm_source=chatgpt.com))

------

## 三、读论文的一些建议 / 如何消化这些技术

为了不被系统复杂度“淹没”，你可以按以下顺序、带着问题去读：

1. **先读 ZeRO 原始论文**，理解把优化器状态 / 梯度 / 参数做分区的思路，以及为什么这能减少显存占用。
2. **读 ZeRO-Infinity**，看它如何把 CPU / NVMe 也纳入体系，以及异构内存的调度、offload 策略。
3. **再读 ZeRO++**，重点在于通信问题，大模型分布式训练里通信往往是瓶颈。看看他们是怎么压缩 / 重新组织通信的。
4. **读 Inference / MoE /混并行的方案**：了解推理时如何用类似的零冗余手段，MoE 的并行策略如何设计。
5. **工程 / 系统层面的论文 /报告**（如框架 bug 分析、checkpoint 优化、容错机制等）：这些可以帮助你理解在真实系统部署时的复杂性。

