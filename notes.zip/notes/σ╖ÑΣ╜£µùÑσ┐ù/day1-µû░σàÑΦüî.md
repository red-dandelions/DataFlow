# 新人 landing 日志 day1

## 一、生成 ssh key

`ssh-keygen -t rsa -b 4096 -C "xxx@shein.com"`

## 二、申请堡垒机权限

web: https://appcenter.sheincorp.cn/#/work-flow/order/list/create

IP: 10.122.2.90

![image-20250925175011459](/Users/10283117/Desktop/工作日志/pictures/image-20250925175011459.png)

![image-20250925175217983](/Users/10283117/Desktop/工作日志/pictures/image-20250925175217983.png)



## 三、配置 ssh key

把 mac 本机的 ssh key id_rsa.pub 拷到: https://bastion-aliyun.sheincorp.cn/shterm/#/loginuser/sshkey

1. 堡垒机web登陆地址: https://bastion-aliyun.sheincorp.cn

2. 然后绑定手机令牌

3. `ssh -oHostKeyAlgorithms=+ssh-rsa $(username)@bastion-aliyun.sheincorp.cn` 登陆到堡垒机

4. 拷贝 ~/.ssh/id_rsa.pub内容到 https://gitlab.sheincorp.cn/-/profile/keys

## 四、设置堡垒机用户

1. 创建账号: `sudo useradd $user_name` 
2. 设置账号密码: `sudo passwd $user_name`
3. 切换用户: `su - $user_name`
4. 加入docker组： `sudo usermod -aG docker $user_name`

## 五、代码相关

编译镜像: rk9-abi0:v1.2

堡垒机初始目录下脚本: `run_docker.sh`

1. 创建自己的容器: `sudo ./run_docker.sh --docker_name xxx-rk9 --images rk9-abi0:v1.2`
2. 进容器：`docker exec -it xxx-rk9 /bin/bash`
3. `blade build proto`, `blade build service/strategy --no-test -j 16`
4. 