`ResourcePool` 接口:

* `void Init(size_t init_count)`
* `std::unique_ptr<T> acquire()`
* `void release(std::unique_ptr<T>&& resource)`
* `size_t available()`
* `size_t current()`
* `size_t max_current()`





`StrategyExecutorPool` 里的 executor_pool 实际是 `ResourcePool<StrategyExecutor>`实例。

* `StartReportResource` 接口新建一个线程周期打印资源池信息，并且上报
* `InitExecutorPool`接口调用 `ResourcePool` 的`Init`接口初始化。



`StrategyExecutorPool` 接口：

* `std::unique_ptr<StrategyExecutor> GetExecutor()`
* `void ReleaseExecutor(std::unique_ptr<StrategyExecutor>&& executor)`
* `size_t available()`
* `size_t current()`
* `size_t max_current()`





`StrategyExecutor::Init(true)` 异步执行





`StrategyExecutor` 成员：

* `accessor_`
* `rebuild_accessor_`
* `graph_`
* `kv_model_helper`
* `es_batch_helper`
* `analyzer_`
* `controller_`



`HandleRequest()` 最后依次调用

1. `StrategyExecutor::Bind(const RecMsg& req, std::vector<std::string>&& strategy_ids, RecMsg* rsp)`

   * `accessor_->Bind`
   * `controller_->Bind`
   * `graph_->Bind`
   * `es_batch_helper_->Bind`
   * `kv_model_helper->Bind`

2. `StrategyExecutor::AsyncDAG(std::function<void()>&& cb)`

   * `analyzer_->BuildDAG`
   * `graph_->Run(std::move(cb))`

   会检测是否为有向无环图。

`param_vec` 为 `strategy_ids_`

`MigrateStrategy`对 `strategy_ids_` 再做一次处理

`analyzer_` 和 `controller_` 拥有`StrategyExecutor this` 指针

`accessor_` 拥有 `es_batch_helper` 和 `kv_model_helper` 这两个指针



`BuildDAG`

* `BuildFunctors`
* `BuildDependent`
* `BuildGraph`