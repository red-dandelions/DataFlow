## grpc 异步

`grpc::CompletionQueue::Next(void*, )`

### client

```c++
CompletionQueue cq;
// call back
template <typename SRV, typename RES>
using Callback = std::function<void(const grpc::Status& status, const int cost_ms, RES* response)>;


// rpc
template <typename SVR, typename REQ, typename RES>
using RPC = std::unique_ptr<grpc_impl::ClientAsyncResponseReader<RES>> (SVR::Stub::*)(
	::grpc::ClientContext* contxt, const REQ& request, ::grpc::CompletionQueue* cq
);

RPC<HelloServer, HelloRequest, HelloResponse> func = &HelloStub::AysncSayHello;


auto ctx = new CallContext<SRV, RES>();
// ctx->cli_ctx 为 grpc::ClientContext
ctx->stub = SRV::NewStub(channel);
ctx->resp_reader = (ctx->stub.get()->*rpc)(&ctx->cli_ctx, request, cqs_[GetCqIdx()].get());
ctx->resp_reader->StartCall();
// 这个 ctx 会在 cq.Next(&tag, &ok); 里拿到的 tag
ctx->resp_reader->Finish(ctx->response.get(), &ctx->status, ctx);

// 所有的 ctx 都是在 cq_ 这个事件处理里做的析构，其他cqs_[i] 里获取的，都会通过 grpc::Alarm 的机制，设置到 cq_ 里处理。


```

### async server

```c++
    strategy::StrategyServer server;
    server.SetHandleTimeout(10000);
    server.SetAddress(server_address);
    if (!server.Run<strategy::StrategyHandle>(thread_total, session_size)) {
        LOG_ERROR << "start server error.";
        return -1;
    }

/*
自定义的 server Context 里：
(service->*rpc)(ctx_.get(), request_, resp_writer_.get(), cq, cq, this);


然后启动 worker_size 个线程，监听 session_size 个 context 事件
循环处理：
  只处理 ok == true 事件
*/
//  状态机
 switch(context::status) {
   case Context::Status::Ready: {
     context->status = RUNNING;
     // 注册handler timeout
     ocntext->HandleRequest(); // ReturnResponse 时，设置状态为 FINISH
     avaiable_session_size--;
     break;
   }
   case Context::Status::RUNNING: {
     context->HandleTimeout();
     break;
   }
   case Context::Status::FINISH: {
     context->cancel_handle_timeout();
     context->Reset();
     avaiable_session_size++;
     // report info
     context->reset(&service, cq_.get()); // 重置为 ready 状态，重新注册事件。
   }
 }
  	
  	ready -> running 
  
/*
几个模版参数：
SVR: Recommender
REQ: RecMsg
RES: RecMsg
void (SVR::AsyncService::*rpc)(
:grpc::ServerContext* context, REQ* request,
::grpc::ServerAsyncResponseWriter<RESP>* responder,
::grpc::CompletionQueue* new_call_cq, ::grpc::ServerCompletionQueue* notification_cq, void* tag)
对应 &Recommender::AsyncService::RequestDoRecommend


context:
表示 RPC 的上下文信息。
包含 metadata、客户端地址、deadline、取消状态 等信息。
在处理 RPC 的时候用它。

responder->Finish(response, grpc::Status::OK, tag);

接口 RequestDoRecommend

*/
/*
异步服务时，不需要重新实现接口，需要使用异步 api 监听事件来处理
client 端可以同步请求（阻塞）或者异步请求服务（非阻塞）。
*/
resp_writer_->Finish(*response_, grpc_status_, this);
```

```protobuf
message RecMsg {
    string trace_id = 1;
    ContextMsg context_msg = 2;
    UserMsg user_msg = 3;
    ItemMsg item_msg = 4;
    ExtraMsg extra_msg = 5; //请求方不填
    srchRoute.goods_sort.PbSortRequest srch_request = 6;
    TraceMsg trace_msg = 7;
}
service Recommender {
    rpc DoRecommend(RecMsg) returns(RecMsg) {}
}
```

