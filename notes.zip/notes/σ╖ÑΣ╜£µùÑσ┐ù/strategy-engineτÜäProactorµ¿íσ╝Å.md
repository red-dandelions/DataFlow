# strategy-engine的Proactor模式

------

## 1. 各个模块对应关系

- **Proactor 模型里的角色**
  - **应用线程**：只关心“完成事件”，拿到结果后做业务逻辑。
  - **内核/IO库**：负责监控 socket、完成 IO 操作，把结果事件放到队列里。
  - **Completion Queue (CQ)**：就是“完成队列”，存放 IO 完成事件。
- **strategy-engine场景里**
  - **线程池** = Proactor 应用层工作者。
    - 循环 `while(true) { cq.Next(...) }`
    - 从 CQ 里取出事件。
    - 根据状态（ready / running / finish）处理业务逻辑。
    - 最后注册新的异步操作请求（比如新的 `AsyncRecv`、timeout 事件等）。
  - **CQ (CompletionQueue)** = 内核/IO库 + 完成事件队列。
    - 当 gRPC 请求到来，底层网络层已经做好了 IO，把事件（“RPC 请求已到达”）投递到 CQ。
    - 或者当你注册的超时、写完成、读完成时，也会产生事件进入 CQ。

------

## 2. 整个闭环

流程大概是：

1. **初始化阶段**
   - 创建 N 个 context（比如 RPC call 的 handler）。
   - 把它们都异步注册到 CQ（比如 `AsyncRequestCall`）。
2. **运行阶段**（线程池并发执行）：
   - 线程池里的 M 个线程阻塞在 `cq.Next()` 上。
   - 当某个事件完成（请求到来、写完成、超时等），CQ 把事件唤醒一个线程。
   - 线程拿到事件 → 根据 context 的状态（ready → running → finish）进入相应逻辑。
   - 如果是 finish，就 reset context，再重新注册到 CQ，继续等待下一个请求。
3. **循环往复**
   - 线程池不需要自己 poll socket，也不需要做 IO，只需要消费 CQ 的完成事件 + 处理业务逻辑。
   - CQ 不断产生新事件，线程池不断取事件处理 → 形成一个闭环。

------

## 3. 关键点

- **线程池是 Proactor 的“业务执行者”**，只做事件消费和逻辑处理。
- **CQ 就是“完成事件源”**，相当于内核/IO库的角色，屏蔽了底层 IO 的复杂性。
- **闭环**：处理完一个事件 → 注册下一个事件 → 继续等待完成 → 再次处理。


 **在 gRPC 里，线程池逻辑就是 Proactor 应用层循环，CQ 就是完成队列，二者协作正好构成了一个 Proactor 模式的闭环。**

