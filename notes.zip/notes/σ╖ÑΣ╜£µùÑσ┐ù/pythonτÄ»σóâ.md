## Miniconda 安装

```bash
mkdir -p ~/miniconda3
curl https://repo.anaconda.com/miniconda/Miniconda3-latest-MacOSX-arm64.sh -o ~/miniconda3/miniconda.sh
bash ~/miniconda3/miniconda.sh -b -u -p ~/miniconda3
rm ~/miniconda3/miniconda.sh
```

查看环境

```
conda env list
```

创建环境(空环境)

```bash
conda create -n torch-test python=3.12

# 进入环境
conda activate torch-test
```

## pytorch 安装

pytorch 安装

```bash
pip3 install torch torchvision
```

依赖安装

```bash
pip3 install pandas
pip3 install matplotlib
```

