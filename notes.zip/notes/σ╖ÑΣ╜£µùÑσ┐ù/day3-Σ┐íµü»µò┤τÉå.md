# day3-信息整理

计划:

1. 熟悉整体架构
2. 熟悉PaaS云平台操作
3. 熟悉告警配置平台
4. 熟悉 grafana 监控平台
5. 熟悉策略引擎的业务和整体代码逻辑（服务启动、请求初始化、召回、过滤、融合、响应返回）



strategy-engine 上游是 flow-engine(流程引擎) 

服务命令启动参数：

```bash
rec_strategy --conf=/data/done/rec_strategy_service_master.pb.tag --load_kv_module=strategy --load_kv_dir=/data/rec-model/
```

环境变量：
```bash
ALERT_URL=http://rec-plt-tools-uswest6-prod-proxy:8888/alert
GRPC_CLIENT_CHANNEL_BACKUP_POLL_INTERVAL_MS=10

```

gdb 调试：

```bash
LD_LIBRARY_PATH=/lib64 LD_PRELOAD=/lib64/libboost_regex.so.1.75.0 /usr/bin/gdb  rec_strategy corefile -ex bt
```

gprc run

```
void RunServer(const std::string& db_path) {
  std::string server_address("0.0.0.0:50051");
  RouteGuideImpl service(db_path);

  ServerBuilder builder;
  builder.AddListeningPort(server_address, grpc::InsecureServerCredentials());
  builder.RegisterService(&service);
  std::unique_ptr<Server> server(builder.BuildAndStart());
  std::cout << "Server listening on " << server_address << std::endl;
  server->Wait();
}
```

