```mermaid
graph TD
	Node_es_filter((xx_es_filter:xx))
	Node_recall_prepare_dsl((xx_recall_prepare_dsl:xx))
	Node_recall_es((xx_recall_es:xx))
	Node_recall_kv_model((xx_recal_kv_model:xx))
	Node_recall_mapping((xx_recall_mapping:xx))
	Node_recall_merge_weight((xx_recall_merge_weight:xx))
	Node_recall_quota_fmerge((xx_recall_quota_fmerge:xx))
	Node_recall_filter((xx_recall_filter:xx))
	Node_recall_union_filter((xx_recall_union_filter:xx))
	Node_recall_save((xx_recall_save:xx))
	
	
	Node_es_filter --> Node_recall_prepare_dsl
	Node_recall_prepare_dsl --> Node_recall_es
	Node_recall_mapping --> Node_recall_es
	Node_recall_es --> Node_recall_merge_weight
	Node_recall_prepare_dsl --> Node_recall_kv_model
	Node_recall_mapping --> Node_recall_kv_model
	Node_recall_kv_model --> Node_recall_merge_weight
	Node_recall_merge_weight --> Node_recall_quota_fmerge
	Node_recall_quota_fmerge --> Node_recall_filter
	Node_recall_filter --> Node_recall_union_filter
	Node_recall_union_filter --> Node_recall_save
```

