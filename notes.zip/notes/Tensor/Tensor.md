1. Tensor : TensorBase

2. TensorBase 包装了

`intrusize_ptr<TensorImpl, UndefinedTensorImpl>`

3. TensorImpl 是具体实现。

`struct C10_API TensorImpl : public c10::intrusive_ptr_target`

**intrusize_ptr**:

```cpp
template <
    class TTarget,
    class NullType = detail::intrusive_target_default_null_type<TTarget>>
class intrusive_ptr;
```

```cpp
template <class TTarget>
struct intrusive_target_default_null_type final {
  static constexpr TTarget* singleton() noexcept {
    return nullptr;
  }
};
```



```python
import torch

a = torch.Tensor([1])
b = torch.Tensor([1])
c = torch.add(a, b)

```

调用链

```cpp
python 层次
Tensor __add__ -> THPVariable_add

C++ 层次
THPVariable_add -> Tensor::add

Tensor::add -> at::_ops::add_Tensor::call // add_Tensor 是 python 自动生成在 .h 文件里的

// add_Tensor::call 的实现
static auto op = create_add_Tensor_typed_handle();
return op.call
  
// 这里由 dispatch 找到对应的 function 
// aten::add.Tensor(Tensor self, Tensor other, *, Scalar alpha=1) -> Tensor
static C10_NOINLINE c10::TypedOperatorHandle<add_Tensor::schema> create_add_Tensor_typed_handle() {
  return c10::Dispatcher::singleton()
      .findSchemaOrThrow(add_Tensor::name, add_Tensor::overload_name)
      .typed<add_Tensor::schema>();
}

// 在 operatorLookupTable_ 里查

```

