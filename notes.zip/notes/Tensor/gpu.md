显卡 -> 架构 -> Compute Capability

对应的显卡和架构，需要在编译的时候指定 sm_xx

比如 Compute Capability 为 8.6 时

nvcc -arch=sm_86 xx.cu. xx.cc



调度流程：

```
CPU -> GPU Kernel Launch -> SM 调度 Block -> Thread 执行 -> 结果回 CPU
```



所有 block 到 GPU 队列里等待调度到空闲的 SM。

block 里 32 个 thread 为一个 warp.

所有的 warp 会调度到 SM 的 队列里。

SM 会有多个 warp 调度器，一次性把多个 warp 放到具体的 core 里执行。

