|pb结构|文件配置|
|--|--|
|recommend_common_config.proto, recommend_updater_config.proto|strategy_engine_main.pb.txt|
|recommend_strategy_param.proto|strategy_param.pb.txt|
|recommend_mmp_param.proto|kv_model_param.pb.txt|
|recommend_fmp_param.proto|strategy_feature_param.pb.txt|
|recommend_common_config.proto|model_feature_service_router.pb.txt, strategy_feature_service_router.pb.txt|