# 一些记录

```
using THPObjectPtr = THPPointer<PyObject>; // 管理 PyObject 指针
```



# 1. pytorch-Tensor

## 速览
- Python 层：`class Tensor(torch._C.TensorBase)` 在 `torch/_tensor.py`，是用户可见的 Python API（许多方法在 Python 层实现或委托给 `_C.TensorBase`/`torch` 函数）。子类、序列化、NumPy/DLPack 等高层逻辑多数在 Python 层或 CPython glue 做校验/委托。
- CPython 绑定（Python↔C++ 桥）：`THPVariable`（定义在 `torch/csrc/autograd/python_variable.*`）表示 Python 的 Tensor 对象的 CPython 类型；它包含一个 `c10::MaybeOwned<at::Tensor> cdata` 字段，用来保存或借用底层 C++ Tensor。主要负责：包装/解包（wrap/unpack）、属性 getter/setter、GC/析构、子类和 wrapper-subclass 的创建与检查、Python/C++ 对象身份保持（resurrection/ownership 切换）等。
- C++ 核心：`c10::TensorImpl`（`c10/core/TensorImpl.h`）是张量底层表示（存储指针 storage、sizes/strides、dispatch keys、version counter、`pyobj_slot_` 等）。`pyobj_slot_` 是关键的数据结构（定义在 `c10/core/impl/PyObjectSlot.h`），用于将 TensorImpl 与 interpreter 特定的 PyObject 关联，并记录 “谁拥有 PyObject” 的标志，从而支持 Python 对象身份不重复、跨解释器检查、以及在必要时“复活” Python 对象。

---

## 一、Python 层—— _tensor.py
- 关键事实
  - Python 中的 `torch.Tensor` 是一个纯 Python 类，继承自扩展模块导出的底层类型 `torch._C.TensorBase`。
  - _tensor.py 提供很多便捷方法、序列化 hook（`__reduce_ex__`）、DLPack、NumPy 互操作、`__deepcopy__` 等，且对不同 layout/后端、量化/稀疏/嵌套张量做了处理分支。
  - `__torch_function__`/`__torch_dispatch__`：PyTorch 支持这些覆盖协议（NumPy 风格的 `__torch_function__`，以及更低级的 `__torch_dispatch__`），但在基础实现里有默认或禁用实现（例如 base class 的 `__torch_dispatch__` 指向 `_C._disabled_torch_dispatch_impl`），wrapper-subclass 的创建会验证 `__torch_dispatch__` 的存在以决定是否允许 Python 层插手调度。

- 调用路径（简化）
  - 用户代码调用 t.xxx() 或 操作符 → 若是 Python 层实现/包装（例如 `Tensor.storage()`）则 Python 方法处理，否则委托给 `torch._C` 或 `torch` 的函数（这些最终由 C++ Dispatcher / kernel 实现）。

- 子类与 wrapper-subclass
  - Python 层允许用户继承 `torch.Tensor`；有两种常见场景：
    - 普通子类（可能只想添加属性/方法）
    - wrapper-subclass：用户定义 `__torch_dispatch__`，希望拦截低级 dispatch（实现自定义行为）。底层在创建 wrapper-subclass 时，会有额外的 C++ 处理（见下文的 CPython 绑定实现）保证该 subclass 的 TensorImpl 有相应的 python-dispatch 标志，这样某些查询（sizes/device/layout）会回退到 Python 实现。

---

## 二、CPython 绑定层（Python 对象 <-> at::Tensor）—— `THPVariable`（torch/csrc/autograd）
- 主要结构
  - struct THPVariable (在 python_variable.h)：是 CPython 的 PyObject 结构体（PyObject_HEAD），包含：
    - c10::MaybeOwned<at::Tensor> cdata;  // 底层 at::Tensor（可能拥有或借用）
    - PyObject* backward_hooks;  // 针对 Parameter/backward hooks 等
    - 其它用于子类等的 Python 指针
  - Variable = at::Tensor
- 主要功能（在 python_variable.cpp）
  - THPVariable_Wrap(const at::TensorBase& var)：把 C++ Tensor 包装成 Python 对象并返回（或重用已存在 PyObject）。
    - 逻辑要点：
      - 对于未定义张量（undefined），返回 Py_None（Python 层语义）。
      - 使用 var.unsafeGetTensorImpl()->pyobj_slot()->check_pyobj(...) 查询该 TensorImpl 在当前 Python interpreter 下是否已经有对应的 PyObject；
      - 如果找到了已存在的 PyObject，就通常会“重用”该 PyObject（以保证 Python 层的身份一致性：C++ Tensor 与 Python 对象一一对应），这需要正确调整引用计数并对所谓的“ownership 标志”做切换；
      - 若未找到，则调用 THPVariable_NewWithVar 在 CPython 层新建一个 THPVariable 并初始化其 cdata。
  - THPVariable_Unpack：将传入的 PyObject（可能是 THPVariable 或其子类）转换为 at::Tensor（用于 C++ API）。
  - Resurrection（复活）：
    - 当 Python 对象被 GC 回收时，绑定层具有复杂逻辑以防止破坏 C++ 侧的资源或违反所有权约定。
    - `isResurrectable()` / `THPVariable_tryResurrect`：如果检测到 TensorImpl 的 pyobj_slot 表示 C++ 侧仍“拥有”该 PyObject，那么在对象析构时可以“复活” Python 对象（通过 `_Py_NewReference`）并切换 owns 标志，避免在 C++ 仍期望 PyObject 存在时把它释放掉。
  - 子类/Wrapper-subclass 创建
    - 有专门的函数 `_make_subclass`、`_make_wrapper_subclass`：在创建 wrapper-subclass 时，会检查该 Python 类是否实现 `__torch_dispatch__`，如果有，则会把底层的 `TensorImpl` 标记为 python-dispatch（通过设置一些 python_custom_* 标志），以便后续对 sizes/device/layout 的查询能回到 Python。
  - 属性映射
    - `THPVariable` 实现了大量属性 getter/setter（`.dtype`, `.device`, `.shape`, `.grad`, `.requires_grad` 等），这些 getter/setter 调用 at::Tensor（或 TensorImpl）对应的方法或字段。
- MaybeOwned<at::Tensor> 含义
  - `c10::MaybeOwned<at::Tensor>` 支持两种语义：Python 对象可以“拥有”底层 at::Tensor（持有一个 owning copy），也可以“借用”外部的 at::Tensor（不负责销毁）。这对避免不必要拷贝与保证正确释放很重要，且与 pyobj_slot 的拥有者标志配合使用。

---

## 三、C++ 核心：TensorImpl 与 PyObjectSlot
### TensorImpl（c10::TensorImpl）
- 职责
  - 保存张量的物理数据相关信息：`Storage storage_`（实际数据）、`SizesAndStrides sizes_and_strides_`、`storage_offset_`、`numel_`、`caffe2::TypeMeta data_type_`、`device_opt_`、`DispatchKeySet key_set_` 等。
  - 包含 Autograd 相关元数据（通过 `autograd_meta_` 指针）、版本计数器（`VariableVersion version_counter_`）以支持 in-place 检测与 saved-variable 检测。
  - 包含 `impl::PyObjectSlot pyobj_slot_`：这是把 C++ TensorImpl 绑定到 Python 对象的核心位置（每个 TensorImpl 内嵌一个 slot）。
- 重要字段（简要）
  - storage_, sizes_and_strides_, storage_offset_, numel_, data_type_, device_opt_
  - key_set_：决定 Dispatcher 如何选择 kernel（DispatchKeySet）
  - version_counter_：用于 autograd 的版本检查（inplace 修改检测）
  - pyobj_slot_：关键（见下）
  - flags/bitfields：`python_custom_sizes_strides_`、`python_custom_device_`、`python_custom_layout_` 等，用于把某些行为交给 Python 层定制（如果是 wrapper-subclass）

### PyObjectSlot（c10::impl::PyObjectSlot）
- 设计目的
  - 在多解释器/线程环境中，把 TensorImpl 和 Python 的 PyObject 关联起来，同时记录“哪个 interpreter”与该 PyObject 相关，并记录“谁拥有 PyObject”（C++ 侧或 Python 侧）。
  - 支持“检查当前 interpreter 下是否已经存在 PyObject”、初始化 tag、清除、以及在析构/复活时的行为控制。
- 关键字段（概念）
  - std::atomic<PyInterpreter*> pyobj_interpreter_：记录该 slot 被哪个 Python interpreter 标记（多解释器运行时需要防止跨解释器滥用）。
  - PyObject* pyobj_：指向实际的 PyObject（可能为空）。
  - owns_pyobj flag（内置为某种 tag，接口有 owns_pyobj() / set_owns_pyobj(bool)）：表示当前 PyObject 的引用/所有权属于哪边（C++ 还是 Python），以避免引用循环或重复释放。
- 主要操作（API）
  - init_pyobj(self_interpreter, pyobj, status)：把 slot 标记为属于某个解释器并写入 pyobj（会在不同 status 下有并发/校验逻辑）。
  - check_pyobj(self_interpreter)：在当前解释器上下文下检查是否存在已标记的 pyobj（会返回 optional<PyObject*>，在 hermetic/TLS 场景或不同 interpreter 时可能返回 nullopt 或报错）。
  - maybe_destroy_pyobj() / unchecked_clear_pyobj()：用于在合适时清理 pyobj。
  - owns_pyobj() / set_owns_pyobj(bool)：读取/设置“谁拥有 pyobj”标志。
- 为什么重要
  - 通过 pyobj_slot，C++ 可以重用已有的 Python 对象（避免每次从 C++ 到 Python 都新建 wrapper）。
  - 支持安全的对象复活（resurrection）：当 Python 对象在析构而 C++ 仍然期望该 PyObject 存在时，pyobj_slot 的 owns 标志可以让 CPython 绑定代码决定是否把 PyObject 从析构路径中拯救回来（并通过 _Py_NewReference 恢复引用计数），从而避免悬空指针或错误释放。
  - 支持多解释器/torch-deploy 场景，避免不同 interpreter 之间错误重用 PyObject。

---

## 四、从 Python 方法到 C++ 内核的调用流程（step-by-step）
1. 用户在 Python 端写 t = torch.tensor(...); 然后调用 t.add(x) 或 t + x。
2. Python 的 `Tensor`（可能直接是 `torch._C.TensorBase` 导出的类型或继承 thereof）会把调用委托给 `_C` 或通过 Python-layer 的方法把调用传递到底层实现。
3. 在 CPython 层，传入的 PyObject（Tensor）会通过 `THPVariable_Unpack` 取得 `at::Tensor`（即从 `THPVariable.cdata` 或通过 Python 对象找到其底层 `TensorImpl`）。
4. C++ 的 `Dispatcher`（根据 `TensorImpl::key_set_`）选择具体的 kernel（某个 backend 的实现），实际工作在 at::Tensor / Storage / kernel 中完成。
5. 返回的 at::Tensor 结果，在回到 Python 时会通过 `THPVariable_Wrap` 包装成 Python 对象：
   - 若该 at::Tensor 对应的 TensorImpl 已经有在当前 interpreter 下的 PyObject（`pyobj_slot_->check_pyobj()` 返回非空），就会尽量重用该 PyObject（调整 owns 标志与引用计数），从而保证 Python 层的 identity（is）一致。
   - 否则创建新的 THPVariable Python 对象并可能通过 `pyobj_slot_.init_pyobj(...)` 把它记录在 TensorImpl 上。

---

## 五、所有权/复活（ownership & resurrection）关键说明
- `pyobj_slot` 的 owns 标志控制“哪个侧（C++ 或 Python）负责 PyObject 的生命周期”：
  - 常见情形：Python 拥有 PyObject（Python 引用计数主导），pyobj_slot 记录 PyObject 指针但标志为“非 owns by C++”。
  - 在某些场景（比如临时 C++ 对象刚创建，尚未暴露给 Python），C++ 可能暂时拥有 PyObject（owns_pyobj==true），此时 Python 的 GC 不能直接释放该 PyObject；一旦 PyObject 要真正暴露给 Python，binding 层会设置 owns 标志为 false，使 Python 成为所有者。
- 复活（resurrection）
  - 当 Python 准备析构 THPVariable 时，绑定层会检查是否可以“复活”该对象（例如 C++ 侧仍然引用 TensorImpl 并且 pyobj_slot 标记表明 C++ 认为 PyObject 还应该存在）。如果可以，绑定层会把 owns 标志设为 true 并调用 `_Py_NewReference` 恢复引用计数，从而让对象继续存活并防止 C++ 侧使用被释放的 PyObject。
  - 这种机制非常细致，包含对 GIL 的管理、跨解释器检查（pyobj_interpreter）以及避免在错误 interpreter 下使用 PyObject 的防护。





---

## 1) at::Tensor / TensorBase ↔ Python `_C.TensorBase` 的对应关系（要点）
- Python 层入口
  - 用户看到：`torch.Tensor`（实现：`torch/_tensor.py` 中 `class Tensor(torch._C.TensorBase)`）。注意：`torch.Tensor` 是一个 Python 类，继承自 C++/扩展导出的 `torch._C.TensorBase`（在 C++ 端对应 `at::TensorBase` / `at::Tensor`）。
- C++ 层类型
  - `at::Tensor` / `at::Tensor` 的定义位置：由 TensorBody.h 生成/实现（该文件定义 `class at::Tensor : public TensorBase`）。`TensorBase` 定义在 TensorBase.h。
  - `TensorBase` 封装 `c10::intrusive_ptr<c10::TensorImpl>`（成员名 `impl_`），提供与 TensorImpl 交互的轻量 API（比如 `sizes()`, `stride()`, `dtype()`, `device()` 等）。
- 典型对应（Python API → C++ API → 关键实现文件）
  - Python `t.shape` / `t.size()` → `_C.TensorBase.size()` → `at::TensorBase::size()` → `TensorImpl::size()` （TensorImpl.h）
  - Python `t.dtype` → `_C.TensorBase.dtype()` → `at::TensorBase::dtype()` → `TensorImpl::dtype()`
  - Python `t.device` → `TensorBase::device()` → `TensorImpl::device()`（`device_opt_`）
  - Python `t.numpy()` / DLPack interop → CPython glue (`torch/csrc/…tensor_numpy.cpp`) → 使用 `THPVariable_Unpack` 获取 `at::Tensor` 后走 storage->data 等
  - Python `t.requires_grad`、`.grad`、`.backward()` → Python 层或 CPython glue 调用 `TensorBase::requires_grad()`, `impl_->grad()`，autograd node 在 `autograd` 相关目录中实现。
- 总结：Python 的 `torch.Tensor`（高层方法与兼容性逻辑）大多在 Python 层实现或委托；真正的低级字段/行为（storage、sizes、strides、device、dispatch keys、version counter、pyobj_slot）在 `TensorImpl` 中。

---

## 2) 端到端调用与对象生命周期（简化但精确的序列）
下面以“Python 调用算子并返回结果”举例（例如 t + x）说明数据与对象如何在 Python/C++ 间流动，以及身份/所有权如何维持。

1. Python 层调用（用户代码）
   - 用户写 t + x，Python 首先把操作映射到 `torch` 顶层函数或直接触发 `Tensor.__add__`（Python）或 `torch.ops.aten.add()` 的高速路径。`torch/_tensor.py` 有一些运算符包装，但大多数操作通过 dispatcher 到 C++。

2. Python 对象到 C++（解包）
   - C++ 接口层接收 PyObject 参数（可能是 `THPVariable` 或其子类）。
   - 绑定函数中用 `THPVariable_Unpack(pyobj)`（在 `python_variable.h/.cpp`）把 PyObject 解为 `at::Tensor`（内部是 `THPVariable->cdata` 或使用 PyObject 查找 TensorImpl）。
   - `THPVariable_Unpack` 能处理子类、检查 `None`、检查 type 等，并最终得到 `at::Tensor`（即持有 `intrusive_ptr<TensorImpl>`）。

3. C++ Dispatcher & kernel
   - Dispatcher 使用 `at::Tensor`（从 `TensorImpl::key_set_`）决定 dispatch keys，然后选择合适后端/实现（CPU/CUDA/...）执行具体 kernel（这个路径涉及 `c10::Dispatcher`、`native_functions` 自动生成的代码，可能是 `aten/src/ATen/native/` 中的实现）。
   - kernel 读取/写 `TensorImpl` 的 `storage_`（或创建新 Tensor/Storage），并产生返回的 `at::Tensor`。

4. C++ 返回到 Python（包装）
   - 调用从 C++ 返回 `at::Tensor`，要暴露给 Python 时，执行 `THPVariable_Wrap(const at::TensorBase& var)`：
     - `THPVariable_Wrap` 先检查 `var.defined()`；若 undefined 返回 None；
     - 调用 `var.unsafeGetTensorImpl()->pyobj_slot()->check_pyobj(self_interpreter)`，查看当前 interpreter（多解释器场景）是否已有对应 PyObject；
     - 如果 slot 返回已有 PyObject（表示此前某次从 C++ 到 Python 时在该 interpreter 已创建对应 Python 对象），则“重用”该 PyObject（调整引用计数、可能切换 owns 标志），从而保证 Python 层 object identity（is）一致；
     - 如果没有，则创建新的 `THPVariable`（`THPVariable_NewWithVar`）并把它与 TensorImpl 的 `pyobj_slot` 关联（`init_pyobj`）。
   - 关键是：TensorImpl 的 `pyobj_slot` 记录了 interpreter tag、pyobj 指针和 owns 标志。

5. GC / 复活（resurrection）场景
   - 有时 Python 对象被 GC 收回（引用计数到 0），但底层 C++ 仍持有 Tensor（例如存在 C++ 静态变量或其他持有引用）。`pyobj_slot` 可以被设置为 C++“拥有” PyObject（`owns_pyobj()`），在 Python 对象析构路径，绑定层会检测到此情形并调用复活逻辑：`THPVariable_tryResurrect` 会把 `pyobj_slot_->set_owns_pyobj(true)` -> 调用 `_Py_NewReference` 恢复引用计数，最终让 Python 对象继续存在，避免 C++ 使用悬空 PyObject。
   - 反之，当 Python 成为唯一所有者时，`set_owns_pyobj(false)` 会设置，使得 Python 的析构能够真正释放资源。

---

## 3) pyobj_slot 的状态机（要点）
pyobj_slot (`c10::impl::PyObjectSlot`) 的核心字段/语义：
- `pyobj_interpreter_`（atomic）：记录哪个 PyInterpreter tag 拥有该 slot（用于多解释器安全）
- `PyObject* pyobj_`：指向实际 Python 对象（可空）
- owns 标志：指示“谁负责 PyObject 生命周期”（C++（true）或 Python（false））

主要操作：
- `init_pyobj(interpreter, pyobj, status)`：给 slot 打上 interpreter 标签并设置 pyobj（并在并发情形做检查）
- `check_pyobj(interpreter)`：如果 slot 被当前 interpreter 标签化，返回 pyobj（或 null），否则返回 nullopt（或在非法跨解释器访问时报错）
- `has_pyobj_nonhermetic()` / `maybe_destroy_pyobj()` / `unchecked_clear_pyobj()`：用于清理
- `owns_pyobj()` / `set_owns_pyobj(bool)`：读写 owns 标志

典型转换：
- 初始无 pyobj → 第一次从 C++ 包装到 Python：创建 PyObject、`init_pyobj`；默认 owns=false（Python 拥有）
- 短暂情况：C++ 代码可能临时“拥有” PyObject（owns=true）以避免引用循环/在未把对象公开给 Python 前被立即回收 → 之后把 owns 切到 false。
- 析构时，如果 owns==true 且 C++ 想维持 pyobj 存活，则在 Python 侧析构捕获并复活（_Py_NewReference），反之允许析构。

---

## 4) wrapper-subclass（__torch_dispatch__）示例及行为解释
示例：一个简单的 Python wrapper-subclass，会拦截所有 torch 运算并打印日志。

示例代码（运行说明见后）：
```python
import torch

class MyTensor(torch.Tensor):
    # 必须定义 __new__ 来创建正确的底层表示或用 Tensor.make_wrapper_subclass
    @staticmethod
    def __new__(cls, data):
        # 先把普通 tensor 包装成 MyTensor
        t = torch.as_tensor(data)
        return torch._utils_internal._make_wrapper_subclass(cls, t)  # 伪 API，实际由 C++ glue 实现

    def __torch_dispatch__(self, func, types, args=(), kwargs=None):
        print("Intercepted:", func.__name__)
        # 调用默认实现以获得实际计算结果（或自己实现）
        return func(*args, **(kwargs or {}))

# 简单使用
a = MyTensor([1.0, 2.0])
b = torch.rand(2)
c = a + b  # MyTensor.__torch_dispatch__ 会被调用
```

关键点与实现：
- Python 层定义了 `__torch_dispatch__`，表示该类型希望拦截 dispatcher 层面的调用。
- 在 C++ 绑定创建 wrapper-subclass 时（`THPVariable_make_wrapper_subclass` / `_make_wrapper_subclass`），会：
  - 验证 Python 子类确实实现了 `__torch_dispatch__`；
  - 在对应的 `TensorImpl` 上设置 `python_custom_*` 的 flags（`python_custom_sizes_strides_`, `python_custom_device_`, `python_custom_layout_`），并把 `python_ks`（python dispatch key）加入 `key_set_`；
  - 这样，当 dispatcher 查看 `key_set_` 时，会发现 `python_ks`，触发 Python dispatch path（c10 dispatcher 在遇到 python key 时会进入 Python 的 `__torch_dispatch__`）。
- 当 wrapper-subclass 的运算需要访问 `.size()`/`.device()`，这些方法可能会被 routed 回 Python（因为 `python_custom_*` 已设置），也就是 `TensorImpl` 上的 `matches_python_custom` 会令 `sizes()/device()` 调用到 virtual/custom path，从而进入 Python 层实现（所以 wrapper-subclass 在覆盖这些属性时需要谨慎，且会有性能代价）。

注意：
- 创建 wrapper-subclass 必须用 C++ glue 的专门 API（不能直接简单 new 一个子类），因为需要把底层 TensorImpl 标记为 “python dispatch” 并确保 `pyobj_slot`、ownership、version 等不被破坏。
- `__torch_function__` 与 `__torch_dispatch__` 的区别：
  - `__torch_function__` 是 numpy-style 的高层钩子（函数层面），由 Python 解释器/运算选择；
  - `__torch_dispatch__` 是低层 dispatcher hook，直接在 c10 dispatch path 拦截，灵活但更危险，常用于实现自定义 tensor backends（如 functorch、accelerator wrappers）。

---





## 高层结论（一句话）
- Python 层的 `torch.Tensor` 是 Python 的类（继承自 C 扩展导出的 `_C.TensorBase`）；实际数据与元信息由底层 C++ `at::Tensor` / `c10::TensorImpl` 管理，Python↔C++ 的桥是 `THPVariable`（C struct）与 `pyobj_slot`（TensorImpl 的一个槽），所有权切换和复活逻辑都在 python_variable.cpp + PyObjectSlot.h 中实现；运算调用通过 ATen 的 dispatcher（native_functions.yaml → meta/impl → stub → backend kernel）分发到不同后端与内核。

---

## 我阅读/引用过的关键源码（可直接跳转）
- Python 层 / 元接口
  - `torch/_tensor.py`（Python 层 Tensor 类实现、子类化/序列化等; 我已阅读全文并总结）  
- CPython 绑定 / Python 对象实现
  - `torch/csrc/autograd/python_variable.h` / python_variable.cpp（THPVariable、THPVariable_Wrap/Unpack、wrapper-subclass、resurrection、tp_clear/dealloc、getters/setters 等） — 这是 Python ↔ C++ 的核心 glue。
- C++ Tensor 内部表示与 py-slot
  - TensorImpl.h（`c10::TensorImpl` 字段：storage、sizes/strides、DispatchKeySet、version counter、impl::PyObjectSlot pyobj_slot_、python_custom_* 标志等）。
  - PyObjectSlot.h（`PyObjectSlot`：保存 PyObject*、interpreter tag、owns 标志、并发/多解释器语义：init_pyobj/check_pyobj/set_owns_pyobj/maybe_destroy_pyobj）。
  - TensorBase.h / TensorBody.h（`at::TensorBase` / `at::Tensor` 公开 API 与由 native functions 生成的方法占位）。
- Dispatcher / operator 实现（以 add 举例）
  - native_functions.yaml（operator 声明与 dispatch map；`add.Tensor` / `add.out` 的映射我已定位）
  - BinaryOps.cpp（add 的 meta/impl 层、DEFINE_DISPATCH(add_clamp_stub) 等）
  - BinaryOpsKernel.cpp（CPU 内核实现：`add_clamp_kernel`，并 `REGISTER_DISPATCH(add_clamp_stub, &add_clamp_kernel)`）
  - 其它后端/特殊实现示例：BinaryOps.cpp、SparseTensorMath.cpp、BinaryOps.mm 等（native_functions.yaml 中列出并在源码中实现/redispatch）。

---

## 关键概念与实现要点（精要）
- Python 对象与 C++ 对象的双向映射
  - Python 层返回/接受的对象是 `PyObject*`（类型是 `THPVariable` 或其子类），内部持有 `c10::MaybeOwned<at::Tensor> cdata`。  
  - THPVariable_Unpack(obj)（在 python_variable.cpp 中）把 `PyObject*` -> `at::Tensor`：这是从 Python 下沉到 C++ 的入口；THPVariable_Wrap(at::TensorBase&) 则把 C++ Tensor 包装成 Python `PyObject*`（可能复用已有 PyObject）。
- pyobj_slot（对象身份与复用）
  - `c10::TensorImpl` 含 `impl::PyObjectSlot pyobj_slot_`（定义在 PyObjectSlot.h）。该槽保存 PyObject*、interpreter tag（用于多 Python 解释器情形）、以及 `owns_pyobj` 标志。  
  - 当 C++ 需要重用或返回已有 Python 对象时，会调用 `pyobj_slot()->check_pyobj(getPyInterpreter(), ...)`；若返回有效 PyObject* 则可以复用（避免创建新 PyObject）。  
  - `owns_pyobj` 语义：当 true 表示“C++ 持有并负责 PyObject 的生命周期”；当 false 表示 Python 持有。逻辑在 `THPVariable_Wrap` 中会根据情形 flip（翻转） owns 标志。
- 复活（resurrection）
  - Python 在 GC 触发 tp_clear 时可能会使对象临时变不可达；如果 C++ 仍然有其他引用，`THPVariable_tryResurrect` 会在 tp_dealloc 前通过 `_Py_NewReference` 让对象复活，并把 `pyobj_slot` 的 owns 标志设为 true（C++ 现在拥有 Python 对象），并用 MaybeOwned 切换 `cdata` 的所有权（见 python_variable.cpp）。  
- wrapper-subclass / __torch_dispatch__
  - Python 子类（或 wrapper-subclass）如果定义 `__torch_dispatch__`，在创建 wrapper 时（`_make_wrapper_subclass` / `THPVariable_make_wrapper_subclass`）会把 TensorImpl 上的 python-dispatch / python_custom_* 标志（如 sizes/strides/device/layout）设置好，并在 `key_set_` 中加入 `DispatchKey::Python`，从而让 dispatcher 在遇到该张量时把控制权交给 Python dispatch（或 PythonFallback）。
- DispatchKey / dispatcher 路径简述
  - 每个 TensorImpl 有一个 DispatchKeySet（`key_set_`）；dispatcher 根据这个集合与线程本地 TLS（例如 Python dispatch 是否被排除）来选择要命中的 kernel 或 fallback。  
  - 如果 `DispatchKey::Python` 在 key set 且 TLS 没被排除，执行路径会走到 PythonFallbackKernel.cpp 或 Python dispatcher（即可能进入 Python 层的 `torch._dispatch.python` 机制），否则按常规后端（CPU/CUDA/…）的 stub -> kernel 走。
- native / meta / impl / stub / kernel 分层（ATen）
  - native_functions.yaml 定义 op 名、variants、dispatch map（例如 `add.Tensor`、`add.out`、不同后端的实现名）；
  - meta（TORCH_META_FUNC）负责检查与构建 TensorIterator/输出形状/类型（在 BinaryOps.cpp 的 meta 部分可见）；
  - impl（TORCH_IMPL_FUNC）是把 meta 构建的信息传入实际执行（有时 impl 会直接调用 stub）；
  - stub（DECLARE/DEFINE_DISPATCH）是一个按 device type 分发的抽象（例如 `add_clamp_stub`）；
  - kernel（backend-specific）是实际的实现，如 `add_clamp_kernel`（在 BinaryOpsKernel.cpp），并通过 `REGISTER_DISPATCH(add_clamp_stub, &add_clamp_kernel)` 注册到 stub。

---

## 具体示例：调用 torch.add(a, b) 的端到端调用栈（带文件/函数）
下列是一个常见情形（普通 CPU 张量、非稀疏、无 python custom override），我把每一步的函数/文件名列出来，按时间顺序说明发生了什么：

1) Python 层调用
   - Python: torch.add(a, b)（或 a.add(b)）  
     - 位置（Python 层接口/封装由多个模块生成/导出，映射到 ATen 的声明在 native_functions.yaml）。  

2) 进入 C 层（binding）
   - C/C++  binding: 生成的 ATen 封装将 Python 参数打包并调用对应的 C++ 函数（映射由 native_functions.yaml 控制）。  
   - 在 C++ 实参处理处会调用 THPVariable_Unpack 来把 Python 张量参数转换为 `at::Tensor`：
     - THPVariable_Unpack（定义/调用位置）：python_variable.cpp（多处直接调用，例如 `THPVariable_Unpack(self)`）

3) Dispatcher / 解析 op
   - Dispatcher 根据 op signature（`add.Tensor` / `add.out`）和参数上的 DispatchKeySet 决定到底走哪一条实现分支（native_functions.yaml 中列出：mkldnn、sparse、ZeroTensor、NestedTensor、MPS 等）。  
   - 在没有特殊后端时，调度到结构化 out 路径（`add.out`）。

4) meta（shape/dtype 检查并构造 TensorIterator）
   - meta 实现（文件/函数）：
     - `TORCH_META_FUNC2(add, Tensor)` 在 BinaryOps.cpp（负责 `build_borrowing_binary_op`、`native::alpha_check` 等）。  

5) impl（实现层）与 stub 调用
   - impl 层（如果存在）会调用一个 stub（dispatch stub），例如在 BinaryOps 中某些实现会调用：  
     - `add_clamp_stub(device_type(), iter, alpha, min_val, max_val)`（见 BinaryOps.cpp）  
   - BinaryOps.cpp 有 `DEFINE_DISPATCH(add_clamp_stub);`（该 stub 后续在具体 backend 注册）。

6) backend kernel（CPU）
   - CPU kernel 定义并注册：
     - Kernel 实现：`add_clamp_kernel(TensorIterator& iter, const Scalar& alpha_scalar, const Scalar& min_val, const Scalar& max_val)` 在 BinaryOpsKernel.cpp（实现包含 `cpu_kernel_vec`、`AT_DISPATCH_ALL_TYPES` 等向量化逻辑）。
     - 注册：`REGISTER_DISPATCH(add_clamp_stub, &add_clamp_kernel)`（在 BinaryOpsKernel.cpp 中第 1392 行）。
   - stub -> kernel 路径在运行时由 dispatch framework 调用对应 device 的实现。

7) 返回/包装回 Python
   - kernel 完成计算并写入输出 Tensor（`at::Tensor`），最后层返回 `at::Tensor`。
   - 要把结果返回给 Python，需要调用 `THPVariable_Wrap(const at::TensorBase& var)`（python_variable.cpp）：
     - `THPVariable_Wrap` 会先尝试 `var.unsafeGetTensorImpl()->pyobj_slot()->check_pyobj(getPyInterpreter(), ...)`：如果已有对应的 PyObject 则复用；否则 `THPVariable_NewWithVar` 创建新的 Python 对象并把 pyobj_slot 初始化/注册。
   - 最终 Python 得到 `PyObject*` 并继续执行后续语句。

（注：如果张量 key_set 中含 `DispatchKey::Python`，dispatcher 会把控制权交给 Python dispatch / PythonFallbackKernel，可能在 Python 层被 `__torch_dispatch__` 或 TorchDispatchMode 拦截并处理；native_functions.yaml 也列出专门的后端映射，如 Sparse、MKLDNN、MPS、NestedTensor 等。）

---

## 与对象身份/所有权相关的关键实现细节（要点）
- pyobj_slot 的并发与多解释器语义（见 PyObjectSlot.h）
  - check_pyobj(getPyInterpreter(), ignore_hermetic_tls=false) 会比较 interpreter tag，并可能返回 optional<PyObject*>；如果 slot 目前由另一个解释器“标记”（TAGGED_BY_OTHER），行为不同（可能抛错或返回 nullopt），这用于多解释器安全性与 Hermetic TLS。  
- THPVariable_Wrap 的复用与 owns flip（实现片段在 python_variable.cpp）
  - 如果 slot 返回有效 PyObject* 且 `owns_pyobj()` 为 true，则说明 C++ 之前“独占”了该 PyObject（PyObject 引用数为 1），现在 Python 端要重新获得该对象，代码会把 `pyobj_slot()->set_owns_pyobj(false)`（把拥有权移回 Python），并把 internal MaybeOwned 变为 owned（`reinterpret_cast<THPVariable*>(obj)->cdata = MaybeOwned<Variable>::owned(Variable(var));`）。  
- 复活（THPVariable_tryResurrect）
  - 如果 tp_clear 已运行但 C++ 仍有引用（use_count > 1），代码会在 dealloc 前调用 `_Py_NewReference` 将 PyObject 复活，并把 owns 标志反向设置，避免早期析构 C++ 对象。  
- wrapper-subclass 创建（`_make_wrapper_subclass` / `THPVariable_make_wrapper_subclass`）
  - 函数会强制要求 Python 子类实现 `__torch_dispatch__`，然后构造一个“meta / meta-storage-only” tensor（通常 storage 为 meta 或 meta-backend），并设置 `python_custom_sizes_strides`, `python_custom_device`, `python_custom_layout` 等标志（即 TensorImpl 上的 python_custom_* 字段），以便 dispatcher 在运算时调用 Python 层实现。

---

- 

---

## 我已经做的验证 / 读到的具体行（快速证明）
- 在 python_variable.cpp 中：
  - THPVariable_Wrap 的 pyobj_slot 检查与 owns 翻转逻辑（见函数内部，复用已有 PyObject 与 set_owns_pyobj(false) 的代码路径）。  
  - THPVariable_tryResurrect 使用 `_Py_NewReference`，并把 `pyobj_slot()->set_owns_pyobj(true)`（复活时 C++ 接手 PyObject）。  
  - `_make_wrapper_subclass` / `_make_subclass` 实现在同文件中（用于创建拥有 __torch_dispatch__ 的 wrapper）。
- 在 PyObjectSlot.h 中：
  - check_pyobj/init_pyobj/owns_pyobj/set_owns_pyobj 等方法与并发注释（interpreter tag, hermetic TLS）——我已读并抽取语义要点。  
- 在 operator 路径中：
  - native_functions.yaml 包含 `add.Tensor`, `add.out` 的声明与 dispatch 映射（文件行位于 540~640 附近，我已打开该片段）。  
  - BinaryOps.cpp 包含 add 的 meta 实现（`TORCH_META_FUNC2(add, Tensor)`）和 `DEFINE_DISPATCH(add_clamp_stub)`。  
  - BinaryOpsKernel.cpp 包含 `add_clamp_kernel` 实际向量化实现，并 `REGISTER_DISPATCH(add_clamp_stub, &add_clamp_kernel)`（我已打开并定位注册行）。

